import SwiftUI

import UIKit

// Release Candidate: 2026-09-20

struct ContentView: View {
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
    @StateObject private var workspace = WorkspaceStore()
    @State private var workspaceDestination: WorkspaceDestination?
    @State private var showLawHistory = false
    @State private var activityScope: ProjectScope = .all
    @State private var preparationProjectID: UUID?
    @State private var workProjectID: UUID?
    @State private var evidenceProjectID: UUID?
    @State private var deadlineProjectID: UUID?
    @State private var lawHistorySaved = false


    @State private var workRecords: [WorkRecord] = []

    @State private var editingWorkRecord: WorkRecord? = nil

    let questions = [

        "勤務時間を会社から指定されていますか？",

        "勤務する曜日を会社から指定されていますか？",

        "勤務場所を会社から指定されていますか？",

        "仕事の具体的な進め方について指示を受けていますか？",

        "会社からシフトを組まれていますか？",

        "休みを取る際に会社の許可が必要ですか？",

        "仕事中の行動や進捗を会社から管理されていますか？",

        "定例ミーティングへの参加を求められていますか？",

        "会社から仕事の量や件数を指定されていますか？",

        "業務で使用するツールを会社から指定されていますか？",

        "仕事を断ることが難しい状況ですか？",

        "自分の代わりに別の人へ仕事を任せることが難しいですか？",

        "報酬が成果ではなく、働いた時間を基準に決まっていますか？",

        "会社の社員と似た働き方をしていますか？",

        "契約終了について会社側が一方的に決められる状況ですか？"

    ]

    @State private var questionNumber = 0

    @State private var yesCount = 0

    @State private var answers: [Bool] = []

    @State private var isFinished = false

    @State private var isSaved = false

    @State private var histories: [CheckHistory] = []

    @State private var showHistory = false

    @State private var selectedHistory: CheckHistory? = nil

    @State private var showDeleteAlert = false

    // MARK: - 勤務記録用

    @State private var showWorkRecord = false

    @State private var showWorkRecordHistory = false

    @State private var workDate = Date()

    @State private var workStartTime = Date()

    @State private var workEndTime = Date()

    @State private var workBreakMinutes = 60

    @State private var workInstruction = ""

    @State private var workDetails = ""

    @State private var workMemo = ""

    @State private var showWorkRecordSavedAlert = false

    // 保存ボタンの連打による二重保存を防ぐ

    @State private var isSavingWorkRecord = false

    // 証拠・メモの保存ボタン多重発火を防ぐ

    @State private var isSavingEvidenceRecord = false

    @State private var recordToDelete: WorkRecord? = nil

    @State private var showWorkRecordDeleteAlert = false









    // MARK: - 証拠・メモ用

    @State private var evidenceRecords: [EvidenceRecord] = []

    @State private var editingEvidenceRecord: EvidenceRecord? = nil

    @State private var showEvidenceRecord = false

    @State private var showEvidenceHistory = false

    @State private var evidenceDate = Date()

    @State private var evidenceType = "LINE"

    @State private var evidenceTitle = ""

    @State private var evidenceDetails = ""

    @State private var showEvidenceSavedAlert = false

    @State private var evidenceToDelete: EvidenceRecord? = nil

    @State private var showEvidenceDeleteAlert = false

    // MARK: - 初回ガイド

    var onboardingView: some View {

        OnboardingView(
            onboardingPage: $onboardingPage,
            onComplete: {
                hasSeenOnboarding = true
                onboardingPage = 0
                showHome = true
            }
        )
    }

    // MARK: - ホーム・レポート

    @AppStorage("hasSeenOnboarding") private var hasSeenOnboarding = false

    @AppStorage("hasCreatedFirstRecord") private var hasCreatedFirstRecord = false

    @State private var showFirstUseGuide = false

    @State private var showFreeLimitNotice = false

    @State private var freeLimitKind = "記録"





    @State private var onboardingPage = 0

    @State private var showHome = true

    @State private var showReport = false

    @State private var pdfURL: URL?

    @State private var showPDFShare = false

    @State private var showPDFError = false

    @State private var showConsultation = false

    @State private var showContractGuide = false

    @State private var showSettings = false

    @State private var showAbout = false

    @State private var showMessageOrganizer = false

    @State private var showTroubleGuide = false

    @State private var showFreelanceLawCheck = false

    @State private var showEvidenceChecklist = false

    @State private var showPremium = false

    @State private var showPrivacyInfo = false

    @State private var showDocumentDraft = false

    @State private var documentDraftType = "支払いのお願い・督促"

    @State private var documentRecipient = ""

    @State private var documentSender = ""

    @State private var documentAmount = ""

    @State private var documentDeadline = Date()

    @State private var documentFacts = ""

    @State private var documentRequest = ""

    @State private var documentDraftText = ""

    @State private var documentCopiedAlert = false

    @StateObject private var storeKitManager = StoreKitManager()
    @State private var isPlusUnlocked = PlusAccessConfig.initialUnlocked

    @State private var showFreeLimitAlert = false

    @State private var freeLimitMessage = ""

    @State private var evidenceChecklistCase = 0

    @State private var evidenceChecklistAnswers = Array(repeating: false, count: 8)

    @State private var freelanceLawAnswers = Array(repeating: false, count: 7)

    @State private var organizerText = ""

    @State private var organizerResult = ""

    @State private var importantDates: [ImportantDateRecord] = []

    @State private var editingImportantDate: ImportantDateRecord? = nil

    @State private var showImportantDates = false

    @State private var showImportantDateEditor = false

    @State private var importantDate = Date()

    @State private var importantDateType = "契約終了日"

    @State private var importantDateTitle = ""

    @State private var importantDateMemo = ""

    @State private var importantDateToDelete: ImportantDateRecord? = nil

    @State private var showImportantDateDeleteAlert = false

    // 重要日の保存ボタン多重発火を防ぐ

    @State private var isSavingImportantDate = false

    @State private var organizerSavedAlert = false

    let evidenceTypes = ["LINE", "Slack", "メール", "契約書", "勤務指示", "その他"]

    var body: some View {
        Group {
            if horizontalSizeClass == .regular && hasSeenOnboarding {
                NavigationSplitView {
                    List {
                        Button { returnHome() } label: { Label("ホーム", systemImage: "house") }
                        Section("記録・相談準備") {
                            ForEach(WorkspaceDestination.allCases) { destination in
                                Button { openWorkspace(destination) } label: { Label(destination.rawValue, systemImage: destination.icon) }
                            }
                            Button("勤務記録") { openWorkRecords() }
                            Button("証拠・メモ") { openEvidenceRecords() }
                            Button("期限・重要日") { openDeadlines() }
                        }
                        Section("チェック・資料") {
                            Button("働き方チェック") { returnHome(); startCheckFromHome() }
                            Button("フリーランス法チェック") { openLawCheck() }
                            Button("レポート") { returnHome(); showHome = false; showReport = true }
                            Button("相談先・次の行動") { returnHome(); showHome = false; showConsultation = true }
                            Button("設定") { returnHome(); showHome = false; showSettings = true }
                        }
                    }
                    .navigationTitle("守りナビ")
                    .navigationSplitViewColumnWidth(min: 210, ideal: 240, max: 290)
                } detail: { mainContent }
            } else {
                NavigationStack { mainContent }
            }
        }
        .alert("保存データの確認", isPresented: Binding(get: { workspace.errorMessage != nil }, set: { if !$0 { workspace.errorMessage = nil } })) {
            Button("OK", role: .cancel) { workspace.errorMessage = nil }
        } message: { Text(workspace.errorMessage ?? "") }
    }

    var mainContent: some View {

        ScrollView {

            VStack(spacing: 25) {

                if !hasSeenOnboarding {

                    onboardingView

                } else if let destination = workspaceDestination {
                    workspaceScreen(destination)
                } else if showLawHistory {
                    LawCheckHistoryView(store: workspace, onNew: openLawCheck)
                } else if showHome {
                    dashboardView
                    Divider()
                    homeView

                 } else if showImportantDateEditor {

                    importantDateEditorView

                } else if showImportantDates {

                    importantDatesView

                } else if showEvidenceChecklist {

                    evidenceChecklistView

                } else if showPremium && PlusAccessConfig.isPurchasingEnabled {

                    premiumView

                } else if showPrivacyInfo {

                    privacyInfoView

                } else if showDocumentDraft {

                    documentDraftView

                } else if showFreelanceLawCheck {

                    freelanceLawCheckView

                } else if showTroubleGuide {

                    troubleGuideView

                } else if showMessageOrganizer {

                    messageOrganizerView

                } else if showFreeLimitNotice {

            freeLimitNoticeView

        } else if showFirstUseGuide {

            firstUseGuideView

        } else if showSettings {

                    settingsView

                } else if showAbout {

                    aboutView

                } else if showContractGuide {

                    contractGuideView

                } else if showConsultation {

                    consultationView

                } else if showReport {

                    reportView

                } else if editingWorkRecord != nil {

                    workRecordView

                } else if editingEvidenceRecord != nil {

                    evidenceRecordView

                } else if let history = selectedHistory {

                    historyDetailView(history)

                } else if showHistory {

                    historyListView

                } else if showWorkRecordHistory {

                    workRecordHistoryView

                } else if showWorkRecord {

                    workRecordView

                } else if showEvidenceHistory {

                    evidenceHistoryView

                } else if showEvidenceRecord {

                    evidenceRecordView

                } else if isFinished {

                    resultView

                } else {

                    questionView

                }

            }

            .frame(maxWidth: showHome || workspaceDestination != nil ? 1080 : 760)
            .frame(maxWidth: .infinity)
            .padding()
        }
        .background(Color(.systemGroupedBackground))
        .navigationTitle("FreelanceGuard")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            if hasSeenOnboarding && !showHome {
                ToolbarItem(placement: .topBarTrailing) { Button("ホーム") { returnHome() } }
            }
        }
        .onAppear {

            loadHistories()

            loadWorkRecords()

            loadEvidenceRecords()

            loadImportantDates()

        }

        .alert(

            "この結果を削除しますか？",

            isPresented: $showDeleteAlert

        ) {

            Button("キャンセル", role: .cancel) {

            }

            Button("削除", role: .destructive) {

                if let history = selectedHistory {

                    deleteHistory(history)

                }

            }

        } message: {

            Text("削除した結果は元に戻せません。")

        }

        .sheet(isPresented: $showPDFShare) {

            if let pdfURL {

                ShareSheet(items: [pdfURL])

            }

        }

        .alert("PDFを作成できませんでした", isPresented: $showPDFError) {

            Button("OK", role: .cancel) {}

        } message: {

            Text("もう一度お試しください。")

        }

    }





    var activityEntries: [ActivityEntry] {
        WorkspaceActivity.entries(work: workRecords, evidence: evidenceRecords, deadlines: importantDates,
            checks: histories, laws: workspace.lawChecks)
    }

    var dashboardView: some View {
        WorkspaceDashboardView(store: workspace, work: workRecords, evidence: evidenceRecords,
            deadlines: importantDates, checks: histories, entries: activityEntries,
            onDestination: { destination in activityScope = .all; preparationProjectID = nil; openWorkspace(destination) },
            onWork: openWorkRecords, onEvidence: openEvidenceRecords, onDeadlines: openDeadlines,
            onCheck: { returnHome(); startCheckFromHome() }, onLaw: openLawCheck, onEntry: openActivity)
    }

    @ViewBuilder func workspaceScreen(_ destination: WorkspaceDestination) -> some View {
        switch destination {
        case .projects:
            ProjectManagementView(store: workspace, onDelete: deleteProject,
                onTimeline: { id in activityScope = .project(id); openWorkspace(.timeline) },
                onPreparation: { id in preparationProjectID = id; openWorkspace(.preparation) })
        case .timeline:
            ActivityTimelineView(store: workspace, entries: activityEntries, scope: $activityScope, onOpen: openActivity)
        case .search:
            ActivityTimelineView(store: workspace, entries: activityEntries + WorkspaceActivity.entries(work: [], evidence: [], deadlines: [], checks: [], laws: [], projects: workspace.projects),
                isSearch: true, scope: $activityScope, onOpen: openActivity)
        case .preparation:
            ConsultationPreparationView(store: workspace, work: workRecords, entries: activityEntries,
                projectID: $preparationProjectID, onOpen: openActivity, onProjects: { openWorkspace(.projects) })
        }
    }

    func openWorkspace(_ destination: WorkspaceDestination) {
        returnHome(); showHome = false; workspaceDestination = destination
    }
    func openWorkRecords() { returnHome(); showHome = false; showWorkRecordHistory = true }
    func openEvidenceRecords() { returnHome(); showHome = false; showEvidenceHistory = true }
    func openDeadlines() { returnHome(); showHome = false; showImportantDates = true }
    func openLawCheck() { returnHome(); showHome = false; showFreelanceLawCheck = true }

    func openActivity(_ entry: ActivityEntry) {
        returnHome(); showHome = false
        switch entry.kind {
        case .work:
            if let item = workRecords.first(where: { $0.id == entry.recordID }) { startEditingWorkRecord(item) }
            else { showWorkRecordHistory = true }
        case .evidence:
            if let item = evidenceRecords.first(where: { $0.id == entry.recordID }) { startEditingEvidenceRecord(item) }
            else { showEvidenceHistory = true }
        case .deadline:
            if let item = importantDates.first(where: { $0.id == entry.recordID }) { editImportantDate(item) }
            else { showImportantDates = true }
        case .check:
            selectedHistory = histories.first(where: { $0.id == entry.recordID }); showHistory = true
        case .law: showLawHistory = true
        case .project: workspaceDestination = .projects
        }
    }

    func deleteProject(_ id: UUID) {
        guard workspace.deleteProject(id) else { return }
        WorkspaceRecordLinks.detach(id, work: &workRecords, evidence: &evidenceRecords, deadlines: &importantDates)
        saveWorkRecords(); saveEvidenceRecords(); saveImportantDates()
        if preparationProjectID == id { preparationProjectID = nil }
        if activityScope == .project(id) { activityScope = .all }
    }

    var premiumView: some View {

        PremiumView(
            isPlusUnlocked: $isPlusUnlocked,
            storeKitManager: storeKitManager,
            onHome: {
                returnHome()
            }
        )
    }

    var documentDraftView: some View {

        DocumentDraftView(
            documentDraftType: $documentDraftType,
            documentRecipient: $documentRecipient,
            documentSender: $documentSender,
            documentAmount: $documentAmount,
            documentDeadline: $documentDeadline,
            documentFacts: $documentFacts,
            documentRequest: $documentRequest,
            documentDraftText: $documentDraftText,
            documentCopiedAlert: $documentCopiedAlert,
            onBuildDraft: {
                documentDraftText = buildDocumentDraft()
            },
            onCopy: {
                UIPasteboard.general.string = documentDraftText
                documentCopiedAlert = true
            },
            onBuildCertifiedDraft: {
                documentDraftText = buildContentCertifiedDraft()
            },
            onSharePDF: {
                createAndShareDocumentPDF()
            },
            onSaveToEvidence: {
                evidenceProjectID = nil
                evidenceDate = Date()
                evidenceType = "その他"
                evidenceTitle = "文書案：\(documentDraftType)"
                evidenceDetails = documentDraftText
                editingEvidenceRecord = nil
                showDocumentDraft = false
                showEvidenceRecord = true
            },
            onClear: {
                clearDocumentDraft()
            },
            onHome: {
                returnHome()
            }
        )
    }

    func buildDocumentDraft() -> String {

        let recipient = documentRecipient.trimmingCharacters(in: .whitespacesAndNewlines)

        let sender = documentSender.trimmingCharacters(in: .whitespacesAndNewlines)

        let amount = documentAmount.trimmingCharacters(in: .whitespacesAndNewlines)

        let facts = documentFacts.trimmingCharacters(in: .whitespacesAndNewlines)

        let request = documentRequest.trimmingCharacters(in: .whitespacesAndNewlines)

        let deadline = documentDeadline.formatted(date: .numeric, time: .omitted)

        var lines: [String] = []

        lines.append("【\(documentDraftType)】")

        lines.append("")

        if !recipient.isEmpty { lines.append("\(recipient) 様") }

        lines.append("")

        lines.append("下記の件について、確認のためご連絡いたします。")

        lines.append("")

        lines.append("【事実・経緯】")

        lines.append(facts.isEmpty ? "（入力内容を確認してください）" : facts)

        if documentDraftType == "支払いのお願い・督促" && !amount.isEmpty {

            lines.append("")

            lines.append("【金額】")

            lines.append(amount)

        }

        lines.append("")

        lines.append("【お願い・確認事項】")

        lines.append(request.isEmpty ? defaultDocumentRequest(for: documentDraftType) : request)

        lines.append("")

        lines.append("恐れ入りますが、\(deadline)までにご対応またはご回答をお願いいたします。")

        lines.append("")

        lines.append("本連絡は、事実関係およびやり取りの内容を確認・記録する目的も含めてお送りするものです。")

        if !sender.isEmpty {

            lines.append("")

            lines.append(sender)

        }

        return lines.joined(separator: "\n")

    }

    func defaultDocumentRequest(for type: String) -> String {

        switch type {

        case "支払いのお願い・督促":

            return "お支払い状況をご確認のうえ、支払い予定日をご回答ください。"

        case "契約内容の確認":

            return "現在の契約内容について、認識に相違がないかご確認・ご回答ください。"

        case "契約終了・解除の確認":

            return "契約終了・解除に関する日付、理由および今後の取扱いについてご確認・ご回答ください。"

        case "業務条件の確認":

            return "業務内容・時間・場所・報酬等の条件について、現在の取扱いをご確認・ご回答ください。"

        default:

            return "上記内容についてご確認いただき、必要なご回答をお願いいたします。"

        }

    }





    func buildContentCertifiedDraft() -> String {

        let recipient = documentRecipient.trimmingCharacters(in: .whitespacesAndNewlines)

        let sender = documentSender.trimmingCharacters(in: .whitespacesAndNewlines)

        let amount = documentAmount.trimmingCharacters(in: .whitespacesAndNewlines)

        let facts = documentFacts.trimmingCharacters(in: .whitespacesAndNewlines)

        let request = documentRequest.trimmingCharacters(in: .whitespacesAndNewlines)

        let deadline = documentDeadline.formatted(date: .numeric, time: .omitted)

        let today = Date().formatted(date: .numeric, time: .omitted)

        var lines: [String] = []

        lines.append("通知書")

        lines.append("")

        lines.append("作成日：\(today)")

        if !recipient.isEmpty { lines.append("宛先：\(recipient) 様") }

        if !sender.isEmpty { lines.append("差出人：\(sender)") }

        lines.append("")

        lines.append("件名：\(documentDraftType)")

        lines.append("")

        lines.append("【通知内容】")

        lines.append(facts.isEmpty ? "（事実・経緯を入力してください）" : facts)

        if documentDraftType == "支払いのお願い・督促" && !amount.isEmpty {

            lines.append("")

            lines.append("【対象金額】")

            lines.append(amount)

        }

        lines.append("")

        lines.append("【求める対応】")

        lines.append(request.isEmpty ? defaultDocumentRequest(for: documentDraftType) : request)

        lines.append("")

        lines.append("【回答・対応希望日】")

        lines.append(deadline)

        lines.append("")

        lines.append("以上")

        return lines.joined(separator: "\n")

    }

    func createAndShareDocumentPDF() {

        do {

            pdfURL = try createDocumentDraftPDF()

            showPDFShare = true

        } catch {

            showPDFError = true

        }

    }

    func createDocumentDraftPDF() throws -> URL {

        let pageWidth: CGFloat = 595.2

        let pageHeight: CGFloat = 841.8

        let margin: CGFloat = 48

        let contentWidth = pageWidth - margin * 2

        let renderer = UIGraphicsPDFRenderer(bounds: CGRect(x: 0, y: 0, width: pageWidth, height: pageHeight))

        let url = FileManager.default.temporaryDirectory

            .appendingPathComponent("MamoriNavi_Document_\(Int(Date().timeIntervalSince1970)).pdf")

        try renderer.writePDF(to: url) { context in

            var y: CGFloat = margin

            let titleFont = UIFont.boldSystemFont(ofSize: 20)

            let bodyFont = UIFont.systemFont(ofSize: 12)

            let noteFont = UIFont.systemFont(ofSize: 9)

            func draw(_ text: String, font: UIFont, spacing: CGFloat = 8) {

                let style = NSMutableParagraphStyle()

                style.lineBreakMode = .byWordWrapping

                style.lineSpacing = 3

                let attrs: [NSAttributedString.Key: Any] = [

                    .font: font,

                    .foregroundColor: UIColor.black,

                    .paragraphStyle: style

                ]

                let rect = NSString(string: text).boundingRect(

                    with: CGSize(width: contentWidth, height: .greatestFiniteMagnitude),

                    options: [.usesLineFragmentOrigin, .usesFontLeading],

                    attributes: attrs,

                    context: nil

                )

                let h = ceil(rect.height) + 2

                if y + h + spacing > pageHeight - margin {

                    context.beginPage()

                    y = margin

                }

                NSString(string: text).draw(

                    in: CGRect(x: margin, y: y, width: contentWidth, height: h),

                    withAttributes: attrs

                )

                y += h + spacing

            }

            context.beginPage()

            draw("FreelanceGuard｜文書案", font: titleFont, spacing: 16)

            draw(documentDraftText, font: bodyFont, spacing: 18)

            draw("※本PDFは入力内容を整理した文案です。内容証明郵便その他の法的手続への適合や法的効果を保証するものではありません。送付前に事実・金額・期限・宛先を確認し、必要に応じて専門家へ相談してください。", font: noteFont)

        }

        return url

    }

    func clearDocumentDraft() {

        documentRecipient = ""

        documentSender = ""

        documentAmount = ""

        documentDeadline = Date()

        documentFacts = ""

        documentRequest = ""

        documentDraftText = ""

    }

    // MARK: - プライバシー・データ

    var privacyInfoView: some View {

        PrivacyInfoView(
            onHome: {
                returnHome()
            }
        )
    }

    // MARK: - 質問画面

    // MARK: - 無料枠表示

    var workRecordHomeCountText: String { "\(workRecords.count)件" }

    var evidenceHomeCountText: String { "\(evidenceRecords.count)件" }

    // MARK: - ホーム画面

    var homeView: some View {

        HomeView(
            workRecordCountText: workRecordHomeCountText,
            evidenceRecordCountText: evidenceHomeCountText,
            importantDateSubtitle: importantDateHomeSubtitle,
            checkCount: histories.count,
            workRecordCount: workRecords.count,
            evidenceRecordCount: evidenceRecords.count,
            isPlusUnlocked: isPlusUnlocked,
            onFirstUseGuide: {
                showHome = false
                showFirstUseGuide = true
            },
            onStartWorkStyleCheck: {
                startCheckFromHome()
            },
            onOpenFreelanceLawCheck: {
                showHome = false
                showFreelanceLawCheck = true
            },
            onNewWorkRecord: {
                showHome = false
                prepareNewWorkRecord()
            },
            onNewEvidenceRecord: {
                showHome = false
                prepareNewEvidenceRecord()
            },
            onOpenImportantDates: {
                showHome = false
                showImportantDates = true
            },
            onOpenMessageOrganizer: {
                showHome = false
                showMessageOrganizer = true
            },
            onOpenTroubleGuide: {
                showHome = false
                showTroubleGuide = true
            },
            onOpenEvidenceChecklist: {
                showHome = false
                evidenceChecklistCase = 0
                evidenceChecklistAnswers = Array(repeating: false, count: 8)
                showEvidenceChecklist = true
            },
            onOpenConsultation: {
                showHome = false
                showConsultation = true
            },
            onOpenDocumentDraft: {
                showHome = false
                showDocumentDraft = true
            },
            onOpenPremium: {
                showHome = false
                if PlusAccessConfig.isPurchasingEnabled { showPremium = true } else { openWorkspace(.preparation) }
            },
            onOpenReport: {
                showHome = false
                showReport = true
            },
            onOpenContractGuide: {
                showHome = false
                showContractGuide = true
            },
            onOpenPrivacyInfo: {
                showHome = false
                showPrivacyInfo = true
            },
            onOpenSettings: {
                showHome = false
                showSettings = true
            }
        )
    }

    var reportView: some View {

        ReportView(
            checkCount: histories.count,
            workRecordCount: workRecords.count,
            evidenceRecordCount: evidenceRecords.count,
            importantDateCount: importantDates.count,
            latestCheckDate: histories.last?.date,
            latestYesCount: histories.last?.yesCount,
            questionCount: questions.count,
            hasWorkRecords: !workRecords.isEmpty,
            hasEvidenceRecords: !evidenceRecords.isEmpty,
            hasCheckHistories: !histories.isEmpty,
            onShowWorkRecords: {
                showReport = false
                showWorkRecordHistory = true
            },
            onShowEvidenceRecords: {
                showReport = false
                showEvidenceHistory = true
            },
            onShowCheckHistory: {
                showReport = false
                showHistory = true
            },
            onCreatePDF: {
                createAndSharePDF()
            },
            onHome: {
                returnHome()
            }
        )
    }

    // MARK: - 期限・重要日管理

    let importantDateTypes = ["契約終了日", "支払期限", "回答期限", "更新期限", "相談予定日", "その他"]

    var sortedImportantDates: [ImportantDateRecord] {

        importantDates.sorted { $0.date < $1.date }

    }

    var importantDateHomeSubtitle: String {

        let today = Calendar.current.startOfDay(for: Date())

        if let next = sortedImportantDates.first(where: {

            Calendar.current.startOfDay(for: $0.date) >= today

        }) {

            return "次：\(shortDate(next.date))・\(importantDateStatusText(next.date))  \(next.title)"

        }

        return importantDates.isEmpty

            ? "契約終了・支払・回答・更新期限などを管理"

            : "今後の期限はありません"

    }

    func importantDateDays(from date: Date) -> Int {

        let calendar = Calendar.current

        let today = calendar.startOfDay(for: Date())

        let target = calendar.startOfDay(for: date)

        return calendar.dateComponents([.day], from: today, to: target).day ?? 0

    }

    func importantDateStatusText(_ date: Date) -> String {

        let days = importantDateDays(from: date)

        if days < 0 {

            return "\(abs(days))日超過"

        } else if days == 0 {

            return "今日"

        } else if days == 1 {

            return "明日"

        } else {

            return "あと\(days)日"

        }

    }

    func importantDateStatusIcon(_ date: Date) -> String {

        let days = importantDateDays(from: date)

        if days < 0 {

            return "exclamationmark.triangle.fill"

        } else if days <= 3 {

            return "clock.badge.exclamationmark.fill"

        } else {

            return "calendar.badge.clock"

        }

    }

    var importantDatesView: some View {

        ImportantDatesListView(
            records: sortedImportantDates,
            importantDateToDelete: $importantDateToDelete,
            showImportantDateDeleteAlert: $showImportantDateDeleteAlert,
            statusText: { date in
                importantDateStatusText(date)
            },
            statusIcon: { date in
                importantDateStatusIcon(date)
            },
            daysFromToday: { date in
                importantDateDays(from: date)
            },
            fullDateText: { date in
                fullDate(date)
            },
            onEdit: { record in
                editImportantDate(record)
            },
            onDelete: { record in
                importantDates.removeAll { $0.id == record.id }
                saveImportantDates()
            },
            onNew: {
                prepareNewImportantDate()
            },
            onHome: {
                returnHome()
            }
        )
    }

    var importantDateEditorView: some View {

        VStack(spacing: 16) {
            ProjectPicker(projects: workspace.projects, selection: $deadlineProjectID)
        ImportantDateEditorView(
            importantDate: $importantDate,
            importantDateType: $importantDateType,
            importantDateTitle: $importantDateTitle,
            importantDateMemo: $importantDateMemo,
            editingImportantDate: $editingImportantDate,
            importantDateTypes: importantDateTypes,
            statusText: { date in
                importantDateStatusText(date)
            },
            statusIcon: { date in
                importantDateStatusIcon(date)
            },
            daysFromToday: { date in
                importantDateDays(from: date)
            },
            onSave: {
                saveImportantDateRecord()
            },
            onBack: {
                editingImportantDate = nil
                showImportantDateEditor = false
                showImportantDates = true
            }
        )
        }
    }

    func prepareNewImportantDate() {
        deadlineProjectID = nil

        isSavingImportantDate = false

        editingImportantDate = nil

        importantDate = Date()

        importantDateType = "契約終了日"

        importantDateTitle = ""

        importantDateMemo = ""

        showImportantDates = false

        showImportantDateEditor = true

    }

    func editImportantDate(_ record: ImportantDateRecord) {

        isSavingImportantDate = false

        editingImportantDate = record

        deadlineProjectID = record.projectID
        importantDate = record.date

        importantDateType = record.type

        importantDateTitle = record.title

        importantDateMemo = record.memo

        showImportantDates = false

        showImportantDateEditor = true

    }

    func saveImportantDateRecord() {

        // 保存ボタンの多重発火による二重登録を防ぐ。

        guard !isSavingImportantDate else { return }

        let title = importantDateTitle.trimmingCharacters(in: .whitespacesAndNewlines)

        guard !title.isEmpty else { return }

        // Build 4では保存件数を制限しない。

        isSavingImportantDate = true

        if let editing = editingImportantDate {

            if let index = importantDates.firstIndex(where: { $0.id == editing.id }) {

                importantDates[index] = ImportantDateRecord(

                    id: editing.id,

                    date: importantDate,

                    type: importantDateType,

                    title: title,

                    memo: importantDateMemo,
                    projectID: deadlineProjectID

                )

            }

        } else {

            // 同じ日・種類・タイトル・メモの記録がすでにある場合は追加しない。

            // DatePickerは日付のみ表示のため、内部時刻ではなく同日かどうかで比較する。

            let isExactDuplicate = importantDates.contains { record in

                Calendar.current.isDate(record.date, inSameDayAs: importantDate) &&

                record.type == importantDateType &&

                record.title == title &&

                record.memo == importantDateMemo && record.projectID == deadlineProjectID

            }

            guard !isExactDuplicate else {

                isSavingImportantDate = false

                return

            }

            importantDates.append(

                ImportantDateRecord(

                    date: importantDate,

                    type: importantDateType,

                    title: title,

                    memo: importantDateMemo,
                    projectID: deadlineProjectID

                )

            )

        }

        saveImportantDates()

        editingImportantDate = nil

        showImportantDateEditor = false

        showImportantDates = true

    }

    func saveImportantDates() {

        if let data = try? JSONEncoder().encode(importantDates) {

            UserDefaults.standard.set(data, forKey: "importantDates")

        }

    }

    func loadImportantDates() {

        if let data = UserDefaults.standard.data(forKey: "importantDates"),

           let decoded = try? JSONDecoder().decode([ImportantDateRecord].self, from: data) {

            importantDates = decoded

        }

    }

    func shortDate(_ date: Date) -> String {

        let f = DateFormatter()

        f.locale = Locale(identifier: "ja_JP")

        f.dateFormat = "M/d"

        return f.string(from: date)

    }

    func fullDate(_ date: Date) -> String {

        let f = DateFormatter()

        f.locale = Locale(identifier: "ja_JP")

        f.dateFormat = "yyyy/MM/dd"

        return f.string(from: date)

    }

    var evidenceChecklistView: some View {

        EvidenceChecklistView(
            selectedCase: $evidenceChecklistCase,
            answers: $evidenceChecklistAnswers,
            onSaveToMemo: { title, details in

                evidenceProjectID = nil
                evidenceDate = Date()
                evidenceType = "その他"
                evidenceTitle = title
                evidenceDetails = details
                editingEvidenceRecord = nil
                saveEvidenceRecord()
            },
            onOpenMessageOrganizer: {
                showEvidenceChecklist = false
                showMessageOrganizer = true
            },
            onAddEvidence: {
                showEvidenceChecklist = false
                prepareNewEvidenceRecord()
            },
            onHome: {
                returnHome()
            }
        )
    }

    // MARK: - フリーランス法チェック

    var freelanceLawCheckView: some View {

        FreelanceLawCheckView(
            answers: $freelanceLawAnswers,
            onSaveHistory: { summary in
                lawHistorySaved = workspace.saveLawCheck(answers: freelanceLawAnswers, summary: summary)
            },
            onShowHistory: {
                returnHome(); showHome = false; showLawHistory = true
            },
            onSaveResult: { details in
                evidenceProjectID = nil
                evidenceDate = Date()
                evidenceType = "契約書"
                evidenceTitle = "フリーランス法チェック"
                evidenceDetails = details
                editingEvidenceRecord = nil

                // まず証拠・メモ入力画面へ渡し、内容を確認してから保存する。
                // 保存時は既存の入力検証と二重保存防止を適用する。
                showFreelanceLawCheck = false
                showEvidenceRecord = true
            },
            onShowConsultation: {
                showFreelanceLawCheck = false
                showConsultation = true
            },
            onHome: {
                returnHome()
            }
        )
        .alert("チェック履歴を保存しました", isPresented: $lawHistorySaved) { Button("OK", role: .cancel) {} }

    }

    // MARK: - トラブル対応

    var troubleGuideView: some View {

        TroubleGuideView(
            onOpenMessageOrganizer: {
                showTroubleGuide = false
                showMessageOrganizer = true
            },
            onCreateEvidence: {
                showTroubleGuide = false
                prepareNewEvidenceRecord()
            },
            onOpenConsultation: {
                showTroubleGuide = false
                showConsultation = true
            },
            onHome: {
                returnHome()
            }
        )
    }

    var messageOrganizerView: some View {

        MessageOrganizerView(
            organizerText: $organizerText,
            organizerResult: $organizerResult,
            organizerSavedAlert: $organizerSavedAlert,
            onOrganize: {
                organizerResult = organizeMessage(organizerText)
            },
            onSaveToEvidence: {
                

                    evidenceProjectID = nil
                evidenceDate = Date()
                    evidenceType = "その他"
                    evidenceTitle = "文章整理メモ"
                    evidenceDetails = organizerResult + "\n\n【元の文章】\n" + organizerText
                    editingEvidenceRecord = nil
                    saveEvidenceRecord()
                    organizerSavedAlert = true
                
            },
            onClear: {
                organizerText = ""
                organizerResult = ""
            },
            onHome: {
                returnHome()
            }
        )
    }

    func organizeMessage(_ text: String) -> String {

        let source = text.trimmingCharacters(in: .whitespacesAndNewlines)

        guard !source.isEmpty else { return "" }

        var sections: [String] = []

        let dateTokens = regexMatches(in: source, patterns: [

            #"\d{1,2}月\d{1,2}日"#,

            #"(?:今日|明日|昨日|来週|今週|翌日)"#,

            #"(?:毎日|平日)?\s*\d{1,2}時(?:\d{1,2}分)?"#

        ])

        appendOrganizerSection("日時・時刻", items: dateTokens, to: &sections)

        let workTimeRaw = regexMatches(in: source, patterns: [

            #"(?:平日|毎日|土日)?[^。！？\n、]{0,12}\d{1,2}時(?:\d{1,2}分)?(?:から|〜|～|-|－)?[^。！？\n、]{0,12}(?:\d{1,2}時(?:\d{1,2}分)?)?(?:まで|勤務|稼働|出勤|退勤|始業|終業)"#,

            #"(?:勤務|稼働|出勤|退勤|始業|終業|休憩)[^。！？\n、]{0,24}"#

        ])

        let workTime = workTimeRaw.filter { item in

            let trimmed = item.trimmingCharacters(in: .whitespacesAndNewlines)

            let hasTime = trimmed.range(of: #"\d{1,2}時(?:\d{1,2}分)?"#, options: .regularExpression) != nil

            let hasDuration = trimmed.range(of: #"\d+\s*(?:分|時間)"#, options: .regularExpression) != nil

            return hasTime || hasDuration

        }

        appendOrganizerSection("勤務時間", items: workTime, to: &sections)

        let countsRaw = regexMatches(in: source, patterns: [

            #"(?:1日|毎日|週\d+回|月\d+回)?\s*\d+\s*(?:件|回|本|コール)[^。！？\n、]{0,12}(?:架電|コール|必達|目標|ノルマ)?"#,

            #"(?:架電|コール|ノルマ|必達|目標)[^。！？\n、]{0,16}\d+\s*(?:件|回|本)?"#

        ])

        let counts = countsRaw.filter { item in

            !["出社", "在宅", "リモート", "勤務場所"].contains { item.localizedCaseInsensitiveContains($0) }

        }

        appendOrganizerSection("件数・ノルマ", items: counts, to: &sections)

        let instructionClauses = matchingClauses(in: source, keywords: [

            "指示", "求められ", "求める", "してください", "して下さい", "するよう", "必ず", "提出", "参加", "命令"

        ])

        appendOrganizerSection("指示・依頼", items: instructionClauses, to: &sections)

        let locationClauses = matchingClauses(in: source, keywords: [

            "出社", "在宅", "リモート", "オフィス", "拠点", "勤務場所"

        ])

        appendOrganizerSection("出社・勤務場所", items: locationClauses, to: &sections)

        let contractClauses = matchingClauses(in: source, keywords: [

            "契約解除", "契約終了", "解除", "解約", "契約を終了", "アカウント停止", "ツール停止"

        ])

        appendOrganizerSection("契約解除・終了", items: contractClauses, to: &sections)

        if sections.isEmpty {

            return "【整理結果】\n明確に分類できる記述は見つかりませんでした。\n元の文章を確認し、必要な内容は手動で証拠・メモへ保存してください。"

        }

        return sections.joined(separator: "\n\n")

    }

    func regexMatches(in text: String, patterns: [String]) -> [String] {

        var results: [String] = []

        for pattern in patterns {

            guard let regex = try? NSRegularExpression(pattern: pattern) else { continue }

            let range = NSRange(text.startIndex..<text.endIndex, in: text)

            for match in regex.matches(in: text, range: range) {

                guard let swiftRange = Range(match.range, in: text) else { continue }

                let value = String(text[swiftRange]).trimmingCharacters(in: .whitespacesAndNewlines)

                if !value.isEmpty && !results.contains(value) { results.append(value) }

            }

        }

        return results

    }

    func matchingClauses(in text: String, keywords: [String]) -> [String] {

        let separators = CharacterSet(charactersIn: "。！？\n、")

        let clauses = text.components(separatedBy: separators)

            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }

            .filter { !$0.isEmpty }

        var results: [String] = []

        for clause in clauses {

            if keywords.contains(where: { clause.localizedCaseInsensitiveContains($0) }) && !results.contains(clause) {

                results.append(clause)

            }

        }

        return results

    }

    func appendOrganizerSection(_ title: String, items: [String], to sections: inout [String]) {

        let cleaned = items.map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty }

        guard !cleaned.isEmpty else { return }

        sections.append("【\(title)】\n" + cleaned.map { "・\($0)" }.joined(separator: "\n"))

    }

    // MARK: - 設定

    var freeLimitNoticeView: some View {

        FreeLimitNoticeView(
            freeLimitKind: freeLimitKind,
            onOpenPremium: {
                showFreeLimitNotice = false
                if PlusAccessConfig.isPurchasingEnabled { showPremium = true } else { openWorkspace(.preparation) }
            },
            onHome: {
                returnHome()
            }
        )
    }

    var firstUseGuideView: some View {

        FirstUseGuideView(
            onNewWorkRecord: {
                showFirstUseGuide = false
                showWorkRecord = true
            },
            onNewEvidenceRecord: {
                showFirstUseGuide = false
                showEvidenceRecord = true
            },
            onHome: {
                showFirstUseGuide = false
                showHome = true
            }
        )
    }

    func reportRow(
        title: String,
        count: Int,
        icon: String
    ) -> some View {

        HStack {

            Image(systemName: icon)
                .frame(width: 28)

            Text(title)

            Spacer()

            Text("\(count)件")
                .bold()
        }
    }

    var settingsView: some View {

        SettingsView(
            historyCount: histories.count,
            workRecordCount: workRecords.count,
            evidenceRecordCount: evidenceRecords.count,
            onOpenReport: {
                showSettings = false
                showReport = true
            },
            onOpenAbout: {
                showSettings = false
                showAbout = true
            },
            onShowOnboarding: {
                showSettings = false
                showHome = false
                hasSeenOnboarding = false
            },
            onHome: {
                returnHome()
            }
        )
    }

    // MARK: - このアプリについて

    var aboutView: some View {

        AboutView(
            onOpenConsultation: {
                showAbout = false
                showConsultation = true
            },
            onBackToSettings: {
                showAbout = false
                showSettings = true
            }
        )
    }

    // MARK: - 契約の基礎知識

    var contractGuideView: some View {

        ContractGuideView(
            onOpenConsultation: {
                showContractGuide = false
                showConsultation = true
            },
            onHome: {
                returnHome()
            }
        )
    }

    var consultationView: some View {

        ConsultationView(
            onShowReport: {
                showConsultation = false
                showReport = true
            },
            onShowEvidenceChecklist: {
                showConsultation = false
                evidenceChecklistCase = 0
                evidenceChecklistAnswers = Array(repeating: false, count: 8)
                showEvidenceChecklist = true
            },
            onShowImportantDates: {
                showConsultation = false
                showImportantDates = true
            },
            onHome: {
                returnHome()
            }
        )
    }

    var questionView: some View {

        WorkStyleQuestionView(
            questionNumber: questionNumber,
            questions: questions,
            hasHistories: !histories.isEmpty,
            hasWorkRecords: !workRecords.isEmpty,
            hasEvidenceRecords: !evidenceRecords.isEmpty,
            onAnswerYes: {
                answers.append(true)
                yesCount += 1
                nextQuestion()
            },
            onAnswerNo: {
                answers.append(false)
                nextQuestion()
            },
            onOpenHistory: {
                showHistory = true
            },
            onNewWorkRecord: {
                prepareNewWorkRecord()
            },
            onOpenWorkRecords: {
                showWorkRecordHistory = true
            },
            onNewEvidenceRecord: {
                prepareNewEvidenceRecord()
            },
            onOpenEvidenceRecords: {
                showEvidenceHistory = true
            }
        )
    }

    // MARK: - 今回の結果画面

    var resultView: some View {

        WorkStyleResultView(
            questions: questions,
            answers: answers,
            yesCount: yesCount,
            isSaved: isSaved,
            onSave: {
                saveCurrentResult()
            },
            onOpenHistory: {
                showHistory = true
            },
            onOpenConsultation: {
                showConsultation = true
            },
            onReset: {
                resetCheck()
            },
            onHome: {
                returnHome()
            }
        )
    }

    var workRecordHistoryView: some View {

        WorkRecordHistoryView(
            workRecords: workRecords,
            recordToDelete: $recordToDelete,
            showWorkRecordDeleteAlert: $showWorkRecordDeleteAlert,
            onEdit: { record in
                startEditingWorkRecord(record)
            },
            onDelete: { record in
                deleteWorkRecord(record)
            },
            onNew: {
                showWorkRecordHistory = false
                prepareNewWorkRecord()
            },
            onHome: {
                returnHome()
            }
        )
    }

    var workRecordView: some View {

        VStack(spacing: 16) {
            ProjectPicker(projects: workspace.projects, selection: $workProjectID)
        WorkRecordEditorView(
            workDate: $workDate,
            workStartTime: $workStartTime,
            workEndTime: $workEndTime,
            workBreakMinutes: $workBreakMinutes,
            workInstruction: $workInstruction,
            workDetails: $workDetails,
            workMemo: $workMemo,
            editingWorkRecord: $editingWorkRecord,
            showWorkRecordSavedAlert: $showWorkRecordSavedAlert,
            isSavingWorkRecord: $isSavingWorkRecord,
            workRecords: workRecords,
            onSave: {
                saveWorkRecord()
            },
            onShowHistory: {
                editingWorkRecord = nil
                showWorkRecord = false
                showWorkRecordHistory = true
            },
            onHome: {
                editingWorkRecord = nil
                returnHome()
            }
        )
        }
    }

    var evidenceRecordView: some View {

        VStack(spacing: 16) {
            ProjectPicker(projects: workspace.projects, selection: $evidenceProjectID)
        EvidenceRecordEditorView(
            evidenceDate: $evidenceDate,
            evidenceType: $evidenceType,
            evidenceTitle: $evidenceTitle,
            evidenceDetails: $evidenceDetails,
            editingEvidenceRecord: $editingEvidenceRecord,
            showEvidenceSavedAlert: $showEvidenceSavedAlert,
            evidenceTypes: evidenceTypes,
            evidenceRecords: evidenceRecords,
            onSave: {
                saveEvidenceRecord()
            },
            onShowHistory: {
                editingEvidenceRecord = nil
                showEvidenceRecord = false
                showEvidenceHistory = true
            },
            onHome: {
                editingEvidenceRecord = nil
                returnHome()
            }
        )
        }
    }

    var evidenceHistoryView: some View {

        EvidenceHistoryView(
            evidenceRecords: evidenceRecords,
            evidenceToDelete: $evidenceToDelete,
            showEvidenceDeleteAlert: $showEvidenceDeleteAlert,
            onEdit: { record in
                startEditingEvidenceRecord(record)
            },
            onDelete: { record in
                deleteEvidenceRecord(record)
            },
            onNew: {
                showEvidenceHistory = false
                prepareNewEvidenceRecord()
            },
            onHome: {
                returnHome()
            }
        )
    }

    // MARK: - 履歴一覧

    var historyListView: some View {

        CheckHistoryListView(
            histories: histories,
            questionCount: questions.count,
            onSelect: { history in
                selectedHistory = history
            },
            onHome: {
                returnHome()
            }
        )
    }

    // MARK: - 履歴詳細

    func historyDetailView(_ history: CheckHistory) -> some View {

        CheckHistoryDetailView(
            history: history,
            questions: questions,
            onBackToList: {
                selectedHistory = nil
            },
            onHome: {
                returnHome()
            },
            onDelete: {
                showDeleteAlert = true
            }
        )
    }

    // MARK: - 次の質問

    func nextQuestion() {

        if questionNumber < questions.count - 1 {

            questionNumber += 1

        } else {

            isFinished = true

        }

    }

    // MARK: - 結果を保存

    func saveCurrentResult() {

        let history = CheckHistory(

            date: Date(),

            yesCount: yesCount,

            answers: answers

        )

        histories.append(history)

        saveHistories()

        isSaved = true

    }

    // MARK: - 保存データを読み込む

    func loadHistories() {

        guard

            let data = UserDefaults.standard.data(

                forKey: "checkHistories"

            ),

            let saved = try? JSONDecoder().decode(

                [CheckHistory].self,

                from: data

            )

        else {

            return

        }

        histories = saved

    }

    // MARK: - 履歴を削除

    func deleteHistory(

        _ history: CheckHistory

    ) {

        histories.removeAll { item in

            item.id == history.id

        }

        saveHistories()

        selectedHistory = nil

    }

    // MARK: - 履歴をiPhoneに保存

    func saveHistories() {

        if let data = try? JSONEncoder().encode(histories) {

            UserDefaults.standard.set(

                data,

                forKey: "checkHistories"

            )

        }

    }

    // MARK: - 新しい勤務記録を準備

    func prepareNewWorkRecord() {
        workProjectID = nil

        isSavingWorkRecord = false

        editingWorkRecord = nil

        workDate = Date()

        workStartTime = Date()

        workEndTime = Date()

        workBreakMinutes = 60

        workInstruction = ""

        workDetails = ""

        workMemo = ""

        showWorkRecord = true

    }

    // MARK: - 勤務記録の編集を開始

    func startEditingWorkRecord(

        _ record: WorkRecord

    ) {

        isSavingWorkRecord = false

        workProjectID = record.projectID
        workDate = record.date

        workStartTime = record.startTime

        workEndTime = record.endTime

        workBreakMinutes = record.breakMinutes

        workInstruction = record.instruction

        workDetails = record.details

        workMemo = record.memo

        editingWorkRecord = record

    }

    // MARK: - 勤務記録を保存・更新

    func saveWorkRecord() {

        // 保存ボタンの連打などで同じ記録が二重に追加されるのを防ぐ。

        guard !isSavingWorkRecord else { return }

        // Build 4では保存件数を制限しない。

        isSavingWorkRecord = true





        let newRecord = WorkRecord(

            date: workDate,

            startTime: workStartTime,

            endTime: workEndTime,

            instruction: workInstruction,

            details: workDetails,

            breakMinutes: workBreakMinutes,

            memo: workMemo,
            projectID: workProjectID

        )

        if let editingRecord = editingWorkRecord,

           let index = workRecords.firstIndex(

                where: { $0.id == editingRecord.id }

           ) {

            var updatedRecord = newRecord

            updatedRecord.id = editingRecord.id

            workRecords[index] = updatedRecord

        } else {

            // 同一内容・同一日時の記録がすでにある場合は追加しない。

            // 保存ボタンの多重発火や画面イベントの重複による二重保存を防ぐ。

            let isExactDuplicate = workRecords.contains { record in

                record.date == newRecord.date &&

                record.startTime == newRecord.startTime &&

                record.endTime == newRecord.endTime &&

                record.instruction == newRecord.instruction &&

                record.details == newRecord.details &&

                record.breakMinutes == newRecord.breakMinutes &&

                record.memo == newRecord.memo && record.projectID == newRecord.projectID

            }

            guard !isExactDuplicate else {

                isSavingWorkRecord = false

                return

            }

            workRecords.append(newRecord)

        }

        saveWorkRecords()

        editingWorkRecord = nil

        showWorkRecordSavedAlert = true

    }

    // MARK: - 勤務記録をiPhoneに保存

    func saveWorkRecords() {

        if let data = try? JSONEncoder().encode(workRecords) {

            UserDefaults.standard.set(

                data,

                forKey: "workRecords"

            )

        }

    }

    // MARK: - 勤務記録を削除

    func deleteWorkRecord(

        _ record: WorkRecord

    ) {

        workRecords.removeAll {

            $0.id == record.id

        }

        saveWorkRecords()

    }

    // MARK: - 勤務記録を読み込む

    func loadWorkRecords() {

        if let data = UserDefaults.standard.data(

            forKey: "workRecords"

        ),

        let savedRecords = try? JSONDecoder().decode(

            [WorkRecord].self,

            from: data

        ) {

            workRecords = savedRecords

        }

    }









    // MARK: - 新しい証拠・メモを準備

    func prepareNewEvidenceRecord() {
        evidenceProjectID = nil

        isSavingEvidenceRecord = false

        // Build 4では保存件数を制限しない。

        editingEvidenceRecord = nil

        evidenceDate = Date()

        evidenceType = "LINE"

        evidenceTitle = ""

        evidenceDetails = ""

        showEvidenceRecord = true

    }

    // MARK: - 証拠・メモの編集を開始

    func startEditingEvidenceRecord(_ record: EvidenceRecord) {

        isSavingEvidenceRecord = false

        evidenceProjectID = record.projectID
        evidenceDate = record.date

        evidenceType = record.type

        evidenceTitle = record.title

        evidenceDetails = record.details

        editingEvidenceRecord = record

    }

    // MARK: - 証拠・メモを保存・更新

    func saveEvidenceRecord() {

        // 保存ボタンの連打などで同じ記録が二重に追加されるのを防ぐ。

        guard !isSavingEvidenceRecord else { return }

        // Build 4では保存件数を制限しない。

        isSavingEvidenceRecord = true

        let newRecord = EvidenceRecord(

            date: evidenceDate,

            type: evidenceType,

            title: evidenceTitle,

            details: evidenceDetails,
            projectID: evidenceProjectID

        )

        if let editingRecord = editingEvidenceRecord,

           let index = evidenceRecords.firstIndex(where: { $0.id == editingRecord.id }) {

            var updatedRecord = newRecord

            updatedRecord.id = editingRecord.id

            evidenceRecords[index] = updatedRecord

        } else {

            // 同一内容・同一日時の記録がすでにある場合は追加しない。

            let isExactDuplicate = evidenceRecords.contains { record in

                record.date == newRecord.date &&

                record.type == newRecord.type &&

                record.title == newRecord.title &&

                record.details == newRecord.details && record.projectID == newRecord.projectID

            }

            guard !isExactDuplicate else {

                isSavingEvidenceRecord = false

                return

            }

            evidenceRecords.append(newRecord)

        }

        saveEvidenceRecords()

        // 保存完了後は次の保存操作を受け付けられる状態へ戻す。
        // 同一内容の二重保存は上の重複チェックで防止する。
        isSavingEvidenceRecord = false

        editingEvidenceRecord = nil

        showEvidenceSavedAlert = true

    }

    // MARK: - 証拠・メモをiPhoneに保存

    func saveEvidenceRecords() {

        if let data = try? JSONEncoder().encode(evidenceRecords) {

            UserDefaults.standard.set(data, forKey: "evidenceRecords")

        }

    }

    // MARK: - 証拠・メモを削除

    func deleteEvidenceRecord(_ record: EvidenceRecord) {

        evidenceRecords.removeAll { $0.id == record.id }

        saveEvidenceRecords()

    }

    // MARK: - 証拠・メモを読み込む

    func loadEvidenceRecords() {

        if let data = UserDefaults.standard.data(forKey: "evidenceRecords"),

           let savedRecords = try? JSONDecoder().decode([EvidenceRecord].self, from: data) {

            evidenceRecords = savedRecords

        }

    }

    // MARK: - 最初からチェック

    // MARK: - PDFレポート

    func createAndSharePDF() {

        do {

            pdfURL = try createPDFReport()

            showPDFShare = true

        } catch {

            showPDFError = true

        }

    }

    func createPDFReport() throws -> URL {

        // 無料版は「基本PDF」：最新チェック1件・勤務記録5件・証拠メモ5件まで。

        // Plus利用中は保存済みの全履歴をPDFに含める。

        let pdfHistories = isPlusUnlocked ? histories : Array(histories.suffix(1))

        let pdfWorkRecords = isPlusUnlocked ? workRecords : Array(workRecords.suffix(5))

        let pdfEvidenceRecords = isPlusUnlocked ? evidenceRecords : Array(evidenceRecords.suffix(5))

        let allSortedImportantDates = importantDates.sorted { $0.date < $1.date }

        let pdfImportantDates = isPlusUnlocked ? allSortedImportantDates : Array(allSortedImportantDates.prefix(3))

        let pageWidth: CGFloat = 595.2

        let pageHeight: CGFloat = 841.8

        let margin: CGFloat = 42

        let contentWidth = pageWidth - margin * 2

        let renderer = UIGraphicsPDFRenderer(bounds: CGRect(x: 0, y: 0, width: pageWidth, height: pageHeight))

        let url = FileManager.default.temporaryDirectory

            .appendingPathComponent("FreelanceMamoriNavi_Report_\(Int(Date().timeIntervalSince1970)).pdf")

        try renderer.writePDF(to: url) { context in

            var y: CGFloat = margin

            let titleFont = UIFont.boldSystemFont(ofSize: 22)

            let headingFont = UIFont.boldSystemFont(ofSize: 15)

            let bodyFont = UIFont.systemFont(ofSize: 11)

            let smallFont = UIFont.systemFont(ofSize: 9)

            func pageBreak(_ height: CGFloat) {

                if y + height > pageHeight - margin {

                    context.beginPage()

                    y = margin

                }

            }

            func draw(_ text: String, font: UIFont, spacing: CGFloat = 7) {

                let style = NSMutableParagraphStyle()

                style.lineBreakMode = .byWordWrapping

                style.lineSpacing = 2

                let attrs: [NSAttributedString.Key: Any] = [

                    .font: font,

                    .foregroundColor: UIColor.black,

                    .paragraphStyle: style

                ]

                let rect = NSString(string: text).boundingRect(

                    with: CGSize(width: contentWidth, height: .greatestFiniteMagnitude),

                    options: [.usesLineFragmentOrigin, .usesFontLeading],

                    attributes: attrs,

                    context: nil

                )

                let h = ceil(rect.height) + 2

                pageBreak(h + spacing)

                NSString(string: text).draw(

                    in: CGRect(x: margin, y: y, width: contentWidth, height: h),

                    withAttributes: attrs

                )

                y += h + spacing

            }

            func divider() {

                pageBreak(16)

                let path = UIBezierPath()

                path.move(to: CGPoint(x: margin, y: y + 4))

                path.addLine(to: CGPoint(x: pageWidth - margin, y: y + 4))

                UIColor.systemGray4.setStroke()

                path.lineWidth = 0.7

                path.stroke()

                y += 16

            }

            context.beginPage()

            draw("FreelanceGuard", font: titleFont, spacing: 4)

            draw(isPlusUnlocked ? "働き方・勤務記録・証拠メモ・重要日 完全版レポート" : "働き方・勤務記録・証拠メモ・重要日 基本レポート", font: headingFont, spacing: 4)

            draw("作成日時：\(Date().formatted(date: .long, time: .shortened))", font: smallFont, spacing: 4)

            if !isPlusUnlocked {

                draw("無料版：最新チェック1件・勤務記録5件・証拠メモ5件・重要日3件までを収録しています。案件別の整理には相談準備レポートも利用できます。", font: smallFont, spacing: 12)

            }

            draw("※このレポートは記録整理のための資料であり、労働者性や法的権利を判定するものではありません。", font: smallFont, spacing: 12)

            divider()

            draw("1. チェック結果（\(pdfHistories.count)件）", font: headingFont, spacing: 10)

            if pdfHistories.isEmpty {

                draw("保存されたチェック結果はありません。", font: bodyFont)

            } else {

                for (index, history) in pdfHistories.reversed().enumerated() {

                    draw("チェック \(index + 1) \(history.date.formatted(date: .numeric, time: .shortened))", font: bodyFont, spacing: 3)

                    draw("15項目中 \(history.yesCount)項目が該当", font: bodyFont, spacing: 5)

                    for qIndex in questions.indices {

                        let answer = qIndex < history.answers.count && history.answers[qIndex] ? "はい" : "いいえ"

                        draw("\(qIndex + 1). \(questions[qIndex]) 回答：\(answer)", font: smallFont, spacing: 3)

                    }

                    y += 7

                }

            }

            divider()

            draw("2. 勤務記録（\(pdfWorkRecords.count)件）", font: headingFont, spacing: 10)

            if pdfWorkRecords.isEmpty {

                draw("保存された勤務記録はありません。", font: bodyFont)

            } else {

                for (index, record) in pdfWorkRecords.reversed().enumerated() {

                    let minutes = max(0, Int(record.endTime.timeIntervalSince(record.startTime)) / 60 - record.breakMinutes)

                    draw("勤務記録 \(index + 1) \(record.date.formatted(date: .numeric, time: .shortened))", font: bodyFont, spacing: 3)

                    draw("開始：\(record.startTime.formatted(date: .omitted, time: .shortened)) 終了：\(record.endTime.formatted(date: .omitted, time: .shortened)) 勤務：\(minutes / 60)時間\(minutes % 60)分 休憩：\(record.breakMinutes)分", font: smallFont, spacing: 3)

                    draw("会社からの指示：\(record.instruction.isEmpty ? "（記録なし）" : record.instruction)", font: smallFont, spacing: 3)

                    draw("仕事内容・件数：\(record.details.isEmpty ? "（記録なし）" : record.details)", font: smallFont, spacing: 3)

                    draw("メモ：\(record.memo.isEmpty ? "（記録なし）" : record.memo)", font: smallFont, spacing: 8)

                }

            }

            divider()

            draw("3. 証拠・メモ（\(pdfEvidenceRecords.count)件）", font: headingFont, spacing: 10)

            if pdfEvidenceRecords.isEmpty {

                draw("保存された証拠・メモはありません。", font: bodyFont)

            } else {

                for (index, record) in pdfEvidenceRecords.reversed().enumerated() {

                    draw("証拠・メモ \(index + 1) \(record.date.formatted(date: .numeric, time: .shortened))", font: bodyFont, spacing: 3)

                    draw("種類：\(record.type)", font: smallFont, spacing: 3)

                    draw("タイトル：\(record.title)", font: smallFont, spacing: 3)

                    draw("内容：\(record.details.isEmpty ? "（記録なし）" : record.details)", font: smallFont, spacing: 8)

                }

            }

            divider()

            draw("4. 期限・重要日（\(pdfImportantDates.count)件）", font: headingFont, spacing: 10)

            if pdfImportantDates.isEmpty {

                draw("保存された期限・重要日はありません。", font: bodyFont)

            } else {

                for (index, record) in pdfImportantDates.enumerated() {

                    draw("重要日 \(index + 1) \(record.date.formatted(date: .numeric, time: .omitted))", font: bodyFont, spacing: 3)

                    draw("種類：\(record.type)", font: smallFont, spacing: 3)

                    draw("タイトル：\(record.title)", font: smallFont, spacing: 3)

                    draw("状況：\(importantDateStatusText(record.date))", font: smallFont, spacing: 3)

                    draw("メモ：\(record.memo.isEmpty ? "（記録なし）" : record.memo)", font: smallFont, spacing: 8)

                }

            }

            divider()

            draw("このPDFは「FreelanceGuard」に保存されたユーザー入力情報をまとめたものです。", font: smallFont)

        }

        return url

    }

    func startCheckFromHome() {

        questionNumber = 0

        yesCount = 0

        answers = []

        isFinished = false

        isSaved = false

        showHome = false

        showReport = false

        showConsultation = false

    }

    func returnHome() {
        workspaceDestination = nil
        showLawHistory = false

        showFreeLimitNotice = false

        showFirstUseGuide = false

        showHome = true

        showReport = false

        showConsultation = false

        showContractGuide = false

        showSettings = false

        showAbout = false

        showMessageOrganizer = false

        showTroubleGuide = false

        showFreelanceLawCheck = false

        showEvidenceChecklist = false

        showPremium = false

        showPrivacyInfo = false

        showDocumentDraft = false

        showImportantDates = false

        showImportantDateEditor = false

        showHistory = false

        selectedHistory = nil

        showWorkRecord = false

        showWorkRecordHistory = false

        editingWorkRecord = nil

        showEvidenceRecord = false

        showEvidenceHistory = false

        editingEvidenceRecord = nil

    }

    func resetCheck() {

        showHome = false

        showReport = false

        showContractGuide = false

        showConsultation = false

        showSettings = false

        showAbout = false

        showMessageOrganizer = false

        showTroubleGuide = false

        showFreelanceLawCheck = false

        showEvidenceChecklist = false

        showPremium = false

        showPrivacyInfo = false

        showDocumentDraft = false

        showImportantDates = false

        showImportantDateEditor = false

        questionNumber = 0

        yesCount = 0

        answers = []

        isFinished = false

        isSaved = false

        showHistory = false

        selectedHistory = nil

        showWorkRecord = false

        showWorkRecordHistory = false

        editingWorkRecord = nil

        showEvidenceRecord = false

        showEvidenceHistory = false

        editingEvidenceRecord = nil

    }

}

struct ShareSheet: UIViewControllerRepresentable {

    let items: [Any]

    func makeUIViewController(context: Context) -> UIActivityViewController {

        UIActivityViewController(activityItems: items, applicationActivities: nil)

    }

    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}

}

#Preview {

    ContentView()

}
