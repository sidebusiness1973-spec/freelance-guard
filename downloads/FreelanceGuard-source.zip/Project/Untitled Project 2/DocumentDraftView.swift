import SwiftUI

struct DocumentDraftView: View {

    @Binding var documentDraftType: String
    @Binding var documentRecipient: String
    @Binding var documentSender: String
    @Binding var documentAmount: String
    @Binding var documentDeadline: Date
    @Binding var documentFacts: String
    @Binding var documentRequest: String
    @Binding var documentDraftText: String
    @Binding var documentCopiedAlert: Bool

    let onBuildDraft: () -> Void
    let onCopy: () -> Void
    let onBuildCertifiedDraft: () -> Void
    let onSharePDF: () -> Void
    let onSaveToEvidence: () -> Void
    let onClear: () -> Void
    let onHome: () -> Void

    var body: some View {

        VStack(spacing: 22) {

            VStack(spacing: 10) {

                ZStack {

                    Circle()
                        .fill(Color.blue.opacity(0.10))
                        .frame(width: 82, height: 82)

                    Image(systemName: "doc.text.fill")
                        .font(.system(size: 36, weight: .semibold))
                        .foregroundStyle(.blue)
                }

                Text("文書作成サポート")
                    .font(.largeTitle)
                    .bold()

                Text("自分で連絡・通知するときの情報を整理して、文案のたたき台を作ります")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }

            VStack(alignment: .leading, spacing: 14) {

                Text("文書の目的")
                    .font(.headline)

                Picker("文書の目的", selection: $documentDraftType) {

                    Text("支払いのお願い・督促")
                        .tag("支払いのお願い・督促")

                    Text("契約内容の確認")
                        .tag("契約内容の確認")

                    Text("契約終了・解除の確認")
                        .tag("契約終了・解除の確認")

                    Text("業務条件の確認")
                        .tag("業務条件の確認")

                    Text("記録を残すための通知")
                        .tag("記録を残すための通知")
                }
                .pickerStyle(.menu)

                documentInputField(
                    "宛先",
                    text: $documentRecipient,
                    prompt: "会社名・担当者名など"
                )

                documentInputField(
                    "差出人",
                    text: $documentSender,
                    prompt: "氏名・屋号など"
                )

                if documentDraftType == "支払いのお願い・督促" {

                    documentInputField(
                        "請求・確認する金額",
                        text: $documentAmount,
                        prompt: "例：120,000円"
                    )
                }

                VStack(alignment: .leading, spacing: 7) {

                    Text("回答・支払いを希望する日")
                        .font(.subheadline)
                        .bold()

                    DatePicker(
                        "",
                        selection: $documentDeadline,
                        displayedComponents: .date
                    )
                    .labelsHidden()
                }

                VStack(alignment: .leading, spacing: 7) {

                    Text("事実・経緯")
                        .font(.subheadline)
                        .bold()

                    TextField(
                        "例：○月○日に業務を行い、○月○日が支払期限でした。",
                        text: $documentFacts,
                        axis: .vertical
                    )
                    .lineLimit(5...10)
                    .textFieldStyle(.roundedBorder)
                }

                VStack(alignment: .leading, spacing: 7) {

                    Text("相手に求めたいこと")
                        .font(.subheadline)
                        .bold()

                    TextField(
                        "例：支払い予定日をご回答ください。",
                        text: $documentRequest,
                        axis: .vertical
                    )
                    .lineLimit(3...8)
                    .textFieldStyle(.roundedBorder)
                }
            }
            .padding(18)
            .background(Color.gray.opacity(0.08))
            .clipShape(RoundedRectangle(cornerRadius: 20))

            Button {
                onBuildDraft()
            } label: {
                Label("文案を作成", systemImage: "wand.and.stars")
                    .bold()
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.large)
            .disabled(
                documentFacts
                    .trimmingCharacters(in: .whitespacesAndNewlines)
                    .isEmpty
                &&
                documentRequest
                    .trimmingCharacters(in: .whitespacesAndNewlines)
                    .isEmpty
            )

            if !documentDraftText.isEmpty {

                VStack(alignment: .leading, spacing: 12) {

                    Label("文案プレビュー", systemImage: "doc.plaintext")
                        .font(.headline)
                        .foregroundStyle(.blue)

                    Text(documentDraftText)
                        .font(.body)
                        .textSelection(.enabled)
                        .frame(maxWidth: .infinity, alignment: .leading)

                    Button {
                        onCopy()
                    } label: {
                        Label("文案をコピー", systemImage: "doc.on.doc")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.bordered)

                    Button {
                        onBuildCertifiedDraft()
                    } label: {
                        Label(
                            "内容証明向けに整理",
                            systemImage: "envelope.badge.shield.half.filled"
                        )
                        .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.bordered)

                    Button {
                        onSharePDF()
                    } label: {
                        Label(
                            "文案をPDFで共有・保存",
                            systemImage: "doc.richtext"
                        )
                        .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.bordered)

                    Text("「内容証明向けに整理」は、宛先・差出人・日付・事実・求める内容を読みやすく並べる補助機能です。郵便局の内容証明の文字数・行数等の形式要件への適合を保証するものではありません。")
                        .font(.caption2)
                        .foregroundStyle(.secondary)

                    Button {
                        onSaveToEvidence()
                    } label: {
                        Label(
                            "証拠・メモへ保存して確認",
                            systemImage: "tray.and.arrow.down.fill"
                        )
                        .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                }
                .padding(18)
                .background(Color.blue.opacity(0.06))
                .clipShape(RoundedRectangle(cornerRadius: 20))
            }

            VStack(alignment: .leading, spacing: 9) {

                Label(
                    "内容証明などに使う前に",
                    systemImage: "exclamationmark.shield.fill"
                )
                .font(.headline)
                .foregroundStyle(.blue)

                Text("この機能は、ユーザーが入力した情報から文案のたたき台を作るためのものです。法的判断や、特定の手続に適合することを保証するものではありません。重要な請求・通知に使う場合は、事実関係・金額・期限・送付先を必ずご自身で確認し、必要に応じて弁護士などの専門家へ相談してください。")
                    .font(.caption)
                    .foregroundStyle(.secondary)

                Text("元の契約書・請求書・LINE・Slack・メールなども、文案とは別に保存しておくことをおすすめします。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(16)
            .background(Color.gray.opacity(0.08))
            .clipShape(RoundedRectangle(cornerRadius: 16))

            Button("入力をクリア") {
                onClear()
            }
            .buttonStyle(.bordered)

            Button("ホームに戻る") {
                onHome()
            }
            .buttonStyle(.bordered)
        }
        .padding(.horizontal, 4)
        .alert(
            "コピーしました",
            isPresented: $documentCopiedAlert
        ) {
            Button("OK", role: .cancel) {}
        } message: {
            Text("文案をクリップボードへコピーしました。送信前に内容を確認してください。")
        }
    }

    private func documentInputField(
        _ title: String,
        text: Binding<String>,
        prompt: String
    ) -> some View {

        VStack(alignment: .leading, spacing: 7) {

            Text(title)
                .font(.subheadline)
                .bold()

            TextField(prompt, text: text)
                .textFieldStyle(.roundedBorder)
        }
    }
}
