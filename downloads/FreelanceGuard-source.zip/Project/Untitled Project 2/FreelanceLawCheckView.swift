import SwiftUI

struct FreelanceLawCheckView: View {

    @Binding var answers: [Bool]

    let onSaveHistory: (String) -> Void
    let onShowHistory: () -> Void
    let onSaveResult: (String) -> Void
    let onShowConsultation: () -> Void
    let onHome: () -> Void

    private let titles = [
        "取引条件",
        "報酬の支払い",
        "不当な取扱い",
        "募集情報",
        "育児・介護との両立",
        "ハラスメント対策",
        "中途解除・不更新"
    ]

    private let items = [
        (
            "取引条件",
            "業務内容・報酬額・支払期日などが、書面・メール・SNSメッセージ等で明示されている"
        ),
        (
            "報酬の支払い",
            "報酬の支払期日が具体的に示され、期日どおりに支払われている"
        ),
        (
            "不当な取扱い",
            "報酬の一方的な減額、不当なやり直し、購入・利用の強制などがない"
        ),
        (
            "募集情報",
            "募集時に示された仕事内容・報酬・就業場所などの情報が正確で、誤解を招く表示になっていない"
        ),
        (
            "育児・介護との両立",
            "継続的な業務委託の場合、育児・介護等との両立について必要な配慮を申し出られる環境がある"
        ),
        (
            "ハラスメント対策",
            "ハラスメントの相談窓口や、相談に対応するための体制について確認できる"
        ),
        (
            "中途解除・不更新",
            "長期の業務委託を解除・不更新とする場合の予告や、理由確認について必要な対応がされている"
        )
    ]

    var body: some View {

        VStack(spacing: 18) {

            VStack(spacing: 7) {

                Image(systemName: "checkmark.seal.fill")
                    .font(.system(size: 38, weight: .semibold))

                Text("フリーランス法チェック")
                    .font(.title2)
                    .bold()

                Text("取引条件や発注者の対応について、自分の状況を7項目で確認します")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }

            ForEach(items.indices, id: \.self) { index in

                freelanceLawItem(
                    index,
                    items[index].0,
                    items[index].1
                )
            }

            let confirmed = answers.filter { $0 }.count

            VStack(spacing: 7) {

                Text("確認できた項目")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)

                Text("\(confirmed) / 7")
                    .font(.title)
                    .bold()

                Text("チェック数だけで法令違反の有無を判定するものではありません。適用される義務は、発注者や取引期間などの条件によって異なります。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }
            .frame(maxWidth: .infinity)
            .padding()
            .background(Color.gray.opacity(0.09))
            .cornerRadius(16)

            VStack(alignment: .leading, spacing: 9) {

                Label(
                    "覚えておきたいポイント",
                    systemImage: "lightbulb.fill"
                )
                .font(.headline)

                Text("・取引条件は、原則として業務委託時に書面または電磁的方法で明示されます。")

                Text("・報酬の支払期日は、原則として給付を受領した日等から60日以内のできる限り短い期間内で設定されます。")

                Text("・1か月以上の業務委託では、受領拒否・報酬減額・買いたたき等の禁止行為に関する規定があります。")

                Text("・6か月以上の業務委託の解除・不更新では、例外を除き30日前までの予告や、請求時の理由開示に関する規定があります。")
            }
            .font(.subheadline)
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding()
            .background(Color.gray.opacity(0.09))
            .cornerRadius(16)

            VStack(spacing: 10) {
                Button("チェック履歴に保存") { onSaveHistory(resultText) }.buttonStyle(.borderedProminent)
                Button("保存済みのチェック履歴") { onShowHistory() }.buttonStyle(.bordered)


                Button {

                    onSaveResult(resultText)

                } label: {

                    Label(
                        "結果を証拠・メモに保存",
                        systemImage: "square.and.arrow.down"
                    )
                    .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .disabled(confirmed == 0)

                Button {

                    onShowConsultation()

                } label: {

                    Label(
                        "相談先・次の行動を見る",
                        systemImage: "questionmark.bubble.fill"
                    )
                    .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
            }

            Text("※フリーランス法（特定受託事業者に係る取引の適正化等に関する法律）に関する一般的な確認機能です。個別の適用関係や違反の有無を判定するものではありません。")
                .font(.caption)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)

            Button("ホームに戻る") {
                onHome()
            }
            .buttonStyle(.bordered)
        }
        .onAppear {
            ensureAnswerCapacity()
        }
    }

    private var resultText: String {

        let confirmed = answers.filter { $0 }.count

        let checked = answers.enumerated()
            .filter { $0.element && titles.indices.contains($0.offset) }
            .map { titles[$0.offset] }

        let unchecked = answers.enumerated()
            .filter { !$0.element && titles.indices.contains($0.offset) }
            .map { titles[$0.offset] }

        var lines: [String] = [
            "確認できた項目：\(confirmed) / 7"
        ]

        if !checked.isEmpty {
            lines.append("")
            lines.append("確認できた項目：")
            lines.append(contentsOf: checked.map { "・\($0)" })
        }

        if !unchecked.isEmpty {
            lines.append("")
            lines.append("未確認・要確認の項目：")
            lines.append(contentsOf: unchecked.map { "・\($0)" })
        }

        return lines.joined(separator: "\n")
    }

    private func freelanceLawItem(
        _ index: Int,
        _ title: String,
        _ detail: String
    ) -> some View {

        Button {

            ensureAnswerCapacity()
            answers[index].toggle()

        } label: {

            HStack(alignment: .top, spacing: 12) {

                Image(
                    systemName:
                        isChecked(index)
                        ? "checkmark.circle.fill"
                        : "circle"
                )
                .font(.title3)

                VStack(alignment: .leading, spacing: 5) {

                    Text(title)
                        .font(.headline)

                    Text(detail)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }

                Spacer()
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding()
            .background(Color.gray.opacity(0.09))
            .cornerRadius(16)
        }
        .buttonStyle(.plain)
    }

    private func isChecked(_ index: Int) -> Bool {
        guard answers.indices.contains(index) else {
            return false
        }
        return answers[index]
    }

    private func ensureAnswerCapacity() {
        if answers.count < 7 {
            answers += Array(
                repeating: false,
                count: 7 - answers.count
            )
        }
    }
}
