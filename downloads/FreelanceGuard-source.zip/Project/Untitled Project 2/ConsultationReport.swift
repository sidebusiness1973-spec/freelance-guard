import Foundation

struct ConsultationReportDocument {
    struct Section {
        var title: String
        var body: String
    }
    var createdAt: Date
    var sections: [Section]
    var plainText: String {
        "相談準備レポート\n作成日時：\(createdAt.formatted(date: .numeric, time: .shortened))\n\n"
            + sections.map { "【\($0.title)】\n\($0.body)" }.joined(separator: "\n\n")
    }
    static func make(projectID: UUID?, projects: [ProjectContract], work: [WorkRecord],
                     entries: [ActivityEntry], preparation: ConsultationPreparation, now: Date = Date()) -> Self {
        let chosenProjects = projects.filter { projectID == nil || $0.id == projectID }
        let chosenWork = work.filter { projectID == nil || $0.projectID == projectID }
        let records = WorkspaceActivity.filtered(entries.filter { entry in
            projectID == nil || entry.projectID == projectID || entry.kind == .check || entry.kind == .law
        }, newestFirst: false)
        var sections: [Section] = [
            .init(title: "資料の目的", body: "利用者自身の記録整理・相談準備を支援する資料です。記載された事実は利用者の入力内容です。法的な結論、法律相談、違反の判定を行うものではありません。\n対象：\(projectID.flatMap { id in projects.first(where: { $0.id == id })?.name } ?? "すべての案件・案件なし")\n働き方・フリーランス法チェックは案件別に保存していないため、全体の履歴として収録します。"),
            .init(title: "案件・契約情報", body: chosenProjects.isEmpty ? "案件登録なし" : chosenProjects.map(\.summary).joined(separator: "\n\n")),
            .init(title: "勤務記録の概要", body: "\(chosenWork.count)件・合計\(WorkspaceFormat.duration(chosenWork.reduce(0) { $0 + $1.workedMinutes() }))\n休憩を差し引き、終了が開始より前の場合は翌日終了として集計しています。")
        ]
        for kind in [ActivityKind.work, .evidence, .deadline, .check, .law] {
            let category = records.filter { $0.kind == kind }
            let body = category.map { entry in
                let project = projects.first(where: { $0.id == entry.projectID })?.name ?? "案件なし"
                return "\(WorkspaceFormat.date(entry.date))　\(entry.title)\n\(project)\n\(entry.details)"
            }.joined(separator: "\n\n")
            sections.append(.init(title: kind.rawValue, body: category.isEmpty ? "保存済みの記録なし" : body))
        }
        sections.append(.init(title: "相談準備チェック状況", body: ConsultationPreparation.labels.enumerated().map {
            "\(preparation.isChecked($0.offset) ? "確認済み" : "未確認")：\($0.element)"
        }.joined(separator: "\n")))
        sections.append(.init(title: "相談したい内容", body: preparation.question.isEmpty ? "未入力" : preparation.question))
        return Self(createdAt: now, sections: sections)
    }
}
