import SwiftUI

struct ReportView: View {

    let checkCount: Int
    let workRecordCount: Int
    let evidenceRecordCount: Int
    let importantDateCount: Int

    let latestCheckDate: Date?
    let latestYesCount: Int?
    let questionCount: Int

    let hasWorkRecords: Bool
    let hasEvidenceRecords: Bool
    let hasCheckHistories: Bool

    let onShowWorkRecords: () -> Void
    let onShowEvidenceRecords: () -> Void
    let onShowCheckHistory: () -> Void
    let onCreatePDF: () -> Void
    let onHome: () -> Void

    var body: some View {

        VStack(spacing: 18) {

            VStack(spacing: 7) {

                Image(systemName: "chart.bar.doc.horizontal.fill")
                    .font(.system(size: 36, weight: .semibold))

                Text("レポート")
                    .font(.title2)
                    .bold()

                Text("保存した情報をまとめて確認・PDF出力できます")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }

            VStack(alignment: .leading, spacing: 14) {

                Label("保存データ", systemImage: "externaldrive.fill")
                    .font(.headline)

                reportRow(
                    title: "チェック結果",
                    count: checkCount,
                    icon: "checkmark.shield"
                )

                Divider()

                reportRow(
                    title: "勤務記録",
                    count: workRecordCount,
                    icon: "clock"
                )

                Divider()

                reportRow(
                    title: "証拠・メモ",
                    count: evidenceRecordCount,
                    icon: "doc.text"
                )

                Divider()

                reportRow(
                    title: "期限・重要日",
                    count: importantDateCount,
                    icon: "calendar.badge.clock"
                )
            }
            .padding()
            .background(Color.gray.opacity(0.09))
            .cornerRadius(16)

            if let latestCheckDate,
               let latestYesCount {

                VStack(alignment: .leading, spacing: 9) {

                    Label(
                        "最新のチェック結果",
                        systemImage: "checkmark.circle.fill"
                    )
                    .font(.headline)

                    Text(
                        latestCheckDate.formatted(
                            date: .long,
                            time: .shortened
                        )
                    )
                    .font(.subheadline)
                    .foregroundStyle(.secondary)

                    Text(
                        "\(questionCount)項目中 \(latestYesCount)項目が該当"
                    )
                    .font(.title3)
                    .bold()

                    Text("法的な判定ではなく、回答内容を整理した結果です。")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding()
                .background(Color.gray.opacity(0.09))
                .cornerRadius(16)
            }

            VStack(spacing: 10) {

                if hasWorkRecords {

                    Button {
                        onShowWorkRecords()
                    } label: {
                        Label(
                            "勤務記録を見る",
                            systemImage: "clock.arrow.circlepath"
                        )
                        .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.bordered)
                }

                if hasEvidenceRecords {

                    Button {
                        onShowEvidenceRecords()
                    } label: {
                        Label(
                            "証拠・メモを見る",
                            systemImage: "doc.text.magnifyingglass"
                        )
                        .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.bordered)
                }

                if hasCheckHistories {

                    Button {
                        onShowCheckHistory()
                    } label: {
                        Label(
                            "チェック履歴を見る",
                            systemImage: "list.bullet.clipboard"
                        )
                        .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.bordered)
                }
            }

            VStack(spacing: 9) {

                Button {
                    onCreatePDF()
                } label: {
                    Label(
                        "PDFレポートを作成・共有",
                        systemImage: "square.and.arrow.up.fill"
                    )
                    .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)

                Text("チェック結果・勤務記録・証拠メモ・期限・重要日を1つのPDFにまとめます。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }
            .padding()
            .background(Color.gray.opacity(0.07))
            .cornerRadius(16)

            Button("ホームに戻る") {
                onHome()
            }
            .buttonStyle(.bordered)
        }
    }

    private func reportRow(
        title: String,
        count: Int,
        icon: String
    ) -> some View {

        HStack {

            Image(systemName: icon)
                .frame(width: 28)

            Text(title)

            Spacer()

            Text("\(count)件")
                .bold()
        }
    }
}
