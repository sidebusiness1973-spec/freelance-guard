import SwiftUI

struct EvidenceChecklistView: View {

    @Binding var selectedCase: Int
    @Binding var answers: [Bool]

    let onSaveToMemo: (String, String) -> Void
    let onOpenMessageOrganizer: () -> Void
    let onAddEvidence: () -> Void
    let onHome: () -> Void

    private let caseNames = [
        "契約解除・アカウント停止",
        "報酬未払い・支払遅延",
        "勤務時間・シフト指定",
        "出社・勤務場所指定",
        "件数・ノルマ・具体的指示",
        "契約内容と実態の違い"
    ]

    var body: some View {

        VStack(spacing: 18) {

            VStack(spacing: 7) {

                Image(systemName: "checklist.checked")
                    .font(.system(size: 38, weight: .semibold))

                Text("証拠チェックリスト")
                    .font(.title2)
                    .bold()

                Text("手元にある記録と、まだ確認できていない記録を整理します")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }

            VStack(alignment: .leading, spacing: 8) {

                Text("ケース")
                    .font(.caption)
                    .bold()
                    .foregroundStyle(.secondary)

                Picker("ケース", selection: $selectedCase) {

                    ForEach(caseNames.indices, id: \.self) { index in
                        Text(caseNames[index]).tag(index)
                    }
                }
                .pickerStyle(.menu)
                .onChange(of: selectedCase) {
                    answers = Array(repeating: false, count: 8)
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding()
            .background(Color.gray.opacity(0.09))
            .cornerRadius(16)

            ForEach(Array(currentItems.enumerated()), id: \.offset) { index, item in

                Button {

                    ensureAnswerCapacity()
                    answers[index].toggle()

                } label: {

                    HStack(alignment: .top, spacing: 12) {

                        Image(
                            systemName:
                                isChecked(index)
                                ? "checkmark.circle.fill"
                                : "circle"
                        )
                        .font(.title3)
                        .foregroundStyle(
                            isChecked(index) ? .blue : .secondary
                        )

                        VStack(alignment: .leading, spacing: 4) {

                            Text(item.0)
                                .font(.headline)
                                .foregroundStyle(.primary)

                            Text(item.1)
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }

                        Spacer()
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding()
                    .background(
                        isChecked(index)
                        ? Color.blue.opacity(0.07)
                        : Color.gray.opacity(0.09)
                    )
                    .cornerRadius(16)
                }
                .buttonStyle(.plain)
            }

            VStack(spacing: 8) {

                Text("確認状況")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)

                Text("\(checkedCount) / \(currentItems.count)")
                    .font(.title)
                    .bold()

                ProgressView(
                    value: Double(checkedCount),
                    total: Double(max(1, currentItems.count))
                )
                .tint(.blue)

                Text("これは証拠の強さを点数化するものではありません。手元にある記録と不足している記録を整理するための表示です。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }
            .frame(maxWidth: .infinity)
            .padding()
            .background(Color.gray.opacity(0.09))
            .cornerRadius(16)

            VStack(alignment: .leading, spacing: 12) {

                Label(
                    "揃っている記録",
                    systemImage: "checkmark.circle.fill"
                )
                .font(.headline)
                .foregroundStyle(.blue)

                if availableItems.isEmpty {

                    Text("まだチェックされていません")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)

                } else {

                    ForEach(
                        Array(availableItems.enumerated()),
                        id: \.offset
                    ) { _, item in

                        Label(item.0, systemImage: "checkmark")
                            .font(.subheadline)
                    }
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding()
            .background(Color.blue.opacity(0.06))
            .cornerRadius(16)

            VStack(alignment: .leading, spacing: 12) {

                Label(
                    "まだ確認したい記録",
                    systemImage: "magnifyingglass.circle.fill"
                )
                .font(.headline)

                if missingItems.isEmpty {

                    Label(
                        "チェック項目はすべて確認済みです",
                        systemImage: "checkmark.seal.fill"
                    )
                    .font(.subheadline)
                    .foregroundStyle(.blue)

                } else {

                    ForEach(
                        Array(missingItems.enumerated()),
                        id: \.offset
                    ) { _, item in

                        VStack(alignment: .leading, spacing: 3) {

                            Text("・\(item.0)")
                                .font(.subheadline)
                                .bold()

                            Text(item.1)
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding()
            .background(Color.gray.opacity(0.09))
            .cornerRadius(16)

            VStack(alignment: .leading, spacing: 8) {

                Label(
                    "次にやること",
                    systemImage: "arrow.right.circle.fill"
                )
                .font(.headline)
                .foregroundStyle(.blue)

                Text(nextActionText)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding()
            .background(Color.blue.opacity(0.06))
            .cornerRadius(16)

            VStack(spacing: 10) {

                Button {

                    onSaveToMemo(
                        "証拠チェック：\(caseNames[safeCaseIndex])",
                        memoText
                    )

                } label: {

                    Label(
                        "チェック結果をメモに保存",
                        systemImage: "square.and.arrow.down"
                    )
                    .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)

                Button {
                    onOpenMessageOrganizer()
                } label: {
                    Label(
                        "メッセージ文章を整理する",
                        systemImage: "text.viewfinder"
                    )
                    .frame(maxWidth: .infinity)
                }
                .buttonStyle(.bordered)

                Button {
                    onAddEvidence()
                } label: {
                    Label(
                        "証拠・メモを追加する",
                        systemImage: "doc.badge.plus"
                    )
                    .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
            }

            Text("※このチェックリストは記録整理を支援するもので、証拠能力、法的評価、請求の可否や結果を判定するものではありません。元データは可能な限り元の形式でも保管してください。")
                .font(.caption)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)

            Button("ホームに戻る") {
                onHome()
            }
            .buttonStyle(.bordered)
        }
        .onAppear {
            ensureAnswerCapacity()
        }
    }

    private var safeCaseIndex: Int {
        min(max(selectedCase, 0), caseNames.count - 1)
    }

    private var checkedCount: Int {
        currentItems.indices.filter { isChecked($0) }.count
    }

    private var availableItems: [(String, String)] {
        currentItems.enumerated()
            .filter { isChecked($0.offset) }
            .map { $0.element }
    }

    private var missingItems: [(String, String)] {
        currentItems.enumerated()
            .filter { !isChecked($0.offset) }
            .map { $0.element }
    }

    private var nextActionText: String {

        if missingItems.isEmpty {
            return "チェック項目はすべて確認済みです。元データを削除・加工せず保管し、必要に応じて時系列やPDFにまとめておきましょう。"
        }

        let first = missingItems[0].0

        return "まず「\(first)」が残っていないか、LINE・Slack・メール・カレンダー・契約書・端末内の画像などを確認してみましょう。見つからない場合は、覚えている事実を日付入りのメモとして残しておく方法もあります。"
    }

    private var memoText: String {

        let available = availableItems.map { "・\($0.0)" }
        let missing = missingItems.map { "・\($0.0)" }

        var sections: [String] = []

        sections.append("【確認済み】")
        sections.append(
            available.isEmpty
            ? "・なし"
            : available.joined(separator: "\n")
        )

        sections.append("")
        sections.append("【未確認・未保存】")
        sections.append(
            missing.isEmpty
            ? "・なし"
            : missing.joined(separator: "\n")
        )

        sections.append("")
        sections.append("【次にやること】")
        sections.append(nextActionText)

        return sections.joined(separator: "\n")
    }

    private func isChecked(_ index: Int) -> Bool {
        guard answers.indices.contains(index) else {
            return false
        }

        return answers[index]
    }

    private func ensureAnswerCapacity() {
        if answers.count < 8 {
            answers += Array(
                repeating: false,
                count: 8 - answers.count
            )
        }
    }

    private var currentItems: [(String, String)] {

        switch safeCaseIndex {

        case 0:
            return [
                ("契約書・発注書", "契約期間、解除・更新条件が確認できるもの"),
                ("解除・終了の通知", "LINE・Slack・メールなど、通知日時と内容が分かるもの"),
                ("アカウント停止の記録", "利用できなくなった日時や画面、連絡内容"),
                ("勤務予定・シフト", "解除後も予定されていた業務が分かるもの"),
                ("カレンダー・会議予定", "定例会議や今後の予定が入っていた記録"),
                ("それまでの業務実績", "日報、成果物、架電記録など稼働が分かるもの"),
                ("解除前後のやり取り", "話し合い・指摘・回答など経緯が分かるもの"),
                ("報酬・請求資料", "報酬条件、請求書、未精算分が分かるもの")
            ]

        case 1:
            return [
                ("契約書・発注書", "報酬額と支払条件が分かるもの"),
                ("請求書", "請求日、金額、支払期日が分かるもの"),
                ("納品・業務完了記録", "業務を実施したことが分かるもの"),
                ("勤務・稼働記録", "日時と業務内容を確認できるもの"),
                ("支払予定の連絡", "振込予定日など相手の説明が分かるもの"),
                ("催促・問い合わせ履歴", "未払いについて連絡した日時と内容"),
                ("入金履歴", "実際の入金日・金額を確認できるもの"),
                ("報酬変更の連絡", "減額や条件変更があれば、その経緯が分かるもの")
            ]

        case 2:
            return [
                ("契約書・募集条件", "本来の稼働時間・曜日条件が分かるもの"),
                ("シフト表", "提出・承認された勤務予定"),
                ("タイムカード・勤怠", "開始・終了・休憩が分かるもの"),
                ("定例会議予定", "参加日時や頻度が分かるカレンダー等"),
                ("開始・終了の指示", "何時から何時まで等の連絡"),
                ("休暇に関する連絡", "休みの申請・承認等のやり取り"),
                ("日報・業務報告", "日々の稼働状況が分かるもの"),
                ("条件変更の経緯", "当初条件から変更された場合の連絡")
            ]

        case 3:
            return [
                ("契約書・募集条件", "在宅・出社など当初条件が分かるもの"),
                ("出社指示", "出社日・場所を指定された連絡"),
                ("前日・当日の確認", "出社確認や到着報告などのやり取り"),
                ("カレンダー", "出社予定・会議場所が分かるもの"),
                ("交通・入館記録", "必要に応じて実際の出社を確認できる記録"),
                ("勤務場所変更の連絡", "リモートから出社等への変更経緯"),
                ("出社頻度の記録", "週何回など実態を整理した記録"),
                ("場所指定に関する説明", "指定理由や運用ルールが分かるもの")
            ]

        case 4:
            return [
                ("件数目標・必達指示", "架電数・処理件数等の数値が分かるもの"),
                ("業務マニュアル", "具体的な進め方が指定された資料"),
                ("チャットの業務指示", "日々の指示・修正・確認が分かるもの"),
                ("ロープレ・研修記録", "参加日時や指導内容が分かるもの"),
                ("日報・件数報告", "毎日の報告内容が分かるもの"),
                ("評価・注意の連絡", "未達や進め方について指摘された記録"),
                ("会議メモ・予定", "定例会議や指導の頻度が分かるもの"),
                ("システム上の履歴", "件数・活動量・タスク等の管理画面")
            ]

        default:
            return [
                ("契約書", "契約上の業務内容・時間・場所・報酬等"),
                ("募集時の情報", "求人・募集ページや説明時の条件"),
                ("実際の勤務記録", "時間・曜日・休憩等の実態"),
                ("実際の勤務場所", "在宅・出社・現場等の実態"),
                ("業務指示", "実際に受けている指示や管理内容"),
                ("報酬・請求記録", "契約条件と実際の支払い"),
                ("条件変更のやり取り", "途中で条件が変わった経緯"),
                ("時系列メモ", "いつ何が変わったかを整理した記録")
            ]
        }
    }
}
