import SwiftUI

struct PremiumView: View {

    @Binding var isPlusUnlocked: Bool
    @ObservedObject var storeKitManager: StoreKitManager

    let onHome: () -> Void

    var body: some View {

        VStack(spacing: 22) {

            VStack(spacing: 10) {

                ZStack {

                    Circle()
                        .fill(Color.blue.opacity(0.10))
                        .frame(width: 86, height: 86)

                    Image(systemName: "crown.fill")
                        .font(.system(size: 38, weight: .semibold))
                        .foregroundStyle(.blue)
                }

                Text("守りナビ Plus")
                    .font(.largeTitle)
                    .bold()

                Text("記録を残す・整理する・必要なときに持ち出す")
                    .font(.headline)
                    .multilineTextAlignment(.center)

                Text("FreelanceGuardを、長く使うためのプレミアムプラン")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }
            .padding(.top, 6)

            VStack(alignment: .leading, spacing: 14) {

                premiumFeatureRow(
                    "infinity",
                    "記録を無制限に",
                    "勤務記録・証拠メモ・重要日をしっかり保存"
                )

                premiumFeatureRow(
                    "clock.arrow.circlepath",
                    "全履歴を確認",
                    "過去のチェックや記録を時系列で振り返る"
                )

                premiumFeatureRow(
                    "doc.richtext.fill",
                    "完全版PDFレポート",
                    "保存した情報をまとめて整理・持ち出し"
                )

                premiumFeatureRow(
                    "text.viewfinder",
                    "文章整理をもっと便利に",
                    "LINE・Slack・メール等の重要情報を整理"
                )

                premiumFeatureRow(
                    "sparkles",
                    "今後のPlus機能",
                    "AIを使った整理機能などを順次追加予定"
                )
            }
            .padding(18)
            .background(Color.gray.opacity(0.08))
            .clipShape(RoundedRectangle(cornerRadius: 20))

            VStack(alignment: .leading, spacing: 10) {

                Text("無料版の目安")
                    .font(.headline)

                Text("勤務記録 5件・証拠メモ 5件・重要日 3件までを無料で使える想定です。チェック機能や基礎知識は無料のまま利用できます。")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)

                Text("※ 保存済みデータは無料版へ戻っても削除しません。無料版では新しい保存のみ上限で制御します。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(16)
            .background(Color.blue.opacity(0.06))
            .clipShape(RoundedRectangle(cornerRadius: 16))

            VStack(spacing: 12) {

                premiumPlanCard(
                    title: "月額プラン",
                    price: storeKitManager.monthlyDisplayPrice,
                    detail: "1か月ごと",
                    badge: nil
                )

                premiumPlanCard(
                    title: "年額プラン",
                    price: storeKitManager.yearlyDisplayPrice,
                    detail: "月あたり約¥567",
                    badge: "おすすめ"
                )
            }

            if PlusAccessConfig.showsDebugControls {

                Button {

                    isPlusUnlocked.toggle()

                } label: {

                    HStack {

                        Image(
                            systemName:
                                isPlusUnlocked
                                ? "checkmark.seal.fill"
                                : "crown.fill"
                        )

                        Text(
                            isPlusUnlocked
                            ? "開発用PlusをOFF"
                            : "開発用PlusをON"
                        )
                        .bold()
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 5)
                }
                .buttonStyle(.borderedProminent)
                .controlSize(.large)

                Text("DEBUGビルド専用の確認スイッチです。Releaseビルドでは表示されません。購入・請求は発生しません。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)

                Text(
                    storeKitManager.isConfigured
                    ? "StoreKit商品ID：設定済み"
                    : "StoreKit基盤：準備済み（商品IDは次の工程で設定）"
                )
                .font(.caption2)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)

            } else {

                VStack(spacing: 10) {

                    Button {

                        Task {
                            await storeKitManager.purchaseMonthly()
                        }

                    } label: {

                        Label(
                            "月額Plusを購入 \(storeKitManager.monthlyDisplayPrice)",
                            systemImage: "crown.fill"
                        )
                        .bold()
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 5)
                    }
                    .buttonStyle(.borderedProminent)
                    .controlSize(.large)
                    .disabled(
                        !storeKitManager.isConfigured
                        || storeKitManager.isLoading
                        || storeKitManager.monthlyProduct == nil
                    )

                    Button {

                        Task {
                            await storeKitManager.purchaseYearly()
                        }

                    } label: {

                        Label(
                            "年額Plusを購入 \(storeKitManager.yearlyDisplayPrice)",
                            systemImage: "calendar.badge.checkmark"
                        )
                        .bold()
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 5)
                    }
                    .buttonStyle(.bordered)
                    .controlSize(.large)
                    .disabled(
                        !storeKitManager.isConfigured
                        || storeKitManager.isLoading
                        || storeKitManager.yearlyProduct == nil
                    )

                    Button("購入を復元") {

                        Task {
                            await storeKitManager.restorePurchases()
                        }
                    }
                    .disabled(
                        !storeKitManager.isConfigured
                        || storeKitManager.isLoading
                    )
                }

                if storeKitManager.isLoading {

                    ProgressView("App Storeを確認中…")
                        .font(.caption)

                } else if let message = storeKitManager.statusMessage {

                    Text(message)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                }
            }

            VStack(alignment: .leading, spacing: 10) {

                Label(
                    "記録は、あとから作れないことがあります",
                    systemImage: "clock.badge.exclamationmark"
                )
                .font(.subheadline)
                .bold()
                .foregroundStyle(.blue)

                Text("今は問題がなくても、勤務時間・業務指示・契約変更・やり取りを日頃から残しておくと、困ったときに「いつ・何があったか」を整理しやすくなります。無料版でも基本機能を試せます。")
                    .font(.caption)
                    .foregroundStyle(.secondary)

                Text("まず無料で記録する習慣を。記録が増えたらPlusでそのまま長く残せる設計です。")
                    .font(.caption)
                    .bold()
                    .foregroundStyle(.primary)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(16)
            .background(Color.blue.opacity(0.06))
            .clipShape(RoundedRectangle(cornerRadius: 16))

            VStack(alignment: .leading, spacing: 12) {

                Text("無料版とPlus")
                    .font(.headline)

                plusComparisonRow(
                    "働き方・フリーランス法チェック",
                    free: "○",
                    plus: "○"
                )

                plusComparisonRow(
                    "勤務記録",
                    free: "5件",
                    plus: "無制限"
                )

                plusComparisonRow(
                    "証拠・メモ",
                    free: "5件",
                    plus: "無制限"
                )

                plusComparisonRow(
                    "重要日",
                    free: "3件",
                    plus: "無制限"
                )

                plusComparisonRow(
                    "履歴・PDF",
                    free: "基本",
                    plus: "全履歴・完全版"
                )

                plusComparisonRow(
                    "文章整理",
                    free: "基本",
                    plus: "拡張予定"
                )
            }
            .padding(17)
            .background(Color.gray.opacity(0.08))
            .clipShape(RoundedRectangle(cornerRadius: 18))

            Button("ホームに戻る") {
                onHome()
            }
            .buttonStyle(.bordered)

            Text("価格・提供機能はApp Store公開前に最終調整する場合があります。")
                .font(.caption2)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .padding(.horizontal, 4)
        .task {
            await storeKitManager.prepare()

            if !PlusAccessConfig.showsDebugControls {
                isPlusUnlocked = storeKitManager.hasPlusAccess
            }
        }
        .onChange(of: storeKitManager.hasPlusAccess) { _, hasAccess in

            if !PlusAccessConfig.showsDebugControls {
                isPlusUnlocked = hasAccess
            }
        }
    }

    private func premiumFeatureRow(
        _ icon: String,
        _ title: String,
        _ subtitle: String
    ) -> some View {

        HStack(alignment: .top, spacing: 14) {

            Image(systemName: icon)
                .font(.title3)
                .foregroundStyle(.blue)
                .frame(width: 30)

            VStack(alignment: .leading, spacing: 3) {

                Text(title)
                    .font(.headline)

                Text(subtitle)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }

            Spacer()
        }
    }

    private func premiumPlanCard(
        title: String,
        price: String,
        detail: String,
        badge: String?
    ) -> some View {

        HStack(spacing: 14) {

            VStack(alignment: .leading, spacing: 5) {

                HStack(spacing: 8) {

                    Text(title)
                        .font(.headline)

                    if let badge {

                        Text(badge)
                            .font(.caption2)
                            .bold()
                            .foregroundStyle(.blue)
                            .padding(.horizontal, 8)
                            .padding(.vertical, 4)
                            .background(Color.blue.opacity(0.10))
                            .clipShape(Capsule())
                    }
                }

                Text(detail)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            Text(price)
                .font(.title2)
                .bold()
        }
        .padding(17)
        .background(Color.gray.opacity(0.08))
        .overlay(
            RoundedRectangle(cornerRadius: 18)
                .stroke(
                    Color.blue.opacity(
                        badge == nil ? 0.12 : 0.45
                    ),
                    lineWidth:
                        badge == nil ? 1 : 2
                )
        )
        .clipShape(RoundedRectangle(cornerRadius: 18))
    }

    private func plusComparisonRow(
        _ title: String,
        free: String,
        plus: String
    ) -> some View {

        HStack(spacing: 8) {

            Text(title)
                .font(.caption)
                .frame(maxWidth: .infinity, alignment: .leading)

            Text(free)
                .font(.caption)
                .foregroundStyle(.secondary)
                .frame(width: 58)

            Text(plus)
                .font(.caption)
                .bold()
                .foregroundStyle(.blue)
                .frame(width: 82)
        }
    }
}
