import Foundation

struct ProjectContract: Identifiable, Codable, Equatable {
    var id = UUID()
    var createdAt = Date()
    var name = ""
    var client = ""
    var startDate = Date()
    var endDate: Date?
    var contractType = "業務委託"
    var compensation = ""
    var paymentTerms = ""
    var jobDescription = ""
    var workLocation = ""
    var notes = ""

    var isValid: Bool {
        !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
            && (endDate.map { Calendar.current.startOfDay(for: $0) >= Calendar.current.startOfDay(for: startDate) } ?? true)
    }
    var summary: String {
        ["案件：\(name)", "取引先：\(client)", "期間：\(WorkspaceFormat.date(startDate)) ～ \(endDate.map(WorkspaceFormat.date) ?? "未定")",
         "契約形態：\(contractType)", "報酬：\(compensation)", "支払条件：\(paymentTerms)",
         "仕事内容：\(jobDescription)", "勤務場所：\(workLocation)", "備考：\(notes)"].joined(separator: "\n")
    }
}

struct LawCheckSnapshot: Identifiable, Codable, Equatable {
    var id = UUID()
    var date = Date()
    var answers: [Bool]
    var summary: String
}

struct ConsultationPreparation: Codable, Equatable {
    static let labels = ["契約書を確認した", "勤務記録を整理した", "指示内容を整理した",
                         "メール・チャット等を確認した", "重要な日付を整理した", "相談したい内容を整理した"]
    var checked: [Bool] = Array(repeating: false, count: 6)
    var question = ""
    func isChecked(_ index: Int) -> Bool { checked.indices.contains(index) && checked[index] }
}

struct WorkspaceData: Codable, Equatable {
    var version = 1
    var projects: [ProjectContract] = []
    var lawChecks: [LawCheckSnapshot] = []
    var preparations: [String: ConsultationPreparation] = [:]
}

enum WorkspaceFormat {
    nonisolated static func date(_ date: Date) -> String {
        date.formatted(.dateTime.year().month().day().locale(Locale(identifier: "ja_JP")))
    }
    nonisolated static func duration(_ minutes: Int) -> String { "\(minutes / 60)時間\(minutes % 60)分" }
}

extension WorkRecord {
    /// DatePickerの時刻部分を使う。終了が開始より前の場合は翌日終了として集計する。
    func workedMinutes(calendar: Calendar = .current) -> Int {
        let start = calendar.component(.hour, from: startTime) * 60 + calendar.component(.minute, from: startTime)
        let end = calendar.component(.hour, from: endTime) * 60 + calendar.component(.minute, from: endTime)
        let elapsed = end >= start ? end - start : end - start + 24 * 60
        return max(0, elapsed - max(0, breakMinutes))
    }
}

enum ActivityKind: String, CaseIterable, Identifiable {
    case work = "勤務記録", evidence = "証拠・メモ", deadline = "重要日", check = "働き方チェック", law = "フリーランス法チェック", project = "案件・契約"
    var id: String { rawValue }
    var icon: String {
        switch self {
        case .work: "clock"
        case .evidence: "doc.text"
        case .deadline: "calendar"
        case .check: "checkmark.shield"
        case .law: "checkmark.seal"
        case .project: "folder"
        }
    }
}

struct ActivityEntry: Identifiable {
    var recordID: UUID
    var kind: ActivityKind
    var date: Date
    var title: String
    var details: String
    var projectID: UUID?
    var id: String { kind.rawValue + recordID.uuidString }
}

enum ProjectScope: Hashable {
    case all, unassigned, project(UUID)
    func includes(_ id: UUID?) -> Bool {
        switch self {
        case .all: true
        case .unassigned: id == nil
        case .project(let selected): id == selected
        }
    }
}

enum WorkspaceActivity {
    static func entries(work: [WorkRecord], evidence: [EvidenceRecord], deadlines: [ImportantDateRecord],
                        checks: [CheckHistory], laws: [LawCheckSnapshot], projects: [ProjectContract] = []) -> [ActivityEntry] {
        var result = work.map { record in
            ActivityEntry(recordID: record.id, kind: .work, date: record.date,
                title: record.details.isEmpty ? "勤務記録" : record.details,
                details: "勤務時間：\(WorkspaceFormat.duration(record.workedMinutes()))\n開始：\(record.startTime.formatted(date: .omitted, time: .shortened))　終了：\(record.endTime.formatted(date: .omitted, time: .shortened))\n休憩：\(record.breakMinutes)分\n指示：\(record.instruction)\n仕事内容：\(record.details)\nメモ：\(record.memo)", projectID: record.projectID)
        }
        result += evidence.map { ActivityEntry(recordID: $0.id, kind: .evidence, date: $0.date, title: $0.title, details: "種類：\($0.type)\n\($0.details)", projectID: $0.projectID) }
        result += deadlines.map { ActivityEntry(recordID: $0.id, kind: .deadline, date: $0.date, title: $0.title, details: "種類：\($0.type)\n\($0.memo)", projectID: $0.projectID) }
        result += checks.map { ActivityEntry(recordID: $0.id, kind: .check, date: $0.date, title: "\($0.answers.count)項目中\($0.yesCount)項目に該当", details: "回答順：\($0.answers.enumerated().map { "\($0.offset + 1)：\($0.element ? "はい" : "いいえ")" }.joined(separator: "、"))\nセルフチェックの回答を整理したもので、法的判断ではありません。", projectID: nil) }
        result += laws.map { ActivityEntry(recordID: $0.id, kind: .law, date: $0.date, title: "確認済み \($0.answers.filter { $0 }.count) / \($0.answers.count)", details: $0.summary, projectID: nil) }
        result += projects.map { ActivityEntry(recordID: $0.id, kind: .project, date: $0.startDate, title: $0.name, details: $0.summary, projectID: $0.id) }
        return result
    }

    static func filtered(_ entries: [ActivityEntry], query: String = "", scope: ProjectScope = .all,
                         interval: DateInterval? = nil, newestFirst: Bool = true) -> [ActivityEntry] {
        let words = query.split(whereSeparator: { $0.isWhitespace }).map(String.init)
        return entries.filter { entry in
            scope.includes(entry.projectID)
                && (interval.map { entry.date >= $0.start && entry.date < $0.end } ?? true)
                && words.allSatisfy { (entry.title + "\n" + entry.details).localizedStandardContains($0) }
        }.sorted { a, b in
            if a.date == b.date { return a.id < b.id }
            return newestFirst ? a.date > b.date : a.date < b.date
        }
    }
}

enum WorkspaceRecordLinks {
    static func detach(_ projectID: UUID, work: inout [WorkRecord], evidence: inout [EvidenceRecord], deadlines: inout [ImportantDateRecord]) {
        for index in work.indices where work[index].projectID == projectID { work[index].projectID = nil }
        for index in evidence.indices where evidence[index].projectID == projectID { evidence[index].projectID = nil }
        for index in deadlines.indices where deadlines[index].projectID == projectID { deadlines[index].projectID = nil }
    }
}
