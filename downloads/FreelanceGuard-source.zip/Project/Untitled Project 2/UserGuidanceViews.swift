import SwiftUI

struct FreeLimitNoticeView: View {

    let freeLimitKind: String
    let onOpenPremium: () -> Void
    let onHome: () -> Void

    var body: some View {

        ScrollView {

            VStack(spacing: 22) {

                Spacer(minLength: 24)

                ZStack {

                    Circle()
                        .fill(Color.blue.opacity(0.10))
                        .frame(width: 92, height: 92)

                    Image(systemName: "checkmark.shield.fill")
                        .font(.system(size: 46, weight: .semibold))
                        .foregroundStyle(.blue)
                }

                VStack(spacing: 8) {

                    Text("無料版の保存上限です")
                        .font(.title2.bold())
                        .multilineTextAlignment(.center)

                    Text("無料版の\(freeLimitKind)は\(freeLimitKind == "重要日" ? 3 : 5)件まで保存できます。")
                        .font(.body)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                }

                VStack(alignment: .leading, spacing: 12) {

                    Label(
                        "残した記録は、あとから経緯を確認する助けになります",
                        systemImage: "clock.arrow.circlepath"
                    )

                    Label(
                        "案件別に記録を整理して経緯を確認",
                        systemImage: "infinity"
                    )

                    Label(
                        "全履歴・完全版PDFでまとめて整理",
                        systemImage: "doc.richtext"
                    )
                }
                .font(.subheadline)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(18)
                .background(Color(.secondarySystemBackground))
                .clipShape(RoundedRectangle(cornerRadius: 18))

                VStack(alignment: .leading, spacing: 8) {

                    Text("大切なのは、必要になってから思い出すことではなく、普段から残しておくこと。")
                        .font(.headline)

                    Text("保存した記録を確認し、相談準備レポートにまとめられます。")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                .padding(18)
                .background(Color.blue.opacity(0.08))
                .clipShape(RoundedRectangle(cornerRadius: 18))

                Button {
                    onOpenPremium()
                } label: {

                    Label(
                        "相談準備を開く",
                        systemImage: "crown.fill"
                    )
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 16)
                }
                .buttonStyle(.borderedProminent)
                .tint(.blue)
                .clipShape(RoundedRectangle(cornerRadius: 16))

                Button("今はホームに戻る") {
                    onHome()
                }
                .font(.headline)
                .foregroundStyle(.blue)

                Text("保存済みの記録は自動では削除されません。不要な記録を削除する前に、PDFで保管してください。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
            }
            .padding(22)
        }
    }
}

struct FirstUseGuideView: View {

    let onNewWorkRecord: () -> Void
    let onNewEvidenceRecord: () -> Void
    let onHome: () -> Void

    var body: some View {

        ScrollView {

            VStack(spacing: 22) {

                Spacer(minLength: 18)

                Image(systemName: "shield.checkered")
                    .font(.system(size: 52, weight: .semibold))
                    .foregroundStyle(.blue)

                VStack(spacing: 8) {

                    Text("最初の1件を残してみましょう")
                        .font(.title2.bold())

                    Text("大切なのは、困ってから思い出すことではなく、普段から事実を記録しておくことです。")
                        .font(.body)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                }

                VStack(spacing: 12) {

                    firstUseChoiceCard(
                        icon: "clock.fill",
                        title: "勤務記録を残す",
                        subtitle: "開始・終了・休憩・指示内容などを記録",
                        action: onNewWorkRecord
                    )

                    firstUseChoiceCard(
                        icon: "doc.text.fill",
                        title: "証拠・メモを残す",
                        subtitle: "LINE・Slack・メール・口頭指示などを整理",
                        action: onNewEvidenceRecord
                    )
                }

                VStack(alignment: .leading, spacing: 10) {

                    Label(
                        "1件でも残す意味があります",
                        systemImage: "checkmark.shield.fill"
                    )
                    .font(.headline)
                    .foregroundStyle(.blue)

                    Text("日時・指示・やり取りをその都度残しておくと、後から経緯を確認するときに役立ちます。元のメッセージや資料も削除せず保管しておきましょう。")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                .padding(16)
                .background(Color.blue.opacity(0.08))
                .clipShape(RoundedRectangle(cornerRadius: 18))

                Button("今はホームに戻る") {
                    onHome()
                }
                .font(.headline)
                .foregroundStyle(.blue)
                .padding(.top, 4)

                Text("このアプリは記録整理を支援するもので、法的判断や個別の法律相談に代わるものではありません。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
            }
            .padding(22)
        }
    }

    private func firstUseChoiceCard(
        icon: String,
        title: String,
        subtitle: String,
        action: @escaping () -> Void
    ) -> some View {

        Button(action: action) {

            HStack(spacing: 16) {

                Image(systemName: icon)
                    .font(.title2)
                    .foregroundStyle(.blue)
                    .frame(width: 42, height: 42)
                    .background(Color.blue.opacity(0.10))
                    .clipShape(RoundedRectangle(cornerRadius: 12))

                VStack(alignment: .leading, spacing: 5) {

                    Text(title)
                        .font(.headline)
                        .foregroundStyle(.primary)

                    Text(subtitle)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.leading)
                }

                Spacer()

                Image(systemName: "chevron.right")
                    .foregroundStyle(.secondary)
            }
            .padding(17)
            .background(Color(.secondarySystemBackground))
            .clipShape(RoundedRectangle(cornerRadius: 18))
        }
        .buttonStyle(.plain)
    }
}
