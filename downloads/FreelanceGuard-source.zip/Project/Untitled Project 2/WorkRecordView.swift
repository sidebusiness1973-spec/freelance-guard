import SwiftUI

struct WorkRecordEditorView: View {

    @Binding var workDate: Date
    @Binding var workStartTime: Date
    @Binding var workEndTime: Date
    @Binding var workBreakMinutes: Int
    @Binding var workInstruction: String
    @Binding var workDetails: String
    @Binding var workMemo: String

    @Binding var editingWorkRecord: WorkRecord?
    @Binding var showWorkRecordSavedAlert: Bool
    @Binding var isSavingWorkRecord: Bool

    let workRecords: [WorkRecord]

    let onSave: () -> Void
    let onShowHistory: () -> Void
    let onHome: () -> Void

    var body: some View {

        VStack(spacing: 18) {

            VStack(spacing: 6) {

                Image(
                    systemName: editingWorkRecord == nil
                    ? "clock"
                    : "pencil.and.list.clipboard"
                )
                .font(.system(size: 34, weight: .semibold))

                Text(
                    editingWorkRecord == nil
                    ? "勤務を記録"
                    : "勤務記録を編集"
                )
                .font(.title2)
                .bold()

                Text("勤務時間や会社からの指示を、あとから振り返れる形で残します")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }

            VStack(alignment: .leading, spacing: 15) {

                Label("勤務日時", systemImage: "calendar")
                    .font(.headline)

                DatePicker(
                    "日付",
                    selection: $workDate,
                    displayedComponents: [.date]
                )

                DatePicker(
                    "開始時刻",
                    selection: $workStartTime,
                    displayedComponents: .hourAndMinute
                )

                DatePicker(
                    "終了時刻",
                    selection: $workEndTime,
                    displayedComponents: .hourAndMinute
                )

                Stepper(
                    "休憩時間：\(workBreakMinutes)分",
                    value: $workBreakMinutes,
                    in: 0...180,
                    step: 15
                )
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding()
            .background(Color.gray.opacity(0.09))
            .cornerRadius(16)

            VStack(alignment: .leading, spacing: 13) {

                Label("仕事内容・指示", systemImage: "text.bubble")
                    .font(.headline)

                TextField(
                    "会社から受けた指示",
                    text: $workInstruction,
                    axis: .vertical
                )
                .textFieldStyle(.roundedBorder)
                .lineLimit(2...5)

                TextField(
                    "仕事内容・件数",
                    text: $workDetails,
                    axis: .vertical
                )
                .textFieldStyle(.roundedBorder)
                .lineLimit(2...5)

                TextField(
                    "その他のメモ",
                    text: $workMemo,
                    axis: .vertical
                )
                .textFieldStyle(.roundedBorder)
                .lineLimit(2...5)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding()
            .background(Color.gray.opacity(0.09))
            .cornerRadius(16)

            Button {
                onSave()
            } label: {
                Label(
                    editingWorkRecord == nil
                    ? "勤務記録を保存"
                    : "変更内容を保存",
                    systemImage: "square.and.arrow.down.fill"
                )
            }
            .buttonStyle(.borderedProminent)
            .disabled(isSavingWorkRecord)
            .alert(
                editingWorkRecord == nil
                ? "勤務記録を保存しました"
                : "勤務記録を更新しました",
                isPresented: $showWorkRecordSavedAlert
            ) {
                Button("OK", role: .cancel) {
                    isSavingWorkRecord = false
                }
            }

            HStack {

                if !workRecords.isEmpty {
                    Button("勤務記録を見る") {
                        onShowHistory()
                    }
                    .buttonStyle(.bordered)
                }

                Button("ホームに戻る") {
                    onHome()
                }
                .buttonStyle(.bordered)
            }
        }
    }
}

struct WorkRecordHistoryView: View {

    let workRecords: [WorkRecord]

    @Binding var recordToDelete: WorkRecord?
    @Binding var showWorkRecordDeleteAlert: Bool

    let onEdit: (WorkRecord) -> Void
    let onDelete: (WorkRecord) -> Void
    let onNew: () -> Void
    let onHome: () -> Void

    var body: some View {

        VStack(spacing: 18) {

            VStack(spacing: 6) {

                Image(systemName: "clock.arrow.circlepath")
                    .font(.system(size: 34, weight: .semibold))

                Text("勤務記録")
                    .font(.title2)
                    .bold()

                Text("保存した勤務時間・指示・仕事内容を確認できます")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }

            if workRecords.isEmpty {

                ContentUnavailableView(
                    "勤務記録はまだありません",
                    systemImage: "clock",
                    description: Text(
                        "勤務した日時や会社からの指示を記録しておきましょう。"
                    )
                )

            } else {

                ForEach(workRecords.reversed()) { record in

                    let totalMinutes = max(
                        0,
                        Int(
                            record.endTime
                                .timeIntervalSince(record.startTime)
                        ) / 60 - record.breakMinutes
                    )

                    VStack(alignment: .leading, spacing: 10) {

                        HStack {

                            Label(
                                record.date.formatted(
                                    date: .numeric,
                                    time: .omitted
                                ),
                                systemImage: "calendar"
                            )
                            .font(.headline)

                            Spacer()

                            Text(
                                "\(totalMinutes / 60)時間\(totalMinutes % 60)分"
                            )
                            .font(.headline)
                        }

                        HStack {

                            Label(
                                "\(record.startTime.formatted(date: .omitted, time: .shortened))〜\(record.endTime.formatted(date: .omitted, time: .shortened))",
                                systemImage: "clock"
                            )

                            Spacer()

                            Text("休憩 \(record.breakMinutes)分")
                                .foregroundStyle(.secondary)
                        }
                        .font(.subheadline)

                        Divider()

                        recordLine(
                            title: "会社からの指示",
                            text: record.instruction
                        )

                        recordLine(
                            title: "仕事内容・件数",
                            text: record.details
                        )

                        recordLine(
                            title: "メモ",
                            text: record.memo
                        )

                        HStack {

                            Button {
                                onEdit(record)
                            } label: {
                                Label("編集", systemImage: "pencil")
                            }
                            .buttonStyle(.bordered)

                            Spacer()

                            Button(role: .destructive) {
                                recordToDelete = record
                                showWorkRecordDeleteAlert = true
                            } label: {
                                Label("削除", systemImage: "trash")
                            }
                            .buttonStyle(.bordered)
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding()
                    .background(Color.gray.opacity(0.09))
                    .overlay(
                        RoundedRectangle(cornerRadius: 16)
                            .stroke(
                                Color.primary.opacity(0.07),
                                lineWidth: 1
                            )
                    )
                    .cornerRadius(16)
                }
            }

            HStack {

                Button("新しい勤務記録") {
                    onNew()
                }
                .buttonStyle(.bordered)

                Button("ホームに戻る") {
                    onHome()
                }
                .buttonStyle(.borderedProminent)
            }
        }
        .alert(
            "勤務記録を削除しますか？",
            isPresented: $showWorkRecordDeleteAlert
        ) {

            Button("キャンセル", role: .cancel) {
                recordToDelete = nil
            }

            Button("削除", role: .destructive) {
                if let record = recordToDelete {
                    onDelete(record)
                }
                recordToDelete = nil
            }

        } message: {
            Text("削除した勤務記録は元に戻せません。")
        }
    }

    private func recordLine(
        title: String,
        text: String
    ) -> some View {

        VStack(alignment: .leading, spacing: 3) {

            Text(title)
                .font(.caption)
                .foregroundStyle(.secondary)

            Text(text.isEmpty ? "記録なし" : text)
                .font(.subheadline)
        }
    }
}
