import SwiftUI

enum WorkspaceDestination: String, CaseIterable, Identifiable {
    case projects = "案件・契約", timeline = "タイムライン", preparation = "相談準備", search = "記録を検索"
    var id: String { rawValue }
    var icon: String {
        switch self {
        case .projects: "folder"
        case .timeline: "clock.arrow.circlepath"
        case .preparation: "list.clipboard"
        case .search: "magnifyingglass"
        }
    }
}

struct WorkspaceCard<Content: View>: View {
    @ViewBuilder var content: Content
    var body: some View {
        VStack(alignment: .leading, spacing: 12) { content }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(18)
            .background(Color(.secondarySystemGroupedBackground))
            .clipShape(RoundedRectangle(cornerRadius: 18))
            .overlay(RoundedRectangle(cornerRadius: 18).stroke(Color.primary.opacity(0.08)))
    }
}

struct ProjectPicker: View {
    let projects: [ProjectContract]
    @Binding var selection: UUID?
    var allRecords = false
    var body: some View {
        Picker("案件・契約", selection: $selection) {
            Text(allRecords ? "すべての案件・案件なし" : "案件なし").tag(nil as UUID?)
            ForEach(projects) { project in Text(project.name).tag(Optional(project.id)) }
        }
        .pickerStyle(.menu)
        .accessibilityIdentifier("projectPicker")
    }
}

struct ProjectScopePicker: View {
    let projects: [ProjectContract]
    @Binding var selection: ProjectScope
    var body: some View {
        Picker("案件で絞り込む", selection: $selection) {
            Text("すべて").tag(ProjectScope.all)
            Text("案件なし").tag(ProjectScope.unassigned)
            ForEach(projects) { Text($0.name).tag(ProjectScope.project($0.id)) }
        }.pickerStyle(.menu)
    }
}

struct WorkspaceDashboardView: View {
    @ObservedObject var store: WorkspaceStore
    let work: [WorkRecord]
    let evidence: [EvidenceRecord]
    let deadlines: [ImportantDateRecord]
    let checks: [CheckHistory]
    let entries: [ActivityEntry]
    let onDestination: (WorkspaceDestination) -> Void
    let onWork: () -> Void
    let onEvidence: () -> Void
    let onDeadlines: () -> Void
    let onCheck: () -> Void
    let onLaw: () -> Void
    let onEntry: (ActivityEntry) -> Void

    private var monthWork: [WorkRecord] {
        let interval = Calendar.current.dateInterval(of: .month, for: Date())
        return work.filter { item in interval.map { item.date >= $0.start && item.date < $0.end } ?? false }
    }
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            VStack(alignment: .leading, spacing: 22) {
                HStack {
                    Label("FreelanceGuard", systemImage: "shield.lefthalf.filled")
                        .font(.subheadline.bold())
                    Spacer()
                    Text("WORK JOURNAL").font(.caption2.bold()).tracking(2)
                }.foregroundStyle(.white.opacity(0.8))
                HStack(alignment: .top, spacing: 16) {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("今日の記録が、\n明日の備えに。")
                            .font(.system(.largeTitle, design: .rounded, weight: .bold))
                            .foregroundStyle(.white).accessibilityAddTraits(.isHeader)
                        Text("勤務・証拠・契約をまとめて、\n相談できる資料へ。")
                            .font(.subheadline).foregroundStyle(.white.opacity(0.8))
                    }
                }
                Button(action: onWork) {
                    HStack {
                        Image(systemName: "plus.circle.fill")
                        Text("今日の勤務を記録").fontWeight(.bold)
                        Spacer()
                        Image(systemName: "arrow.right")
                    }.padding(16)
                        .foregroundStyle(Color(red: 0.05, green: 0.20, blue: 0.24))
                        .background(Color(red: 0.40, green: 0.90, blue: 0.80), in: RoundedRectangle(cornerRadius: 16))
                }.buttonStyle(.plain)
                HStack(spacing: 8) {
                    Image(systemName: "iphone")
                    Text("端末に保存")
                    Text("・")
                    Text("アカウント登録不要")
                }.font(.caption).foregroundStyle(.white.opacity(0.75))
            }
            .padding(24)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(LinearGradient(colors: [Color(red: 0.06, green: 0.16, blue: 0.24), Color(red: 0.09, green: 0.30, blue: 0.34)], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 28))

            HStack {
                Text("記録から相談まで").font(.title2.bold())
                Spacer()
                Image(systemName: "arrow.right").foregroundStyle(.secondary)
            }
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 145), alignment: .top)], spacing: 12) {
                step("勤務を残す", icon: "clock.fill", action: onWork)
                step("証拠を整理", icon: "doc.text.image", action: onEvidence)
                step("経緯を見る", icon: "clock.arrow.circlepath") { onDestination(.timeline) }
                step("相談用PDF", icon: "doc.richtext") { onDestination(.preparation) }
            }
            Text("今の記録状況").font(.title2.bold())
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 160), alignment: .top)], spacing: 12) {
                metric("今月の勤務記録", value: "\(monthWork.count)件", icon: "calendar", action: onWork)
                metric("今月の勤務時間", value: WorkspaceFormat.duration(monthWork.reduce(0) { $0 + $1.workedMinutes() }), icon: "clock", action: onWork)
                metric("証拠・メモ", value: "\(evidence.count)件", icon: "doc.text", action: onEvidence)
                metric("重要日・期限", value: "\(deadlines.count)件", icon: "calendar.badge.clock", action: onDeadlines)
            }
            Text("勤務時間は休憩を差し引いて集計します。終了が開始より前の場合は翌日終了として扱います。")
                .font(.caption).foregroundStyle(.secondary)
            Button(action: onDeadlines) {
                WorkspaceCard {
                    Label("直近の重要日", systemImage: "calendar.badge.exclamationmark").font(.headline)
                    if let next = deadlines.filter({ $0.date >= Calendar.current.startOfDay(for: Date()) }).min(by: { $0.date < $1.date }) {
                        Text("\(WorkspaceFormat.date(next.date))　\(next.title)")
                    } else { Text("今後の重要日はありません。タップして登録できます。") }
                }
            }.buttonStyle(.plain)
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 260), alignment: .top)], spacing: 12) {
                Button(action: onCheck) {
                    WorkspaceCard {
                        Label("最新の働き方チェック", systemImage: "checkmark.shield").font(.headline)
                        if let latest = checks.max(by: { $0.date < $1.date }) {
                            Text("\(latest.answers.count)項目中\(latest.yesCount)項目に該当")
                            Text(WorkspaceFormat.date(latest.date)).font(.caption)
                        } else { Text("まだ結果がありません。チェックを始める") }
                    }
                }.buttonStyle(.plain)
                Button(action: onLaw) {
                    WorkspaceCard {
                        Label("最新のフリーランス法チェック", systemImage: "checkmark.seal").font(.headline)
                        if let latest = store.lawChecks.max(by: { $0.date < $1.date }) {
                            Text("確認済み \(latest.answers.filter { $0 }.count) / \(latest.answers.count)")
                            Text(WorkspaceFormat.date(latest.date)).font(.caption)
                        } else if let old = evidence.filter({ $0.title == "フリーランス法チェック" }).max(by: { $0.date < $1.date }) {
                            Text(old.details).lineLimit(3)
                            Text("保存済みメモ：\(WorkspaceFormat.date(old.date))").font(.caption)
                        } else { Text("まだ結果がありません。確認を始める") }
                    }
                }.buttonStyle(.plain)
            }
            Text("セルフチェックは回答の整理です。法的判断や個別の法律相談ではありません。")
                .font(.caption).foregroundStyle(.secondary)
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 160))], spacing: 12) {
                ForEach(WorkspaceDestination.allCases) { destination in
                    step(destination.rawValue, icon: destination.icon) { onDestination(destination) }
                }
            }
            Text("最近の記録").font(.title2.bold())
            let recent = WorkspaceActivity.filtered(entries.filter { $0.kind != .deadline || $0.date <= Date() }).prefix(5)
            if recent.isEmpty { Text("記録を追加すると、ここに最近の経緯が表示されます。").foregroundStyle(.secondary) }
            ForEach(Array(recent)) { entry in
                Button { onEntry(entry) } label: {
                    WorkspaceCard { ActivitySummary(entry: entry, projectName: store.projectName(entry.projectID)) }
                }.buttonStyle(.plain)
            }
        }
    }
    private func step(_ title: String, icon: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 16) {
                HStack {
                    Image(systemName: icon)
                        .font(.title2)
                        .foregroundStyle(Color.accentColor)
                        .frame(width: 46, height: 46)
                        .background(Color.accentColor.opacity(0.10), in: RoundedRectangle(cornerRadius: 14))
                    Spacer()
                    Image(systemName: "arrow.up.right").font(.caption.bold()).foregroundStyle(.secondary)
                }
                Text(title).font(.headline).foregroundStyle(.primary)
            }
            .frame(maxWidth: .infinity, alignment: .leading).padding(18)
            .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 22))
            .overlay(RoundedRectangle(cornerRadius: 22).stroke(Color.primary.opacity(0.06)))
        }.buttonStyle(.plain)
    }
    private func metric(_ title: String, value: String, icon: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            WorkspaceCard {
                Label(title, systemImage: icon).font(.subheadline)
                Text(value).font(.title2.bold()).foregroundStyle(Color.accentColor)
            }
        }.buttonStyle(.plain)
    }
}

struct ActivitySummary: View {
    let entry: ActivityEntry
    let projectName: String
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Label(entry.kind.rawValue, systemImage: entry.kind.icon).font(.caption).foregroundStyle(.secondary)
            Text(entry.title.isEmpty ? entry.kind.rawValue : entry.title).font(.headline).multilineTextAlignment(.leading)
            Text("\(WorkspaceFormat.date(entry.date)) ・ \(projectName)").font(.caption).foregroundStyle(.secondary)
        }
    }
}

struct ActivityTimelineView: View {
    @ObservedObject var store: WorkspaceStore
    let entries: [ActivityEntry]
    var isSearch = false
    @Binding var scope: ProjectScope
    let onOpen: (ActivityEntry) -> Void
    @State private var query = ""
    @State private var newestFirst = true
    @State private var filterDates = false
    @State private var start = Calendar.current.date(byAdding: .month, value: -1, to: Date()) ?? Date()
    @State private var end = Date()
    private var matches: [ActivityEntry] {
        let calendar = Calendar.current
        let endExclusive = calendar.date(byAdding: .day, value: 1, to: calendar.startOfDay(for: end)) ?? end
        let interval = filterDates ? DateInterval(start: calendar.startOfDay(for: start), end: max(calendar.startOfDay(for: start), endExclusive)) : nil
        return WorkspaceActivity.filtered(entries, query: query, scope: scope, interval: interval, newestFirst: newestFirst)
    }
    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            Text(isSearch ? "記録を検索" : "活動タイムライン").font(.largeTitle.bold())
            Text(isSearch ? "案件名・取引先・仕事内容・指示・証拠メモをまとめて検索します。" : "勤務・証拠・重要日・チェック結果を、日付順に振り返ります。重要日は期日で表示します。")
                .foregroundStyle(.secondary)
            WorkspaceCard {
                TextField("キーワードを入力", text: $query).textFieldStyle(.roundedBorder).accessibilityIdentifier("activitySearch")
                ProjectScopePicker(projects: store.projects, selection: $scope)
                Picker("並び順", selection: $newestFirst) {
                    Text("新しい順").tag(true)
                    Text("古い順").tag(false)
                }.pickerStyle(.segmented)
                Toggle("日付で絞り込む", isOn: $filterDates)
                if filterDates {
                    DatePicker("開始日", selection: $start, displayedComponents: .date)
                    DatePicker("終了日", selection: $end, in: start..., displayedComponents: .date)
                }
            }
            Text("\(matches.count)件").font(.headline)
            if matches.isEmpty {
                ContentUnavailableView("該当する記録はありません", systemImage: "tray", description: Text("条件を変えるか、ホームから記録を追加してください。"))
            }
            LazyVStack(spacing: 12) {
                ForEach(matches) { entry in
                    WorkspaceCard {
                        DisclosureGroup {
                            Text(entry.details).textSelection(.enabled).frame(maxWidth: .infinity, alignment: .leading).padding(.vertical, 8)
                            Button(entry.kind == .law ? "チェック履歴を見る" : "記録を開く") { onOpen(entry) }.buttonStyle(.bordered)
                        } label: { ActivitySummary(entry: entry, projectName: store.projectName(entry.projectID)) }
                    }
                }
            }
        }
    }
}
