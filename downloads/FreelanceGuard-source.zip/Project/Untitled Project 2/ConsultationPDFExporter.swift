import UIKit
import CoreText

@MainActor
enum ConsultationPDFExporter {
    /// Core Textの表示済み文字数でページを進め、長いメモも途中で切り捨てない。
    static func create(_ document: ConsultationReportDocument) throws -> URL {
        let text = NSMutableAttributedString(string: "")
        let bodyParagraph = NSMutableParagraphStyle()
        bodyParagraph.lineSpacing = 4
        bodyParagraph.paragraphSpacing = 6
        func append(_ value: String, bold: Bool = false) {
            text.append(NSAttributedString(string: value + "\n\n", attributes: [
                .font: bold ? UIFont.boldSystemFont(ofSize: 14) : UIFont.systemFont(ofSize: 11),
                .foregroundColor: UIColor.black,
                .paragraphStyle: bodyParagraph
            ]))
        }
        append("作成日時：\(document.createdAt.formatted(date: .numeric, time: .shortened))")
        for section in document.sections { append(section.title, bold: true); append(section.body) }
        let framesetter = CTFramesetterCreateWithAttributedString(text)
        let bounds = CGRect(x: 0, y: 0, width: 595, height: 842)
        let format = UIGraphicsPDFRendererFormat()
        format.documentInfo = [kCGPDFContextTitle as String: "相談準備レポート"]
        let renderer = UIGraphicsPDFRenderer(bounds: bounds, format: format)
        var offset = 0
        let data = renderer.pdfData { context in
            var page = 0
            while offset < text.length {
                page += 1
                context.beginPage()
                ("FreelanceGuard｜相談準備レポート" as NSString).draw(at: CGPoint(x: 36, y: 24), withAttributes: [.font: UIFont.boldSystemFont(ofSize: 12), .foregroundColor: UIColor.black])
                ("\(page)　記録整理・相談準備支援（法的判断ではありません）" as NSString).draw(at: CGPoint(x: 36, y: 810), withAttributes: [.font: UIFont.systemFont(ofSize: 9), .foregroundColor: UIColor.darkGray])
                let cg = context.cgContext
                cg.saveGState()
                cg.textMatrix = .identity
                cg.translateBy(x: 0, y: bounds.height)
                cg.scaleBy(x: 1, y: -1)
                let path = CGPath(rect: CGRect(x: 36, y: 56, width: 523, height: 728), transform: nil)
                let frame = CTFramesetterCreateFrame(framesetter, CFRange(location: offset, length: 0), path, nil)
                CTFrameDraw(frame, cg)
                let visible = CTFrameGetVisibleStringRange(frame)
                cg.restoreGState()
                guard visible.length > 0 else { break }
                offset += visible.length
            }
        }
        guard offset == text.length else { throw CocoaError(.fileWriteUnknown) }
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent("ConsultationReports", isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let url = directory.appendingPathComponent("相談準備レポート-\(UUID().uuidString).pdf")
        try data.write(to: url, options: .atomic)
        return url
    }
}
