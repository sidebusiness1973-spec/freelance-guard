import SwiftUI

struct WorkStyleQuestionView: View {

    let questionNumber: Int
    let questions: [String]

    let hasHistories: Bool
    let hasWorkRecords: Bool
    let hasEvidenceRecords: Bool

    let onAnswerYes: () -> Void
    let onAnswerNo: () -> Void
    let onOpenHistory: () -> Void
    let onNewWorkRecord: () -> Void
    let onOpenWorkRecords: () -> Void
    let onNewEvidenceRecord: () -> Void
    let onOpenEvidenceRecords: () -> Void

    var body: some View {

        VStack(spacing: 25) {

            Text("働き方チェック")
                .font(.headline)

            Text("質問 \(questionNumber + 1) / \(questions.count)")
                .font(.subheadline)

            ProgressView(
                value: Double(questionNumber + 1),
                total: Double(questions.count)
            )

            Text(questions[questionNumber])
                .font(.title3)
                .multilineTextAlignment(.center)
                .padding()

            HStack(spacing: 20) {

                Button("はい") {
                    onAnswerYes()
                }
                .buttonStyle(.borderedProminent)

                Button("いいえ") {
                    onAnswerNo()
                }
                .buttonStyle(.bordered)
            }

            if hasHistories {

                Button("過去のチェック結果を見る") {
                    onOpenHistory()
                }
                .padding(.top)
            }

            Button("勤務記録をつける") {
                onNewWorkRecord()
            }
            .buttonStyle(.borderedProminent)
            .padding(.top, 5)

            if hasWorkRecords {

                Button("勤務記録を見る") {
                    onOpenWorkRecords()
                }
                .buttonStyle(.bordered)
            }

            Button("証拠・メモを記録する") {
                onNewEvidenceRecord()
            }
            .buttonStyle(.borderedProminent)
            .padding(.top, 5)

            if hasEvidenceRecords {

                Button("証拠・メモを見る") {
                    onOpenEvidenceRecords()
                }
                .buttonStyle(.bordered)
            }
        }
    }
}

struct WorkStyleResultView: View {

    let questions: [String]
    let answers: [Bool]
    let yesCount: Int
    let isSaved: Bool

    let onSave: () -> Void
    let onOpenHistory: () -> Void
    let onOpenConsultation: () -> Void
    let onReset: () -> Void
    let onHome: () -> Void

    var body: some View {

        VStack(spacing: 18) {

            VStack(spacing: 8) {

                Image(systemName: "checkmark.shield.fill")
                    .font(.system(size: 40, weight: .semibold))
                    .symbolRenderingMode(.hierarchical)

                Text("チェック結果")
                    .font(.title2)
                    .bold()

                Text("\(questions.count)項目中 \(yesCount)項目が該当")
                    .font(.title)
                    .bold()

                Text("回答内容を振り返り、必要な記録や次の行動を整理しましょう。")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }

            VStack(alignment: .leading, spacing: 10) {

                Label("結果の見方", systemImage: "info.circle.fill")
                    .font(.headline)

                CheckResultMessageView(count: yesCount)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding()
            .background(Color.gray.opacity(0.10))
            .overlay(
                RoundedRectangle(cornerRadius: 16)
                    .stroke(Color.primary.opacity(0.08), lineWidth: 1)
            )
            .cornerRadius(16)

            if yesCount > 0 {

                VStack(alignment: .leading, spacing: 10) {

                    Label("今回該当した項目", systemImage: "checklist")
                        .font(.headline)

                    ForEach(Array(questions.enumerated()), id: \.offset) { index, question in

                        if index < answers.count && answers[index] {

                            HStack(alignment: .top, spacing: 9) {

                                Image(systemName: "checkmark.circle.fill")
                                    .font(.subheadline)

                                Text(question)
                                    .font(.subheadline)
                            }
                        }
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding()
                .background(Color.gray.opacity(0.10))
                .overlay(
                    RoundedRectangle(cornerRadius: 16)
                        .stroke(Color.primary.opacity(0.08), lineWidth: 1)
                )
                .cornerRadius(16)
            }

            if isSaved {

                Label("この結果は保存済みです", systemImage: "checkmark.circle.fill")
                    .font(.headline)

            } else {

                Button {
                    onSave()
                } label: {
                    Label("この結果を保存", systemImage: "square.and.arrow.down.fill")
                }
                .buttonStyle(.borderedProminent)
            }

            HStack(spacing: 10) {

                Button("過去の結果") {
                    onOpenHistory()
                }
                .buttonStyle(.bordered)

                Button("相談先・次の行動") {
                    onOpenConsultation()
                }
                .buttonStyle(.bordered)
            }

            DisclosureGroup("15問すべての回答を見る") {
                CheckAnswerListView(
                    questions: questions,
                    answers: answers
                )
                .padding(.top, 8)
            }
            .padding()
            .background(Color.gray.opacity(0.07))
            .cornerRadius(14)

            Text("※このチェックは働き方を整理するための参考情報です。労働者性や法的な権利を判定するものではありません。")
                .font(.caption)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)

            HStack(spacing: 10) {

                Button("もう一度チェック") {
                    onReset()
                }
                .buttonStyle(.bordered)

                Button("ホームに戻る") {
                    onHome()
                }
                .buttonStyle(.borderedProminent)
            }
        }
    }
}

struct CheckHistoryListView: View {

    let histories: [CheckHistory]
    let questionCount: Int

    let onSelect: (CheckHistory) -> Void
    let onHome: () -> Void

    var body: some View {

        VStack(spacing: 18) {

            VStack(spacing: 7) {

                Image(systemName: "list.bullet.clipboard.fill")
                    .font(.system(size: 34, weight: .semibold))

                Text("チェック履歴")
                    .font(.title2)
                    .bold()

                Text("保存したチェック結果を振り返れます")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }

            if histories.isEmpty {

                ContentUnavailableView(
                    "保存された結果はありません",
                    systemImage: "checkmark.shield",
                    description: Text("働き方チェックを行い、結果を保存するとここに表示されます。")
                )

            } else {

                ForEach(histories.reversed()) { history in

                    Button {
                        onSelect(history)
                    } label: {

                        HStack(spacing: 12) {

                            Image(systemName: "checkmark.shield.fill")
                                .font(.title2)

                            VStack(alignment: .leading, spacing: 5) {

                                Text(history.date.formatted(date: .numeric, time: .shortened))
                                    .font(.headline)

                                Text("\(questionCount)項目中 \(history.yesCount)項目が該当")
                                    .font(.subheadline)
                                    .bold()

                                Text("回答内容を確認")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }

                            Spacer()

                            Image(systemName: "chevron.right")
                                .foregroundStyle(.secondary)
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding()
                        .background(Color.gray.opacity(0.09))
                        .overlay(
                            RoundedRectangle(cornerRadius: 16)
                                .stroke(Color.primary.opacity(0.07), lineWidth: 1)
                        )
                        .cornerRadius(16)
                    }
                    .buttonStyle(.plain)
                }
            }

            Button("ホームに戻る") {
                onHome()
            }
            .buttonStyle(.borderedProminent)
        }
    }
}

struct CheckHistoryDetailView: View {

    let history: CheckHistory
    let questions: [String]

    let onBackToList: () -> Void
    let onHome: () -> Void
    let onDelete: () -> Void

    var body: some View {

        VStack(spacing: 18) {

            VStack(spacing: 7) {

                Image(systemName: "checkmark.shield.fill")
                    .font(.system(size: 34, weight: .semibold))

                Text("チェック結果の詳細")
                    .font(.title2)
                    .bold()

                Text(history.date.formatted(date: .long, time: .shortened))
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }

            VStack(spacing: 6) {

                Text("\(questions.count)項目中")
                    .font(.subheadline)

                Text("\(history.yesCount)項目が該当")
                    .font(.title)
                    .bold()

                Text("法的な判定ではなく、保存した回答内容の整理です。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }
            .frame(maxWidth: .infinity)
            .padding()
            .background(Color.gray.opacity(0.09))
            .cornerRadius(16)

            CheckResultMessageView(count: history.yesCount)

            if history.yesCount > 0 {

                VStack(alignment: .leading, spacing: 9) {

                    Label("該当した項目", systemImage: "checklist")
                        .font(.headline)

                    ForEach(Array(questions.enumerated()), id: \.offset) { index, question in

                        if index < history.answers.count && history.answers[index] {

                            HStack(alignment: .top, spacing: 8) {

                                Image(systemName: "checkmark.circle.fill")

                                Text(question)
                                    .font(.subheadline)
                            }
                        }
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding()
                .background(Color.gray.opacity(0.09))
                .cornerRadius(16)
            }

            DisclosureGroup("15問すべての回答を見る") {
                CheckAnswerListView(
                    questions: questions,
                    answers: history.answers
                )
                .padding(.top, 8)
            }
            .padding()
            .background(Color.gray.opacity(0.07))
            .cornerRadius(14)

            HStack {

                Button("履歴一覧に戻る") {
                    onBackToList()
                }
                .buttonStyle(.bordered)

                Button("ホームに戻る") {
                    onHome()
                }
                .buttonStyle(.borderedProminent)
            }

            Button("この結果を削除", role: .destructive) {
                onDelete()
            }
            .buttonStyle(.bordered)

            Text("削除した結果は元に戻せません")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
    }
}

private struct CheckAnswerListView: View {

    let questions: [String]
    let answers: [Bool]

    var body: some View {

        VStack(spacing: 12) {

            ForEach(questions.indices, id: \.self) { index in

                VStack(alignment: .leading, spacing: 6) {

                    Text("\(index + 1). \(questions[index])")
                        .font(.headline)

                    if index < answers.count {

                        Text(
                            answers[index]
                                ? "回答：はい"
                                : "回答：いいえ"
                        )
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding()
                .background(Color.gray.opacity(0.1))
                .cornerRadius(10)
            }
        }
    }
}

private struct CheckResultMessageView: View {

    let count: Int

    var body: some View {

        VStack(spacing: 12) {

            if count <= 4 {

                Text("現在の働き方を整理してみましょう")
                    .font(.headline)

                Text("今回の回答では、該当する項目は比較的少ない結果となりました。")
                    .multilineTextAlignment(.center)

            } else if count <= 9 {

                Text("契約内容と実際の働き方を確認してみましょう")
                    .font(.headline)

                Text("契約書の内容と、実際の勤務方法に違いがないか整理しておくことをおすすめします。")
                    .multilineTextAlignment(.center)

            } else {

                Text("働き方の状況を詳しく整理してみましょう")
                    .font(.headline)

                Text("該当する項目が多くなっています。契約内容、日々の指示、勤務記録などを整理しておくと状況を把握しやすくなります。")
                    .multilineTextAlignment(.center)
            }
        }
        .padding()
    }
}
