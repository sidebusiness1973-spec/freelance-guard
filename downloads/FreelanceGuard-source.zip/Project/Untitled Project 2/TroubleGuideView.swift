import SwiftUI

struct TroubleGuideView: View {

    let onOpenMessageOrganizer: () -> Void
    let onCreateEvidence: () -> Void
    let onOpenConsultation: () -> Void
    let onHome: () -> Void

    var body: some View {

        VStack(spacing: 18) {

            VStack(spacing: 7) {

                Image(systemName: "lifepreserver.fill")
                    .font(.system(size: 38, weight: .semibold))

                Text("トラブル対応")
                    .font(.title2)
                    .bold()

                Text("困っている状況から、確認事項・残しておきたい記録・アプリでできることを整理します")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }

            troubleCard(
                icon: "xmark.circle.fill",
                title: "契約解除・突然のアカウント停止",
                check: "解除・終了の通知日、契約終了日、契約書の解除条項、事前予告の有無を確認。",
                evidence: "解除を伝えられたLINE・Slack・メール、契約書、アカウント停止日時、勤務予定・シフト等を保存。"
            )

            troubleCard(
                icon: "yensign.circle.fill",
                title: "報酬が支払われない・遅れている",
                check: "報酬額、支払期日、請求書、業務を行った事実、発注条件を確認。",
                evidence: "契約書・発注書・請求書・納品記録・勤務記録・相手との支払連絡を保存。"
            )

            troubleCard(
                icon: "clock.badge.exclamationmark.fill",
                title: "勤務時間・曜日を指定されている",
                check: "開始・終了時刻、曜日、休暇の扱い、シフト提出や勤怠報告の方法を整理。",
                evidence: "タイムカード、カレンダー、シフト表、勤怠連絡、定例会議の予定等を保存。"
            )

            troubleCard(
                icon: "building.2.fill",
                title: "出社・勤務場所を指定されている",
                check: "契約上の勤務場所と実際の運用、出社頻度、変更の経緯を確認。",
                evidence: "出社指示、前日の確認連絡、オフィス予定、契約募集時の条件等を保存。"
            )

            troubleCard(
                icon: "phone.arrow.up.right.fill",
                title: "件数・ノルマ・具体的な指示がある",
                check: "件数目標、必達指示、業務手順、ロープレ・トーク指導などの実態を整理。",
                evidence: "チャット、業務マニュアル、目標表、日報、会議記録、件数管理画面等を保存。"
            )

            troubleCard(
                icon: "doc.text.fill",
                title: "契約内容と実際の働き方が違う",
                check: "契約書・募集条件と、実際の時間・場所・指示・報酬・業務範囲を比較。",
                evidence: "契約書の原本と、実際の運用を示す勤務記録・連絡・カレンダー等を両方保存。"
            )

            VStack(alignment: .leading, spacing: 10) {

                Label("まずやっておきたいこと", systemImage: "checklist.checked")
                    .font(.headline)

                knowledgeRow("元の契約書・発注書を消さずに保管")
                knowledgeRow("LINE・Slack・メールは日時が分かる形で保存")
                knowledgeRow("勤務日時・休憩・業務内容を継続して記録")
                knowledgeRow("口頭指示は日時・相手・内容をメモ")
                knowledgeRow("重要な出来事はPDFレポートでも整理")
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding()
            .background(Color.gray.opacity(0.09))
            .cornerRadius(16)

            VStack(spacing: 10) {

                Button {
                    onOpenMessageOrganizer()
                } label: {
                    Label("文章を整理する", systemImage: "text.viewfinder")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.bordered)

                Button {
                    onCreateEvidence()
                } label: {
                    Label("証拠・メモを残す", systemImage: "doc.badge.plus")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.bordered)

                Button {
                    onOpenConsultation()
                } label: {
                    Label("相談先・次の行動を見る", systemImage: "questionmark.bubble.fill")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
            }

            Text("※状況整理のための一般的な案内です。個別の違法性、労働者性、契約解除の有効性、請求の可否などを判定するものではありません。")
                .font(.caption)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)

            Button("ホームに戻る") {
                onHome()
            }
            .buttonStyle(.bordered)
        }
    }

    private func troubleCard(
        icon: String,
        title: String,
        check: String,
        evidence: String
    ) -> some View {

        VStack(alignment: .leading, spacing: 10) {

            Label(title, systemImage: icon)
                .font(.headline)

            VStack(alignment: .leading, spacing: 4) {

                Text("確認すること")
                    .font(.caption)
                    .bold()
                    .foregroundStyle(.secondary)

                Text(check)
                    .font(.subheadline)
            }

            Divider()

            VStack(alignment: .leading, spacing: 4) {

                Text("残しておきたい記録")
                    .font(.caption)
                    .bold()
                    .foregroundStyle(.secondary)

                Text(evidence)
                    .font(.subheadline)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(Color.gray.opacity(0.09))
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(Color.primary.opacity(0.07), lineWidth: 1)
        )
        .cornerRadius(16)
    }

    private func knowledgeRow(_ text: String) -> some View {

        HStack(alignment: .top, spacing: 8) {

            Image(systemName: "checkmark.circle.fill")
                .font(.subheadline)

            Text(text)
                .font(.subheadline)

            Spacer()
        }
    }
}
