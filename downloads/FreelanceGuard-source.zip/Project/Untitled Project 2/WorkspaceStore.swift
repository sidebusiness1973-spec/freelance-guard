import Foundation
import Combine

protocol WorkspaceStorage {
    func read() -> Data?
    func write(_ data: Data)
}

struct WorkspaceDefaultsStorage: WorkspaceStorage {
    static let key = "freelanceGuardWorkspaceV1"
    var defaults: UserDefaults = .standard
    func read() -> Data? { defaults.data(forKey: Self.key) }
    func write(_ data: Data) { defaults.set(data, forKey: Self.key) }
}

@MainActor
final class WorkspaceStore: ObservableObject {
    @Published private(set) var data = WorkspaceData()
    @Published var errorMessage: String?
    private let storage: any WorkspaceStorage
    private var isReadOnly = false
    var projects: [ProjectContract] { data.projects }
    var lawChecks: [LawCheckSnapshot] { data.lawChecks }

    init(storage: (any WorkspaceStorage)? = nil) {
        self.storage = storage ?? WorkspaceDefaultsStorage()
        guard let raw = self.storage.read() else { return }
        do {
            let decoded = try JSONDecoder().decode(WorkspaceData.self, from: raw)
            guard decoded.version == 1 else { throw CocoaError(.coderReadCorrupt) }
            data = decoded
        } catch {
            isReadOnly = true
            errorMessage = "案件・相談準備データを読み込めませんでした。元の保存データは保持しています。アプリを削除せず、サポートへご相談ください。"
        }
    }

    @discardableResult
    private func commit(_ change: (inout WorkspaceData) -> Void) -> Bool {
        guard !isReadOnly else {
            errorMessage = "元の保存データを保護しているため、案件・相談準備の変更を保存できません。"
            return false
        }
        var updated = data
        change(&updated)
        do {
            let raw = try JSONEncoder().encode(updated)
            storage.write(raw)
            data = updated
            return true
        } catch {
            errorMessage = "保存できませんでした。入力内容をご確認ください。"
            return false
        }
    }

    @discardableResult
    func saveProject(_ project: ProjectContract) -> Bool {
        guard project.isValid else { errorMessage = "案件名と契約期間を確認してください。"; return false }
        return commit { state in
            if let index = state.projects.firstIndex(where: { $0.id == project.id }) { state.projects[index] = project }
            else { state.projects.append(project) }
        }
    }

    @discardableResult
    func deleteProject(_ id: UUID) -> Bool {
        commit { state in
            state.projects.removeAll { $0.id == id }
            state.preparations.removeValue(forKey: id.uuidString)
        }
    }

    @discardableResult
    func saveLawCheck(answers: [Bool], summary: String) -> Bool {
        commit { $0.lawChecks.append(LawCheckSnapshot(answers: answers, summary: summary)) }
    }

    @discardableResult
    func deleteLawCheck(_ id: UUID) -> Bool { commit { $0.lawChecks.removeAll { $0.id == id } } }

    func preparation(for projectID: UUID?) -> ConsultationPreparation {
        data.preparations[projectID?.uuidString ?? "all"] ?? ConsultationPreparation()
    }

    @discardableResult
    func savePreparation(_ preparation: ConsultationPreparation, projectID: UUID?) -> Bool {
        commit { $0.preparations[projectID?.uuidString ?? "all"] = preparation }
    }

    func projectName(_ id: UUID?) -> String {
        projects.first(where: { $0.id == id })?.name ?? "案件なし"
    }
}
