import SwiftUI

struct ConsultationPreparationView: View {
    @ObservedObject var store: WorkspaceStore
    let work: [WorkRecord]
    let entries: [ActivityEntry]
    @Binding var projectID: UUID?
    let onOpen: (ActivityEntry) -> Void
    let onProjects: () -> Void
    @State private var question = ""
    @State private var shareURL: URL?
    @State private var showingShare = false
    @State private var pdfError: String?
    @State private var noteSaved = false
    @State private var isCreatingPDF = false
    private var preparation: ConsultationPreparation { store.preparation(for: projectID) }
    private var selectedEntries: [ActivityEntry] {
        WorkspaceActivity.filtered(entries.filter { projectID == nil || $0.projectID == projectID || $0.kind == .check || $0.kind == .law })
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            Text("相談準備").font(.largeTitle.bold())
            Text("記録を見返し、相談先へ伝えたいことを自分で整理します。法律相談や法的判断を行う機能ではありません。")
                .foregroundStyle(.secondary)
            WorkspaceCard {
                ProjectPicker(projects: store.projects, selection: $projectID, allRecords: true)
                if let project = store.projects.first(where: { $0.id == projectID }) {
                    DisclosureGroup("案件の基本情報") { Text(project.summary).textSelection(.enabled) }
                } else { Text("案件を選ぶと、その案件の勤務・証拠・重要日に絞り込めます。").font(.caption) }
                Button("案件・契約を確認") { onProjects() }.buttonStyle(.bordered)
            }
            WorkspaceCard {
                Text("相談準備チェックリスト").font(.title3.bold())
                ForEach(ConsultationPreparation.labels.indices, id: \.self) { index in
                    Toggle(ConsultationPreparation.labels[index], isOn: Binding(get: { preparation.isChecked(index) }, set: { checked in
                        var changed = preparation
                        while changed.checked.count < ConsultationPreparation.labels.count { changed.checked.append(false) }
                        changed.checked[index] = checked
                        _ = store.savePreparation(changed, projectID: projectID)
                    }))
                }
                Text("チェック状態は案件ごとに端末内へ保存します。").font(.caption).foregroundStyle(.secondary)
            }
            WorkspaceCard {
                Text("相談したい内容").font(.headline)
                TextField("確認したいこと・伝えたい経緯", text: $question, axis: .vertical).lineLimit(4...12).textFieldStyle(.roundedBorder)
                Text("入力内容は自動保存されます。").font(.caption).foregroundStyle(.secondary)
                Button("相談メモを保存") { saveQuestion() }.buttonStyle(.bordered)
                if noteSaved { Text("保存しました").font(.caption).foregroundStyle(.secondary) }
            }
            Text("整理する記録").font(.title2.bold())
            Text("働き方・フリーランス法チェックは、案件に紐づかない全体の履歴として表示します。以前メモに保存した法チェックは「証拠・メモ」に表示します。")
                .font(.caption).foregroundStyle(.secondary)
            ForEach([ActivityKind.work, .evidence, .deadline, .check, .law]) { kind in
                recordSection(kind)
            }
            WorkspaceCard {
                Text("相談準備レポート").font(.title3.bold())
                Text("選択した案件の情報・記録とチェック状況をPDFにまとめます。共有先は、作成後にご自身で選べます。")
                Button {
                    guard !isCreatingPDF else { return }
                    isCreatingPDF = true
                    defer { isCreatingPDF = false }
                    var latest = preparation
                    latest.question = question
                    guard store.savePreparation(latest, projectID: projectID) else { return }
                    do {
                        let document = ConsultationReportDocument.make(projectID: projectID, projects: store.projects,
                            work: work, entries: entries, preparation: latest)
                        shareURL = try ConsultationPDFExporter.create(document)
                        showingShare = true
                    } catch { pdfError = "PDFを作成できませんでした。端末の空き容量を確認して、もう一度お試しください。" }
                } label: { Label("相談準備PDFを作成・共有", systemImage: "square.and.arrow.up") }
                .buttonStyle(.borderedProminent).disabled(isCreatingPDF).accessibilityIdentifier("createConsultationPDF")
            }
        }
        .onAppear { question = preparation.question }
        .onChange(of: projectID) { _, _ in question = preparation.question; noteSaved = false }
        .onChange(of: question) { _, value in
            // 案件切り替えによる表示更新は、保存済みの内容と同じなので書き込まない。
            guard value != preparation.question else { return }
            var updated = preparation; updated.question = value
            _ = store.savePreparation(updated, projectID: projectID)
            noteSaved = false
        }
        .sheet(isPresented: $showingShare, onDismiss: {
            if let url = shareURL { try? FileManager.default.removeItem(at: url) }
            shareURL = nil
        }) { if let shareURL { ShareSheet(items: [shareURL]) } }
        .alert("PDFの作成", isPresented: Binding(get: { pdfError != nil }, set: { if !$0 { pdfError = nil } })) {
            Button("OK", role: .cancel) { pdfError = nil }
        } message: { Text(pdfError ?? "") }
    }

    private func saveQuestion() {
        var changed = preparation; changed.question = question
        noteSaved = store.savePreparation(changed, projectID: projectID)
    }
    private func recordSection(_ kind: ActivityKind) -> some View {
        let records = selectedEntries.filter { $0.kind == kind }
        return WorkspaceCard {
            DisclosureGroup("\(kind.rawValue)　\(records.count)件") {
                if records.isEmpty { Text("保存された記録はありません。").foregroundStyle(.secondary) }
                ForEach(records) { entry in
                    VStack(alignment: .leading, spacing: 8) {
                        ActivitySummary(entry: entry, projectName: store.projectName(entry.projectID))
                        Text(entry.details).font(.subheadline).textSelection(.enabled)
                        Button("記録を開く") { onOpen(entry) }.buttonStyle(.bordered)
                        Divider()
                    }.padding(.top, 10)
                }
            }
        }
    }
}

struct LawCheckHistoryView: View {
    @ObservedObject var store: WorkspaceStore
    let onNew: () -> Void
    @State private var deleting: LawCheckSnapshot?
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("フリーランス法チェック履歴").font(.title.bold())
            Button("チェックを始める", action: onNew).buttonStyle(.borderedProminent)
            if store.lawChecks.isEmpty { Text("履歴はまだありません。以前メモに保存した結果は、証拠・メモから確認できます。") }
            ForEach(store.lawChecks.sorted { $0.date > $1.date }) { item in
                WorkspaceCard {
                    Text(WorkspaceFormat.date(item.date)).font(.headline)
                    Text(item.summary).textSelection(.enabled)
                    Button("履歴を削除", role: .destructive) { deleting = item }
                }
            }
        }.alert("このチェック履歴を削除しますか？", isPresented: Binding(get: { deleting != nil }, set: { if !$0 { deleting = nil } })) {
            Button("キャンセル", role: .cancel) { deleting = nil }
            Button("削除", role: .destructive) { if let item = deleting { store.deleteLawCheck(item.id) }; deleting = nil }
        }
    }
}
