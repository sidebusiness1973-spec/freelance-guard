import SwiftUI

struct AboutView: View {

    let onOpenConsultation: () -> Void
    let onBackToSettings: () -> Void

    var body: some View {

        VStack(spacing: 18) {

            VStack(spacing: 7) {

                Image(systemName: "shield.checkered")
                    .font(.system(size: 38, weight: .semibold))
                    .foregroundStyle(.blue)

                Text("FreelanceGuard")
                    .font(.title2)
                    .bold()

                Text("働き方を確認し、日々の記録を整理するためのサポートアプリ")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }

            infoCard(
                title: "このアプリでできること",
                icon: "checkmark.circle.fill",
                text: "働き方チェック、勤務記録、仕事に関する証拠・メモの整理、契約の基礎知識の確認、保存した情報のPDFレポート作成を行えます。"
            )

            infoCard(
                title: "法的判断について",
                icon: "scale.3d",
                text: "このアプリのチェック結果や説明文は一般的な情報整理を目的としており、労働者性、契約の有効性、違法性、請求可能額などを個別に判定するものではありません。"
            )

            infoCard(
                title: "重要な判断が必要な場合",
                icon: "person.crop.circle.badge.questionmark",
                text: "契約解除、報酬未払い、損害賠償、労働者性など個別事情によって結論が変わる問題は、契約書や実際の記録を持って、弁護士や行政の相談窓口などへ相談してください。"
            )

            infoCard(
                title: "記録について",
                icon: "externaldrive.fill",
                text: "重要な記録はアプリだけに依存せず、元のメール・チャット・契約書・ファイル等も保管してください。PDFレポートは情報整理や相談時の資料作成を補助するための機能です。"
            )

            Text("掲載内容は一般的な情報提供を目的としています。法令・制度は改正されることがあります。")
                .font(.caption)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)

            HStack {

                Button("相談先を見る") {
                    onOpenConsultation()
                }
                .buttonStyle(.bordered)

                Button("設定に戻る") {
                    onBackToSettings()
                }
                .buttonStyle(.borderedProminent)
            }
        }
    }

    private func infoCard(
        title: String,
        icon: String,
        text: String
    ) -> some View {

        VStack(alignment: .leading, spacing: 9) {

            Label(title, systemImage: icon)
                .font(.headline)

            Text(text)
                .font(.subheadline)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(Color.gray.opacity(0.09))
        .cornerRadius(16)
    }
}
