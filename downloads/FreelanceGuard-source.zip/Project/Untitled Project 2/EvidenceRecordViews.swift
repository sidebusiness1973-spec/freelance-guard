import SwiftUI

struct EvidenceRecordEditorView: View {

    @Binding var evidenceDate: Date
    @Binding var evidenceType: String
    @Binding var evidenceTitle: String
    @Binding var evidenceDetails: String

    @Binding var editingEvidenceRecord: EvidenceRecord?
    @Binding var showEvidenceSavedAlert: Bool

    let evidenceTypes: [String]
    let evidenceRecords: [EvidenceRecord]

    let onSave: () -> Void
    let onShowHistory: () -> Void
    let onHome: () -> Void

    var body: some View {

        VStack(spacing: 18) {

            VStack(spacing: 6) {
                Image(
                    systemName: editingEvidenceRecord == nil
                    ? "doc.badge.plus"
                    : "pencil.and.outline"
                )
                .font(.system(size: 34, weight: .semibold))

                Text(
                    editingEvidenceRecord == nil
                    ? "証拠・メモを記録"
                    : "証拠・メモを編集"
                )
                .font(.title2)
                .bold()

                Text("LINE・Slack・メール・勤務指示などを整理して残します")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }

            VStack(alignment: .leading, spacing: 15) {
                Label("基本情報", systemImage: "doc.text")
                    .font(.headline)

                DatePicker(
                    "日付",
                    selection: $evidenceDate,
                    displayedComponents: [.date, .hourAndMinute]
                )

                Picker("種類", selection: $evidenceType) {
                    ForEach(evidenceTypes, id: \.self) { type in
                        Text(type).tag(type)
                    }
                }

                TextField("タイトル", text: $evidenceTitle)
                    .textFieldStyle(.roundedBorder)

                TextField("内容・メモ", text: $evidenceDetails, axis: .vertical)
                    .textFieldStyle(.roundedBorder)
                    .lineLimit(4...9)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding()
            .background(Color.gray.opacity(0.09))
            .cornerRadius(16)

            Button {
                onSave()
            } label: {
                Label(
                    editingEvidenceRecord == nil
                    ? "証拠・メモを保存"
                    : "変更内容を保存",
                    systemImage: "square.and.arrow.down.fill"
                )
            }
            .buttonStyle(.borderedProminent)
            .disabled(
                evidenceTitle
                    .trimmingCharacters(in: .whitespacesAndNewlines)
                    .isEmpty
            )
            .alert(
                editingEvidenceRecord == nil
                ? "証拠・メモを保存しました"
                : "証拠・メモを更新しました",
                isPresented: $showEvidenceSavedAlert
            ) {
                Button("OK", role: .cancel) {}
            }

            HStack {
                if !evidenceRecords.isEmpty {
                    Button("証拠・メモを見る") {
                        onShowHistory()
                    }
                    .buttonStyle(.bordered)
                }

                Button("ホームに戻る") {
                    onHome()
                }
                .buttonStyle(.bordered)
            }
        }
    }
}

struct EvidenceHistoryView: View {

    let evidenceRecords: [EvidenceRecord]

    @Binding var evidenceToDelete: EvidenceRecord?
    @Binding var showEvidenceDeleteAlert: Bool

    let onEdit: (EvidenceRecord) -> Void
    let onDelete: (EvidenceRecord) -> Void
    let onNew: () -> Void
    let onHome: () -> Void

    var body: some View {

        VStack(spacing: 18) {

            VStack(spacing: 6) {
                Image(systemName: "doc.text.magnifyingglass")
                    .font(.system(size: 34, weight: .semibold))

                Text("証拠・メモ")
                    .font(.title2)
                    .bold()

                Text("保存した連絡・指示・メモを時系列で確認できます")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }

            if evidenceRecords.isEmpty {
                ContentUnavailableView(
                    "証拠・メモはまだありません",
                    systemImage: "doc.text",
                    description: Text(
                        "仕事に関する連絡や指示を整理して残しておきましょう。"
                    )
                )
            } else {
                ForEach(evidenceRecords.reversed()) { record in
                    VStack(alignment: .leading, spacing: 10) {

                        HStack {
                            Label(
                                record.date.formatted(
                                    date: .numeric,
                                    time: .shortened
                                ),
                                systemImage: "calendar"
                            )
                            .font(.headline)

                            Spacer()

                            Text(record.type)
                                .font(.caption)
                                .padding(.horizontal, 8)
                                .padding(.vertical, 4)
                                .background(Color.gray.opacity(0.14))
                                .clipShape(Capsule())
                        }

                        Text(record.title)
                            .font(.headline)

                        Text(
                            record.details.isEmpty
                            ? "内容の記録なし"
                            : record.details
                        )
                        .font(.subheadline)
                        .foregroundStyle(.secondary)

                        HStack {
                            Button {
                                onEdit(record)
                            } label: {
                                Label("編集", systemImage: "pencil")
                            }
                            .buttonStyle(.bordered)

                            Spacer()

                            Button(role: .destructive) {
                                evidenceToDelete = record
                                showEvidenceDeleteAlert = true
                            } label: {
                                Label("削除", systemImage: "trash")
                            }
                            .buttonStyle(.bordered)
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding()
                    .background(Color.gray.opacity(0.09))
                    .overlay(
                        RoundedRectangle(cornerRadius: 16)
                            .stroke(
                                Color.primary.opacity(0.07),
                                lineWidth: 1
                            )
                    )
                    .cornerRadius(16)
                }
            }

            HStack {
                Button("新しいメモ") {
                    onNew()
                }
                .buttonStyle(.bordered)

                Button("ホームに戻る") {
                    onHome()
                }
                .buttonStyle(.borderedProminent)
            }
        }
        .alert(
            "証拠・メモを削除しますか？",
            isPresented: $showEvidenceDeleteAlert
        ) {
            Button("キャンセル", role: .cancel) {
                evidenceToDelete = nil
            }

            Button("削除", role: .destructive) {
                if let record = evidenceToDelete {
                    onDelete(record)
                }
                evidenceToDelete = nil
            }
        } message: {
            Text("削除した証拠・メモは元に戻せません。")
        }
    }
}
