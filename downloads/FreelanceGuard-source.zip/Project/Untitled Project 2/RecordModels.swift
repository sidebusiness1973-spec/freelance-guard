import Foundation

struct CheckHistory: Identifiable, Codable {

    var id = UUID()

    let date: Date

    let yesCount: Int

    let answers: [Bool]

}

struct WorkRecord: Identifiable, Codable {

    var id = UUID()

    let date: Date

    let startTime: Date

    let endTime: Date

    let instruction: String

    let details: String

    let breakMinutes: Int

    let memo: String

    var projectID: UUID? = nil

}









struct EvidenceRecord: Identifiable, Codable {

    var id = UUID()

    let date: Date

    let type: String

    let title: String

    let details: String

    var projectID: UUID? = nil

}

struct ImportantDateRecord: Identifiable, Codable {

    var id = UUID()

    let date: Date

    let type: String

    let title: String

    let memo: String

    var projectID: UUID? = nil

}

