import SwiftUI

struct HomeView: View {

    let workRecordCountText: String
    let evidenceRecordCountText: String
    let importantDateSubtitle: String

    let checkCount: Int
    let workRecordCount: Int
    let evidenceRecordCount: Int

    let isPlusUnlocked: Bool

    let onFirstUseGuide: () -> Void
    let onStartWorkStyleCheck: () -> Void
    let onOpenFreelanceLawCheck: () -> Void
    let onNewWorkRecord: () -> Void
    let onNewEvidenceRecord: () -> Void
    let onOpenImportantDates: () -> Void
    let onOpenMessageOrganizer: () -> Void
    let onOpenTroubleGuide: () -> Void
    let onOpenEvidenceChecklist: () -> Void
    let onOpenConsultation: () -> Void
    let onOpenDocumentDraft: () -> Void
    let onOpenPremium: () -> Void
    let onOpenReport: () -> Void
    let onOpenContractGuide: () -> Void
    let onOpenPrivacyInfo: () -> Void
    let onOpenSettings: () -> Void

    var body: some View {

        VStack(spacing: 22) {

            if workRecordCount == 0 && evidenceRecordCount == 0 {

                Button {
                    onFirstUseGuide()
                } label: {

                    HStack(spacing: 14) {

                        Image(systemName: "sparkles")
                            .font(.title3.bold())
                            .foregroundStyle(.blue)
                            .frame(width: 36, height: 36)
                            .background(Color.blue.opacity(0.10))
                            .clipShape(RoundedRectangle(cornerRadius: 10))

                        VStack(alignment: .leading, spacing: 4) {

                            Text("はじめての記録")
                                .font(.headline)
                                .foregroundStyle(.primary)

                            Text("まず1件残して、記録がどう役立つか体験してみましょう")
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                                .multilineTextAlignment(.leading)
                        }

                        Spacer()

                        Image(systemName: "chevron.right")
                            .foregroundStyle(.secondary)
                    }
                    .padding(16)
                    .background(Color.blue.opacity(0.07))
                    .clipShape(RoundedRectangle(cornerRadius: 18))
                }
                .buttonStyle(.plain)
            }

            sectionTitle("チェックする")

            Button {
                onStartWorkStyleCheck()
            } label: {
                featuredCard(
                    icon: "checkmark.shield.fill",
                    title: "働き方をチェック",
                    subtitle: "15問で現在の働き方を整理",
                    badge: "約2分"
                )
            }
            .buttonStyle(.plain)

            Button {
                onOpenFreelanceLawCheck()
            } label: {
                card(
                    icon: "checkmark.seal.fill",
                    title: "フリーランス法チェック",
                    subtitle: "取引条件・報酬・解除など7項目を確認"
                )
            }
            .buttonStyle(.plain)

            sectionTitle("記録する")

            HStack(spacing: 12) {

                Button {
                    onNewWorkRecord()
                } label: {
                    compactCard(
                        icon: "clock.fill",
                        title: "勤務記録",
                        subtitle: workRecordCountText
                    )
                }
                .buttonStyle(.plain)

                Button {
                    onNewEvidenceRecord()
                } label: {
                    compactCard(
                        icon: "doc.text.fill",
                        title: "証拠・メモ",
                        subtitle: evidenceRecordCountText
                    )
                }
                .buttonStyle(.plain)
            }

            if PlusAccessConfig.isPurchasingEnabled && !isPlusUnlocked && (workRecordCount >= 3 || evidenceRecordCount >= 3) {

                HStack(alignment: .top, spacing: 10) {

                    Image(systemName: "shield.lefthalf.filled")
                        .foregroundStyle(.blue)

                    VStack(alignment: .leading, spacing: 4) {

                        Text("記録が増えてきました")
                            .font(.subheadline)
                            .bold()

                        Text("大切なのは、困ってから思い出すことではなく、普段から残しておくこと。Plusでは記録を無制限に残せる予定です。")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }

                    Spacer()
                }
                .padding(14)
                .background(Color.blue.opacity(0.06))
                .clipShape(RoundedRectangle(cornerRadius: 16))
            }

            Button {
                onOpenImportantDates()
            } label: {
                card(
                    icon: "calendar.badge.clock",
                    title: "期限・重要日",
                    subtitle: importantDateSubtitle
                )
            }
            .buttonStyle(.plain)

            Button {
                onOpenMessageOrganizer()
            } label: {
                card(
                    icon: "text.viewfinder",
                    title: "文章を整理",
                    subtitle: "LINE・Slack・メール等から重要情報を抽出"
                )
            }
            .buttonStyle(.plain)

            sectionTitle("困ったとき")

            Button {
                onOpenTroubleGuide()
            } label: {
                card(
                    icon: "lifepreserver.fill",
                    title: "トラブル対応",
                    subtitle: "状況別に確認事項・残す記録・次の行動を整理"
                )
            }
            .buttonStyle(.plain)

            Button {
                onOpenEvidenceChecklist()
            } label: {
                card(
                    icon: "checklist.checked",
                    title: "証拠チェックリスト",
                    subtitle: "ケース別に残しておきたい記録を確認"
                )
            }
            .buttonStyle(.plain)

            Button {
                onOpenConsultation()
            } label: {
                card(
                    icon: "questionmark.bubble.fill",
                    title: "相談先・次の行動",
                    subtitle: "困ったときの相談先候補を整理"
                )
            }
            .buttonStyle(.plain)

            Button {
                onOpenDocumentDraft()
            } label: {
                card(
                    icon: "doc.text.fill",
                    title: "文書作成サポート",
                    subtitle: "督促・契約確認などの文案を整理"
                )
            }
            .buttonStyle(.plain)

            sectionTitle("資料・設定")

            if PlusAccessConfig.isPurchasingEnabled {
            Button {
                onOpenPremium()
            } label: {
                card(
                    icon: "crown.fill",
                    title: "守りナビ Plus",
                    subtitle: isPlusUnlocked
                        ? "Plus利用中"
                        : "全履歴・完全版PDF・記録整理をもっと便利に"
                )
            }
            .buttonStyle(.plain)
            }

            Button {
                onOpenReport()
            } label: {
                card(
                    icon: "chart.bar.doc.horizontal.fill",
                    title: "レポート",
                    subtitle: "記録をまとめて確認・PDF出力"
                )
            }
            .buttonStyle(.plain)

            Button {
                onOpenContractGuide()
            } label: {
                card(
                    icon: "book.closed.fill",
                    title: "契約の基礎知識",
                    subtitle: "委任・準委任・請負の違いを確認"
                )
            }
            .buttonStyle(.plain)

            Button {
                onOpenPrivacyInfo()
            } label: {
                card(
                    icon: "hand.raised.fill",
                    title: "プライバシー・データ",
                    subtitle: "保存場所・データの扱いを確認"
                )
            }
            .buttonStyle(.plain)

            Button {
                onOpenSettings()
            } label: {
                card(
                    icon: "gearshape.fill",
                    title: "設定・このアプリについて",
                    subtitle: "免責事項・保存データ・アプリ情報"
                )
            }
            .buttonStyle(.plain)

            HStack(spacing: 6) {

                Image(systemName: "externaldrive.fill")

                Text("保存済み")
                    .bold()

                Text("チェック \(checkCount)件")
                Text("・")
                Text("勤務 \(workRecordCount)件")
                Text("・")
                Text("メモ \(evidenceRecordCount)件")
            }
            .font(.caption)
            .foregroundStyle(.secondary)

            Text("記録整理を支援するアプリです。法的判断や個別の法律相談に代わるものではありません。")
                .font(.caption2)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 8)
        }
    }

    private func sectionTitle(_ title: String) -> some View {

        HStack {

            Text(title)
                .font(.headline)

            Spacer()
        }
        .padding(.top, 4)
    }

    private func featuredCard(
        icon: String,
        title: String,
        subtitle: String,
        badge: String
    ) -> some View {

        HStack(spacing: 16) {

            Image(systemName: icon)
                .font(.title)
                .foregroundStyle(.blue)
                .frame(width: 44)

            VStack(alignment: .leading, spacing: 5) {

                HStack {

                    Text(title)
                        .font(.headline)

                    Text(badge)
                        .font(.caption2)
                        .padding(.horizontal, 7)
                        .padding(.vertical, 3)
                        .background(Color.gray.opacity(0.15))
                        .clipShape(Capsule())
                }

                Text(subtitle)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            Image(systemName: "chevron.right")
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding()
        .background(Color.gray.opacity(0.10))
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(Color.primary.opacity(0.08), lineWidth: 1)
        )
        .cornerRadius(16)
    }

    private func compactCard(
        icon: String,
        title: String,
        subtitle: String
    ) -> some View {

        VStack(alignment: .leading, spacing: 10) {

            Image(systemName: icon)
                .font(.title2)
                .foregroundStyle(.blue)

            Text(title)
                .font(.headline)

            Text(subtitle)
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, minHeight: 90, alignment: .leading)
        .padding()
        .background(Color.gray.opacity(0.10))
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(Color.primary.opacity(0.08), lineWidth: 1)
        )
        .cornerRadius(16)
    }

    private func card(
        icon: String,
        title: String,
        subtitle: String
    ) -> some View {

        HStack(spacing: 16) {

            Image(systemName: icon)
                .font(.title2)
                .foregroundStyle(.blue)
                .frame(width: 38)

            VStack(alignment: .leading, spacing: 5) {

                Text(title)
                    .font(.headline)

                Text(subtitle)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            Image(systemName: "chevron.right")
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding()
        .background(Color.gray.opacity(0.10))
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(Color.primary.opacity(0.08), lineWidth: 1)
        )
        .cornerRadius(16)
    }
}
