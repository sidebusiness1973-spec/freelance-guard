import SwiftUI

struct MessageOrganizerView: View {

    @Binding var organizerText: String
    @Binding var organizerResult: String
    @Binding var organizerSavedAlert: Bool

    let onOrganize: () -> Void
    let onSaveToEvidence: () -> Void
    let onClear: () -> Void
    let onHome: () -> Void

    var body: some View {

        VStack(spacing: 18) {

            VStack(spacing: 7) {

                Image(systemName: "text.viewfinder")
                    .font(.system(size: 36, weight: .semibold))

                Text("文章を整理")
                    .font(.title2)
                    .bold()

                Text("LINE・Slack・メールなどの文章を貼り付けて、記録に必要な情報を整理します")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }

            VStack(alignment: .leading, spacing: 10) {

                Label("元の文章", systemImage: "doc.on.clipboard")
                    .font(.headline)

                TextField(
                    "ここに文章を貼り付けてください",
                    text: $organizerText,
                    axis: .vertical
                )
                .textFieldStyle(.roundedBorder)
                .lineLimit(8...16)

                Text("\(organizerText.count)文字")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding()
            .background(Color.gray.opacity(0.09))
            .cornerRadius(16)

            Button {
                onOrganize()
            } label: {
                Label("文章を整理する", systemImage: "wand.and.stars")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .disabled(
                organizerText
                    .trimmingCharacters(in: .whitespacesAndNewlines)
                    .isEmpty
            )

            if !organizerResult.isEmpty {

                VStack(alignment: .leading, spacing: 10) {

                    Label("整理結果", systemImage: "list.clipboard.fill")
                        .font(.headline)

                    Text(organizerResult)
                        .font(.subheadline)
                        .textSelection(.enabled)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding()
                .background(Color.gray.opacity(0.09))
                .cornerRadius(16)

                Button {
                    onSaveToEvidence()
                } label: {
                    Label(
                        "証拠・メモに保存",
                        systemImage: "square.and.arrow.down.fill"
                    )
                    .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .alert(
                    "証拠・メモに保存しました",
                    isPresented: $organizerSavedAlert
                ) {
                    Button("OK", role: .cancel) {}
                }
            }

            VStack(alignment: .leading, spacing: 8) {

                Label("現在の整理項目", systemImage: "checklist")
                    .font(.headline)

                Text("・日付や時刻に関する記述")
                Text("・勤務時間に関する記述")
                Text("・件数・ノルマ・数量")
                Text("・指示・依頼・命令に関する表現")
                Text("・出社・勤務場所に関する記述")
                Text("・契約解除・終了に関する記述")
            }
            .font(.subheadline)
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding()
            .background(Color.gray.opacity(0.07))
            .cornerRadius(16)

            Text("※現在は端末内のルールで文章を整理する試作版です。法的評価や違法性の判定は行いません。生成AIによる高度な整理機能は今後接続できます。")
                .font(.caption)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)

            HStack {

                Button("入力をクリア") {
                    onClear()
                }
                .buttonStyle(.bordered)

                Button("ホームに戻る") {
                    onHome()
                }
                .buttonStyle(.borderedProminent)
            }
        }
    }
}
