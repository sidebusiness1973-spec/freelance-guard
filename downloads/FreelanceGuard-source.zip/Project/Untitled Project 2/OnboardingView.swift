import SwiftUI

struct OnboardingView: View {

    @Binding var onboardingPage: Int

    let onComplete: () -> Void

    var body: some View {

        VStack(spacing: 22) {

            HStack {

                Spacer()

                if onboardingPage < 2 {

                    Button("スキップ") {
                        onComplete()
                    }
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                }
            }

            Spacer(minLength: 4)

            ZStack {

                Circle()
                    .fill(Color.blue.opacity(0.09))
                    .frame(width: 104, height: 104)

                Image(systemName: onboardingPageIcon)
                    .font(.system(size: 46, weight: .semibold))
                    .foregroundStyle(.blue)
            }

            VStack(spacing: 10) {

                Text(onboardingPageTitle)
                    .font(.title2)
                    .bold()
                    .multilineTextAlignment(.center)

                Text(onboardingPageMessage)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .lineSpacing(3)
            }

            VStack(spacing: 12) {

                if onboardingPage == 0 {

                    onboardingRow(
                        "checkmark.shield.fill",
                        "約2分で働き方を整理",
                        "15問のチェックから始められます"
                    )

                    onboardingRow(
                        "doc.text.fill",
                        "記録をひとつに",
                        "勤務・証拠メモ・重要日をまとめて保存"
                    )

                } else if onboardingPage == 1 {

                    onboardingRow(
                        "clock.badge.checkmark.fill",
                        "勤務時間を残す",
                        "開始・終了・休憩・業務内容を記録"
                    )

                    onboardingRow(
                        "bubble.left.and.text.bubble.right.fill",
                        "指示や変更を残す",
                        "LINE・Slack・メールなどの内容を整理"
                    )

                    onboardingRow(
                        "calendar.badge.clock",
                        "重要な日を忘れない",
                        "契約終了・支払・回答期限などを管理"
                    )

                } else {

                    onboardingRow(
                        "shield.lefthalf.filled",
                        "困る前から少しずつ",
                        "普段の記録が、あとで状況を整理する材料になります"
                    )

                    onboardingRow(
                        "doc.richtext.fill",
                        "必要なときにまとめる",
                        "保存した記録を確認し、PDFとして整理できます"
                    )

                    onboardingRow(
                        "crown.fill",
                        "まずは無料でスタート",
                        "日々の記録を案件ごとにまとめ、相談の準備まで進められます"
                    )
                }
            }

            HStack(spacing: 8) {

                ForEach(0..<3, id: \.self) { index in

                    Capsule()
                        .fill(
                            index == onboardingPage
                                ? Color.blue
                                : Color.gray.opacity(0.25)
                        )
                        .frame(
                            width: index == onboardingPage ? 28 : 8,
                            height: 8
                        )
                }
            }
            .animation(.easeInOut(duration: 0.2), value: onboardingPage)

            if onboardingPage == 2 {

                Text("このアプリは記録整理を支援するもので、法的判断や個別の法律相談に代わるものではありません。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }

            Button {

                if onboardingPage < 2 {

                    withAnimation {
                        onboardingPage += 1
                    }

                } else {

                    onComplete()
                }

            } label: {

                HStack {

                    Text(
                        onboardingPage == 2
                            ? "無料ではじめる"
                            : "次へ"
                    )
                    .font(.headline)

                    if onboardingPage < 2 {
                        Image(systemName: "arrow.right")
                    }
                }
                .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.large)

            if onboardingPage > 0 {

                Button("戻る") {

                    withAnimation {
                        onboardingPage -= 1
                    }
                }
                .font(.subheadline)
                .foregroundStyle(.secondary)
            }

            Spacer(minLength: 8)
        }
        .padding(.horizontal, 22)
        .padding(.top, 6)
    }

    private var onboardingPageIcon: String {

        switch onboardingPage {

        case 0:
            return "shield.checkered"

        case 1:
            return "tray.full.fill"

        default:
            return "clock.arrow.circlepath"
        }
    }

    private var onboardingPageTitle: String {

        switch onboardingPage {

        case 0:
            return "働き方を、記録して守る"

        case 1:
            return "記録は、あとから作れないことがあります"

        default:
            return "未来の自分が確認できる形に"
        }
    }

    private var onboardingPageMessage: String {

        switch onboardingPage {

        case 0:
            return "契約や働き方に「これって大丈夫？」と感じたとき、状況と記録をひとつに整理するアプリです。"

        case 1:
            return "今は問題がなくても、勤務時間・業務指示・契約変更・やり取りを日頃から残しておくと、必要なときに振り返りやすくなります。"

        default:
            return "まずは無料版で記録する習慣を。必要になったとき、過去の出来事を時系列で整理しやすくします。"
        }
    }

    private func onboardingRow(
        _ icon: String,
        _ title: String,
        _ subtitle: String
    ) -> some View {

        HStack(spacing: 14) {

            Image(systemName: icon)
                .font(.title2)
                .foregroundStyle(.blue)
                .frame(width: 34)

            VStack(alignment: .leading, spacing: 3) {

                Text(title)
                    .font(.headline)

                Text(subtitle)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }

            Spacer()
        }
        .frame(maxWidth: .infinity)
        .padding()
        .background(Color.gray.opacity(0.08))
        .clipShape(RoundedRectangle(cornerRadius: 18))
    }
}
