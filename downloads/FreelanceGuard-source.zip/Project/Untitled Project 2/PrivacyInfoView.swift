import SwiftUI

struct PrivacyInfoView: View {

    let onHome: () -> Void

    var body: some View {

        VStack(spacing: 22) {

            VStack(spacing: 10) {

                ZStack {

                    Circle()
                        .fill(Color.blue.opacity(0.10))
                        .frame(width: 78, height: 78)

                    Image(systemName: "hand.raised.fill")
                        .font(.system(size: 34, weight: .semibold))
                        .foregroundStyle(.blue)
                }

                Text("プライバシー・データ")
                    .font(.largeTitle)
                    .bold()

                Text("記録する前に、データの扱いを確認できます")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }

            privacyCard(
                icon: "iphone",
                title: "現在の保存場所",
                text: "チェック結果・勤務記録・証拠メモ・重要日・案件情報・相談準備の内容は、この端末内に保存します。"
            )

            privacyCard(
                icon: "lock.shield.fill",
                title: "大切な記録について",
                text: "端末の故障・紛失・アプリ削除などに備え、重要な内容はPDFなどでも別途保管することをおすすめします。"
            )

            privacyCard(
                icon: "doc.text.fill",
                title: "PDFへの書き出し",
                text: "保存した記録はPDFにまとめて確認・共有できます。共有先や保存先は、ご自身で内容を確認して選択してください。"
            )

            privacyCard(
                icon: "sparkles",
                title: "外部への送信",
                text: "本バージョンは入力した記録を開発者のサーバーやAIサービスへ送信しません。PDFの共有先はご自身で選択します。"
            )

            VStack(alignment: .leading, spacing: 9) {

                Label(
                    "記録と共有ファイルの管理",
                    systemImage: "checkmark.seal.fill"
                )
                .font(.headline)
                .foregroundStyle(.blue)

                Text("各画面から記録を削除できます。書き出したPDFや共有済みのファイルは別途管理してください。クラウド対応の共有先へ保存した場合は、そのサービスの設定に従って同期されることがあります。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(16)
            .background(Color.blue.opacity(0.06))
            .clipShape(RoundedRectangle(cornerRadius: 16))

            Button("ホームに戻る") {
                onHome()
            }
            .buttonStyle(.bordered)
        }
        .padding(.horizontal, 4)
    }

    private func privacyCard(
        icon: String,
        title: String,
        text: String
    ) -> some View {

        HStack(alignment: .top, spacing: 14) {

            Image(systemName: icon)
                .font(.title3)
                .foregroundStyle(.blue)
                .frame(width: 30)

            VStack(alignment: .leading, spacing: 5) {

                Text(title)
                    .font(.headline)

                Text(text)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }

            Spacer()
        }
        .padding(17)
        .background(Color.gray.opacity(0.08))
        .clipShape(RoundedRectangle(cornerRadius: 18))
    }
}
