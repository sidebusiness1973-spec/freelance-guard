import SwiftUI

struct ProjectManagementView: View {
    @ObservedObject var store: WorkspaceStore
    let onDelete: (UUID) -> Void
    let onTimeline: (UUID) -> Void
    let onPreparation: (UUID) -> Void
    @State private var query = ""
    @State private var editing: ProjectContract?
    @State private var deleting: ProjectContract?
    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            Text("案件・契約").font(.largeTitle.bold())
            Text("取引先・条件と記録をまとめて、案件ごとの経緯を整理します。").foregroundStyle(.secondary)
            Button { editing = ProjectContract() } label: { Label("案件を追加", systemImage: "plus") }
                .buttonStyle(.borderedProminent).accessibilityIdentifier("addProject")
            TextField("案件名・取引先・仕事内容で検索", text: $query).textFieldStyle(.roundedBorder)
            if store.projects.isEmpty {
                ContentUnavailableView("案件を登録しましょう", systemImage: "folder.badge.plus", description: Text("勤務記録などは、案件を選ばなくても今までどおり使えます。"))
            }
            let projects = store.projects.filter { query.isEmpty || $0.summary.localizedStandardContains(query) }.sorted { $0.createdAt > $1.createdAt }
            if !store.projects.isEmpty && projects.isEmpty { Text("検索に一致する案件はありません。").foregroundStyle(.secondary) }
            ForEach(projects) { project in
                WorkspaceCard {
                    Text(project.name).font(.title3.bold())
                    Text(project.client.isEmpty ? "取引先未入力" : project.client).foregroundStyle(.secondary)
                    Text("\(WorkspaceFormat.date(project.startDate)) ～ \(project.endDate.map(WorkspaceFormat.date) ?? "終了日未定")").font(.caption)
                    DisclosureGroup("契約条件を確認") { Text(project.summary).textSelection(.enabled).padding(.vertical, 8) }
                    ViewThatFits(in: .horizontal) {
                        HStack { actions(project) }
                        VStack(alignment: .leading) { actions(project) }
                    }
                    .buttonStyle(.bordered)
                }
            }
        }
        .sheet(item: $editing) { project in
            ProjectEditorView(project: project) { store.saveProject($0) }
        }
        .alert("案件を削除しますか？", isPresented: Binding(get: { deleting != nil }, set: { if !$0 { deleting = nil } })) {
            Button("キャンセル", role: .cancel) { deleting = nil }
            Button("削除", role: .destructive) {
                if let project = deleting { onDelete(project.id) }
                deleting = nil
            }
        } message: {
            Text("案件情報と、この案件の相談準備チェック・相談メモを削除します。勤務記録・証拠・重要日は削除せず「案件なし」に戻します。")
        }
    }
    @ViewBuilder private func actions(_ project: ProjectContract) -> some View {
        Button("編集") { editing = project }
        Button("経緯を見る") { onTimeline(project.id) }
        Button("相談準備") { onPreparation(project.id) }
        Button("削除", role: .destructive) { deleting = project }
    }
}

struct ProjectEditorView: View {
    @Environment(\.dismiss) private var dismiss
    @State var project: ProjectContract
    let onSave: (ProjectContract) -> Bool
    @State private var saveFailed = false
    var body: some View {
        NavigationStack {
            Form {
                Section("基本情報") {
                    TextField("案件名（必須）", text: $project.name).accessibilityIdentifier("projectName")
                    TextField("取引先名", text: $project.client)
                    TextField("契約形態", text: $project.contractType)
                }
                Section("契約期間") {
                    DatePicker("開始日", selection: $project.startDate, displayedComponents: .date)
                    Toggle("終了日を設定", isOn: Binding(get: { project.endDate != nil }, set: { project.endDate = $0 ? project.startDate : nil }))
                    if project.endDate != nil {
                        DatePicker("終了日", selection: Binding(get: { project.endDate ?? project.startDate }, set: { project.endDate = $0 }), in: project.startDate..., displayedComponents: .date)
                    }
                    if !project.isValid && !project.name.isEmpty { Text("終了日は開始日以降にしてください。").foregroundStyle(.red) }
                }
                Section("報酬・業務") {
                    TextField("報酬（例：月額30万円・税込）", text: $project.compensation)
                    TextField("支払条件", text: $project.paymentTerms, axis: .vertical)
                    TextField("仕事内容", text: $project.jobDescription, axis: .vertical).lineLimit(3...8)
                    TextField("勤務場所", text: $project.workLocation)
                    TextField("備考", text: $project.notes, axis: .vertical).lineLimit(3...8)
                }
            }
            .navigationTitle("案件・契約の編集")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("キャンセル") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存") {
                        project.name = project.name.trimmingCharacters(in: .whitespacesAndNewlines)
                        if onSave(project) { dismiss() } else { saveFailed = true }
                    }.disabled(!project.isValid).accessibilityIdentifier("saveProject")
                }
            }
            .alert("保存できませんでした", isPresented: $saveFailed) { Button("OK", role: .cancel) {} }
        }
    }
}
