import SwiftUI

struct ImportantDatesListView: View {

    let records: [ImportantDateRecord]

    @Binding var importantDateToDelete: ImportantDateRecord?
    @Binding var showImportantDateDeleteAlert: Bool

    let statusText: (Date) -> String
    let statusIcon: (Date) -> String
    let daysFromToday: (Date) -> Int
    let fullDateText: (Date) -> String

    let onEdit: (ImportantDateRecord) -> Void
    let onDelete: (ImportantDateRecord) -> Void
    let onNew: () -> Void
    let onHome: () -> Void

    var body: some View {

        VStack(spacing: 18) {

            VStack(spacing: 7) {

                Image(systemName: "calendar.badge.clock")
                    .font(.system(size: 38, weight: .semibold))

                Text("期限・重要日")
                    .font(.title2)
                    .bold()

                Text("契約終了・支払・回答・更新などの重要な日を、残り日数と一緒に管理します")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }

            if records.isEmpty {

                VStack(spacing: 10) {

                    Image(systemName: "calendar.badge.plus")
                        .font(.largeTitle)

                    Text("まだ重要日は登録されていません")
                        .font(.headline)

                    Text("忘れたくない期限や予定を1件登録してみましょう")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 28)
                .background(Color.gray.opacity(0.09))
                .cornerRadius(16)

            } else {

                ForEach(records) { record in

                    VStack(alignment: .leading, spacing: 11) {

                        HStack(alignment: .top) {

                            VStack(alignment: .leading, spacing: 5) {

                                Label(
                                    fullDateText(record.date),
                                    systemImage: "calendar"
                                )
                                .font(.headline)

                                Label(
                                    statusText(record.date),
                                    systemImage: statusIcon(record.date)
                                )
                                .font(.subheadline)
                                .bold()
                                .foregroundStyle(
                                    daysFromToday(record.date) < 0
                                    ? .red
                                    : .blue
                                )
                            }

                            Spacer()

                            Text(record.type)
                                .font(.caption)
                                .bold()
                                .padding(.horizontal, 9)
                                .padding(.vertical, 5)
                                .background(Color.gray.opacity(0.12))
                                .cornerRadius(10)
                        }

                        Text(record.title)
                            .font(.headline)

                        if !record.memo.isEmpty {
                            Text(record.memo)
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }

                        HStack {

                            Button("編集") {
                                onEdit(record)
                            }
                            .buttonStyle(.bordered)

                            Spacer()

                            Button("削除", role: .destructive) {
                                importantDateToDelete = record
                                showImportantDateDeleteAlert = true
                            }
                            .buttonStyle(.bordered)
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding()
                    .background(Color.gray.opacity(0.09))
                    .overlay(
                        RoundedRectangle(cornerRadius: 16)
                            .stroke(
                                daysFromToday(record.date) < 0
                                ? Color.red.opacity(0.30)
                                : Color.primary.opacity(0.06),
                                lineWidth: 1
                            )
                    )
                    .cornerRadius(16)
                }
            }

            Button {
                onNew()
            } label: {
                Label(
                    "新しい重要日を登録",
                    systemImage: "plus.circle.fill"
                )
                .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)

            Text("※残り日数・超過日数は端末の日付を基準に表示します。この機能は日付の記録・整理用で、法令上・契約上の期限を自動判定するものではありません。重要な期限は契約書や専門家等でも確認してください。")
                .font(.caption)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)

            Button("ホームに戻る") {
                onHome()
            }
            .buttonStyle(.bordered)
        }
        .alert(
            "この重要日を削除しますか？",
            isPresented: $showImportantDateDeleteAlert
        ) {

            Button("削除", role: .destructive) {
                if let target = importantDateToDelete {
                    onDelete(target)
                }
                importantDateToDelete = nil
            }

            Button("キャンセル", role: .cancel) {
                importantDateToDelete = nil
            }
        }
    }
}


struct ImportantDateEditorView: View {

    @Binding var importantDate: Date
    @Binding var importantDateType: String
    @Binding var importantDateTitle: String
    @Binding var importantDateMemo: String
    @Binding var editingImportantDate: ImportantDateRecord?

    let importantDateTypes: [String]

    let statusText: (Date) -> String
    let statusIcon: (Date) -> String
    let daysFromToday: (Date) -> Int

    let onSave: () -> Void
    let onBack: () -> Void

    var body: some View {

        VStack(spacing: 18) {

            VStack(spacing: 7) {

                Image(
                    systemName: editingImportantDate == nil
                    ? "calendar.badge.plus"
                    : "calendar.badge.clock"
                )
                .font(.system(size: 38, weight: .semibold))

                Text(
                    editingImportantDate == nil
                    ? "重要日を登録"
                    : "重要日を編集"
                )
                .font(.title2)
                .bold()

                Text("日付を登録すると、一覧で「あと○日」「今日」「○日超過」を確認できます")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }

            VStack(alignment: .leading, spacing: 14) {

                DatePicker(
                    "日付",
                    selection: $importantDate,
                    displayedComponents: .date
                )

                HStack {

                    Label(
                        statusText(importantDate),
                        systemImage: statusIcon(importantDate)
                    )
                    .font(.subheadline)
                    .bold()
                    .foregroundStyle(
                        daysFromToday(importantDate) < 0
                        ? .red
                        : .blue
                    )

                    Spacer()
                }

                Picker(
                    "種類",
                    selection: $importantDateType
                ) {

                    ForEach(
                        importantDateTypes,
                        id: \.self
                    ) { type in
                        Text(type).tag(type)
                    }

                    if !importantDateTypes.contains(importantDateType) {
                        Text(importantDateType)
                            .tag(importantDateType)
                    }
                }

                TextField(
                    "タイトル（例：○○社への回答期限）",
                    text: $importantDateTitle
                )
                .textFieldStyle(.roundedBorder)

                TextField(
                    "メモ",
                    text: $importantDateMemo,
                    axis: .vertical
                )
                .textFieldStyle(.roundedBorder)
                .lineLimit(4...8)
            }
            .padding()
            .background(Color.gray.opacity(0.09))
            .cornerRadius(16)

            Button {
                onSave()
            } label: {
                Label(
                    editingImportantDate == nil
                    ? "重要日を保存"
                    : "変更を保存",
                    systemImage: "square.and.arrow.down.fill"
                )
                .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .disabled(
                importantDateTitle
                    .trimmingCharacters(in: .whitespacesAndNewlines)
                    .isEmpty
            )

            Button("一覧に戻る") {
                onBack()
            }
            .buttonStyle(.bordered)
        }
    }
}
