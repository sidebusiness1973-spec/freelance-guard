import SwiftUI

struct SettingsView: View {

    let historyCount: Int
    let workRecordCount: Int
    let evidenceRecordCount: Int

    let onOpenReport: () -> Void
    let onOpenAbout: () -> Void
    let onShowOnboarding: () -> Void
    let onHome: () -> Void

    var body: some View {

        VStack(spacing: 18) {

            VStack(spacing: 7) {

                Image(systemName: "gearshape.fill")
                    .font(.system(size: 36, weight: .semibold))

                Text("設定")
                    .font(.title2)
                    .bold()

                Text("保存データとアプリ情報を確認できます")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }

            VStack(alignment: .leading, spacing: 14) {

                Label(
                    "この端末に保存されているデータ",
                    systemImage: "iphone"
                )
                .font(.headline)

                reportRow(
                    title: "チェック結果",
                    count: historyCount,
                    icon: "checkmark.shield"
                )

                Divider()

                reportRow(
                    title: "勤務記録",
                    count: workRecordCount,
                    icon: "clock"
                )

                Divider()

                reportRow(
                    title: "証拠・メモ",
                    count: evidenceRecordCount,
                    icon: "doc.text"
                )

                Text("現在の記録はこのアプリ内で管理しています。端末の故障・アプリ削除等に備え、重要な記録はPDFでも保管してください。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding()
            .background(Color.gray.opacity(0.09))
            .cornerRadius(16)

            Button {
                onOpenReport()
            } label: {
                Label(
                    "PDFレポート・データ確認",
                    systemImage: "doc.richtext"
                )
                .frame(maxWidth: .infinity)
            }
            .buttonStyle(.bordered)

            Button {
                onOpenAbout()
            } label: {
                Label(
                    "このアプリについて・免責事項",
                    systemImage: "info.circle"
                )
                .frame(maxWidth: .infinity)
            }
            .buttonStyle(.bordered)

            Button {
                onShowOnboarding()
            } label: {
                Label(
                    "最初の使い方を見る",
                    systemImage: "questionmark.circle"
                )
                .frame(maxWidth: .infinity)
            }
            .buttonStyle(.bordered)

            VStack(alignment: .leading, spacing: 8) {

                Label(
                    "Ver.1.0 の主な機能",
                    systemImage: "sparkles"
                )
                .font(.headline)

                Text("・働き方チェック／フリーランス法チェック")
                Text("・勤務記録／証拠・メモ／重要日管理")
                Text("・案件・契約／タイムライン／横断検索")
                Text("・相談準備チェックリスト／相談準備PDF")
                Text("・文章整理／ケース別証拠チェック")
                Text("・PDFレポート／相談先・契約の基礎知識")
            }
            .font(.subheadline)
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding()
            .background(Color.gray.opacity(0.07))
            .cornerRadius(16)

            Button("ホームに戻る") {
                onHome()
            }
            .buttonStyle(.borderedProminent)
        }
    }

    private func reportRow(
        title: String,
        count: Int,
        icon: String
    ) -> some View {

        HStack {

            Image(systemName: icon)
                .frame(width: 28)

            Text(title)

            Spacer()

            Text("\(count)件")
                .bold()
        }
    }
}
