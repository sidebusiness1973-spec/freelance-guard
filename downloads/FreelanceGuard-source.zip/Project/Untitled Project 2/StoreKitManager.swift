import Foundation
import StoreKit
import Combine

@MainActor
final class StoreKitManager: ObservableObject {

    // App Store Connectで商品を作成したあと、この2つを正式なProduct IDへ置き換えます。
    static let monthlyProductID = "REPLACE_WITH_MONTHLY_PRODUCT_ID"
    static let yearlyProductID = "REPLACE_WITH_YEARLY_PRODUCT_ID"

    @Published private(set) var products: [Product] = []
    @Published private(set) var purchasedProductIDs: Set<String> = []
    @Published private(set) var isLoading = false
    @Published var statusMessage: String?

    var isConfigured: Bool {
        !Self.monthlyProductID.hasPrefix("REPLACE_")
        && !Self.yearlyProductID.hasPrefix("REPLACE_")
    }

    var hasPlusAccess: Bool {
        purchasedProductIDs.contains(Self.monthlyProductID)
        || purchasedProductIDs.contains(Self.yearlyProductID)
    }

    var monthlyProduct: Product? {
        products.first { $0.id == Self.monthlyProductID }
    }

    var yearlyProduct: Product? {
        products.first { $0.id == Self.yearlyProductID }
    }

    var monthlyDisplayPrice: String {
        monthlyProduct?.displayPrice ?? "¥680"
    }

    var yearlyDisplayPrice: String {
        yearlyProduct?.displayPrice ?? "¥6,800"
    }

    func prepare() async {

        guard isConfigured else {
            statusMessage = "StoreKit基盤は準備済みです。次にApp Store Connectの商品IDを設定します。"
            return
        }

        await loadProducts()
        await refreshPurchasedStatus()
    }

    func loadProducts() async {

        guard isConfigured else { return }

        isLoading = true
        defer { isLoading = false }

        do {

            let ids = [
                Self.monthlyProductID,
                Self.yearlyProductID
            ]

            products = try await Product.products(for: ids)
                .sorted { $0.price < $1.price }

            if products.isEmpty {
                statusMessage = "商品情報を取得できませんでした。App Store Connectの商品設定を確認してください。"
            } else {
                statusMessage = nil
            }

        } catch {

            statusMessage = "商品情報の取得に失敗しました。"
        }
    }

    func purchaseMonthly() async {
        guard let product = monthlyProduct else {
            statusMessage = "月額商品の情報を取得できていません。"
            return
        }

        await purchase(product)
    }

    func purchaseYearly() async {
        guard let product = yearlyProduct else {
            statusMessage = "年額商品の情報を取得できていません。"
            return
        }

        await purchase(product)
    }

    func restorePurchases() async {

        guard isConfigured else {
            statusMessage = "商品ID設定後に購入復元を確認できます。"
            return
        }

        isLoading = true
        defer { isLoading = false }

        do {

            try await AppStore.sync()
            await refreshPurchasedStatus()

            statusMessage = hasPlusAccess
                ? "購入状態を復元しました。"
                : "復元できるPlus購入は見つかりませんでした。"

        } catch {

            statusMessage = "購入状態の復元に失敗しました。"
        }
    }

    func refreshPurchasedStatus() async {

        guard isConfigured else {
            purchasedProductIDs = []
            return
        }

        var purchased: Set<String> = []

        for await result in Transaction.currentEntitlements {

            guard case .verified(let transaction) = result else {
                continue
            }

            guard transaction.revocationDate == nil else {
                continue
            }

            if transaction.productID == Self.monthlyProductID
                || transaction.productID == Self.yearlyProductID {

                purchased.insert(transaction.productID)
            }
        }

        purchasedProductIDs = purchased
    }

    private func purchase(_ product: Product) async {

        isLoading = true
        defer { isLoading = false }

        do {

            let result = try await product.purchase()

            switch result {

            case .success(let verificationResult):

                switch verificationResult {

                case .verified(let transaction):

                    await transaction.finish()
                    await refreshPurchasedStatus()
                    statusMessage = "Plusの購入状態を確認しました。"

                case .unverified:

                    statusMessage = "購入情報を検証できませんでした。"
                }

            case .pending:

                statusMessage = "購入は保留中です。承認後に反映されます。"

            case .userCancelled:

                statusMessage = nil

            @unknown default:

                statusMessage = "購入状態を確認できませんでした。"
            }

        } catch {

            statusMessage = "購入処理を完了できませんでした。"
        }
    }
}
