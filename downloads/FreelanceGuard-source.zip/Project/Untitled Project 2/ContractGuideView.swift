import SwiftUI

struct ContractGuideView: View {

    let onOpenConsultation: () -> Void
    let onHome: () -> Void

    var body: some View {

        VStack(spacing: 18) {

            VStack(spacing: 7) {

                Image(systemName: "book.closed.fill")
                    .font(.system(size: 36, weight: .semibold))

                Text("契約の基礎知識")
                    .font(.title2)
                    .bold()

                Text("委任・準委任・請負の違いと、契約前に確認したいポイント")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }

            contractKnowledgeCard(
                icon: "signature",
                title: "委任契約",
                summary: "法律行為を相手に委託し、相手が承諾する契約です。",
                points: [
                    "例：法律行為に関する事務を専門家などへ委ねる場合",
                    "民法643条が基本。受任者には善良な管理者としての注意義務があります。",
                    "原則として各当事者はいつでも解除できますが、不利な時期の解除では損害賠償が問題になる場合があります。"
                ]
            )

            contractKnowledgeCard(
                icon: "person.crop.rectangle.stack",
                title: "準委任契約",
                summary: "法律行為ではない事務・業務を委託する契約で、委任の規定が準用されます。",
                points: [
                    "例：営業支援、コンサルティング、システム運用など、業務の遂行を委託する場面",
                    "民法656条により委任の規定が準用されます。",
                    "一般に『仕事を完成させること』そのものを目的とする請負とは区別して考えます。"
                ]
            )

            contractKnowledgeCard(
                icon: "hammer.fill",
                title: "請負契約・請負業務",
                summary: "請負人が仕事の完成を約束し、注文者がその仕事の結果に対して報酬を支払う契約です。",
                points: [
                    "民法632条が基本。成果物の制作・修理・開発などで利用されます。",
                    "『業務を行った時間』よりも『約束した仕事が完成したか』が重要になる契約類型です。",
                    "完成の定義、検収方法、納期、修正範囲、報酬・支払条件を具体的にしておくことが重要です。"
                ]
            )

            VStack(alignment: .leading, spacing: 10) {

                Label("契約前に確認したいこと", systemImage: "checklist.checked")
                    .font(.headline)

                knowledgeRow("誰と誰の契約か／契約期間・更新")
                knowledgeRow("業務内容・成果物・業務範囲")
                knowledgeRow("報酬額・計算方法・支払期日")
                knowledgeRow("業務を行う場所・日時などの条件")
                knowledgeRow("経費負担・機材・アカウント等の扱い")
                knowledgeRow("検収・修正・再作業の条件")
                knowledgeRow("中途解除・不更新・損害賠償の条件")
                knowledgeRow("秘密保持・知的財産権・成果物の権利")
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding()
            .background(Color.gray.opacity(0.09))
            .cornerRadius(16)

            VStack(alignment: .leading, spacing: 9) {

                Label("フリーランス法も確認", systemImage: "doc.text.magnifyingglass")
                    .font(.headline)

                Text("対象となるフリーランスへの業務委託では、発注事業者に取引条件を書面やメール等で明示する義務があります。業務内容、報酬額、支払期日などは、口約束だけにせず確認できる形で残しておくことが大切です。")
                    .font(.subheadline)

                Text("また、一定の場合には報酬支払期日、中途解除等の事前予告、ハラスメント対策などに関する義務も定められています。")
                    .font(.subheadline)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding()
            .background(Color.gray.opacity(0.09))
            .cornerRadius(16)

            VStack(alignment: .leading, spacing: 9) {

                Label("契約名だけでは決まらない", systemImage: "exclamationmark.triangle.fill")
                    .font(.headline)

                Text("契約書に「業務委託」「準委任」などと書かれていても、労働基準法上の労働者に当たるかは契約の名称だけで決まりません。実際の働き方を踏まえて総合的に判断されます。")
                    .font(.subheadline)

                Text("勤務時間・場所の拘束、仕事の指示、仕事を断れるかなど、実態に関する記録を残しておくことが役立つ場合があります。")
                    .font(.subheadline)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding()
            .background(Color.gray.opacity(0.09))
            .cornerRadius(16)

            Text("※一般的な契約知識を整理するための説明です。個別の契約の有効性、労働者性、解除の可否、損害賠償等を判断する法律相談ではありません。")
                .font(.caption)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)

            HStack {

                Button("相談先を見る") {
                    onOpenConsultation()
                }
                .buttonStyle(.bordered)

                Button("ホームに戻る") {
                    onHome()
                }
                .buttonStyle(.borderedProminent)
            }
        }
    }

    private func contractKnowledgeCard(
        icon: String,
        title: String,
        summary: String,
        points: [String]
    ) -> some View {

        VStack(alignment: .leading, spacing: 10) {

            Label(title, systemImage: icon)
                .font(.headline)

            Text(summary)
                .font(.subheadline)
                .bold()

            ForEach(points, id: \.self) { point in

                HStack(alignment: .top, spacing: 8) {

                    Image(systemName: "circle.fill")
                        .font(.system(size: 5))
                        .padding(.top, 6)

                    Text(point)
                        .font(.subheadline)
                }
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(Color.gray.opacity(0.09))
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(Color.primary.opacity(0.07), lineWidth: 1)
        )
        .cornerRadius(16)
    }

    private func knowledgeRow(_ text: String) -> some View {

        HStack(alignment: .top, spacing: 8) {

            Image(systemName: "checkmark.circle")

            Text(text)
                .font(.subheadline)
        }
    }
}
