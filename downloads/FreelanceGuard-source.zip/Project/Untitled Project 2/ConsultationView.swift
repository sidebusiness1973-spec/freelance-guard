import SwiftUI

struct ConsultationView: View {

    let onShowReport: () -> Void
    let onShowEvidenceChecklist: () -> Void
    let onShowImportantDates: () -> Void
    let onHome: () -> Void

    var body: some View {

VStack(spacing: 18) {

    VStack(spacing: 7) {

        Image(systemName: "person.2.badge.gearshape")

            .font(.system(size: 38, weight: .semibold))

        Text("相談先・次の行動")

            .font(.title2).bold()

        Text("困っている内容から、相談先の候補と準備する記録を整理します")

            .font(.subheadline)

            .foregroundStyle(.secondary)

            .multilineTextAlignment(.center)

    }

    VStack(alignment: .leading, spacing: 10) {

        Label("どこへ相談するか迷ったら", systemImage: "signpost.right.and.left.fill")

            .font(.headline)

            .foregroundStyle(.blue)

        Text("まず『何について困っているか』を基準に候補を選びます。契約名だけで決めず、実際の働き方・取引内容・相手とのやり取りを整理しておくと相談しやすくなります。")

            .font(.subheadline)

            .foregroundStyle(.secondary)

    }

    .frame(maxWidth: .infinity, alignment: .leading)

    .padding()

    .background(Color.blue.opacity(0.07))

    .cornerRadius(16)

    consultationCard(

        icon: "building.columns.fill",

        title: "労働基準監督署",

        subtitle: "実態として労働者に当たる可能性があり、賃金・労働時間・解雇など労働基準関係法令について相談したいとき",

        points: [

            "勤務時間・曜日・場所を誰が決めていたか",

            "具体的な業務指示、シフト、定例会議などの記録",

            "タイムカード、チャット、カレンダー、契約書などを準備"

        ],

        linkTitle: "厚生労働省の相談窓口を確認",

        urlString: "https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/koyou_roudou/roudoukijun/kijyungaiyou/kijyungaiyou06.html"

    )

    consultationCard(

        icon: "person.crop.circle.badge.questionmark",

        title: "総合労働相談コーナー",

        subtitle: "労働問題について相談したいものの、どの分野・窓口に当たるのか分からないとき",

        points: [

            "起きた出来事を日付順に整理",

            "契約変更・解除などの通知を保存",

            "何に困っていて、どうしたいのかを短くまとめる"

        ],

        linkTitle: "総合労働相談コーナーを確認",

        urlString: "https://www.mhlw.go.jp/general/seido/chihou/kaiketu/soudan.html"

    )

    consultationCard(

        icon: "person.2.wave.2.fill",

        title: "フリーランス・トラブル110番",

        subtitle: "フリーランスとして、契約上・仕事上のトラブルを弁護士に相談したいとき",

        points: [

            "契約書・発注内容・請求書・支払条件を確認",

            "LINE・Slack・メールなど相手とのやり取りを保存",

            "未払い、契約解除、取引上のトラブルなど経緯を整理"

        ],

        linkTitle: "公式の相談窓口を確認",

        urlString: "https://freelance110.mhlw.go.jp"

    )

    consultationCard(

        icon: "checkmark.seal.fill",

        title: "フリーランス法の相談・申出",

        subtitle: "取引条件の明示、報酬の支払い、発注事業者の対応などフリーランス法に関する確認や申出を検討するとき",

        points: [

            "発注者・受注者、契約期間、業務内容を確認",

            "報酬額・支払期日・発注内容が分かる資料を保存",

            "問題だと考える行為と、その日時・経緯を整理"

        ],

        linkTitle: "公正取引委員会の窓口を確認",

        urlString: "https://www.jftc.go.jp/soudan/soudan/freelance.html"

    )

    consultationCard(

        icon: "briefcase.fill",

        title: "弁護士",

        subtitle: "契約解除、未払い、損害、交渉、労働審判・訴訟など、個別事情を踏まえた法的判断や対応を相談したいとき",

        points: [

            "重要な出来事を日付順にまとめる",

            "契約書・通知・メッセージ・勤務記録など原本を保管",

            "相手に求めたい内容、金額、回答期限などを整理"

        ],

        linkTitle: nil,

        urlString: nil

    )

    VStack(alignment: .leading, spacing: 12) {

        Label("相談前の5ステップ", systemImage: "checklist")

            .font(.headline)

        consultationStep("1", "働き方チェック", "勤務時間・場所・具体的な指示などを整理")

        consultationStep("2", "勤務記録", "出退勤・休憩・業務内容を確認")

        consultationStep("3", "証拠・メモ", "LINE・Slack・メール・指示・通知などを時系列で保存")

        consultationStep("4", "期限・重要日", "回答期限・支払期限・契約終了日などを確認")

        consultationStep("5", "PDFレポート", "相談時に見せられる形へまとめる")

    }

    .frame(maxWidth: .infinity, alignment: .leading)

    .padding()

    .background(Color.gray.opacity(0.09))

    .cornerRadius(16)

    VStack(alignment: .leading, spacing: 10) {

        Label("相談資料をまとめる", systemImage: "doc.richtext.fill")

            .font(.headline)

            .foregroundStyle(.blue)

        Text("保存したチェック結果・勤務記録・証拠メモを確認し、相談時に説明しやすい形へ整理しておきましょう。")

            .font(.subheadline)

            .foregroundStyle(.secondary)

        Button {

            onShowReport()

        } label: {

            Label("PDF・レポートを確認", systemImage: "doc.text.magnifyingglass")

                .frame(maxWidth: .infinity)

        }

        .buttonStyle(.borderedProminent)

    }

    .frame(maxWidth: .infinity, alignment: .leading)

    .padding()

    .background(Color.blue.opacity(0.06))

    .cornerRadius(16)

    VStack(spacing: 10) {

        Button {

            onShowEvidenceChecklist()

        } label: {

            Label("証拠チェックリストを確認", systemImage: "checklist.checked")

                .frame(maxWidth: .infinity)

        }

        .buttonStyle(.bordered)

        Button {

            onShowImportantDates()

        } label: {

            Label("期限・重要日を確認", systemImage: "calendar.badge.clock")

                .frame(maxWidth: .infinity)

        }

        .buttonStyle(.bordered)

    }

    Text("※相談先は状況に応じた候補を整理するための一般的な案内です。アプリが労働者性、法令違反、請求の可否などを判定するものではありません。個別の適用関係、期限、手続は各機関や専門家に直接確認してください。")

        .font(.caption)

        .foregroundStyle(.secondary)

        .multilineTextAlignment(.center)

    Button("ホームに戻る") {

        onHome()

    }

    .buttonStyle(.bordered)

}

    
    }

private func consultationCard(

    icon: String,

    title: String,

    subtitle: String,

    points: [String],

    linkTitle: String? = nil,

    urlString: String? = nil

) -> some View {

    VStack(alignment: .leading, spacing: 10) {

        Label(title, systemImage: icon)

            .font(.headline)

        Text(subtitle)

            .font(.subheadline)

            .foregroundStyle(.secondary)

        ForEach(points, id: \.self) { point in

            HStack(alignment: .top, spacing: 7) {

                Image(systemName: "checkmark.circle")

                    .font(.caption)

                    .foregroundStyle(.blue)

                    .padding(.top, 3)

                Text(point)

                    .font(.subheadline)

            }

        }

        if let linkTitle, let urlString, let url = URL(string: urlString) {

            Link(destination: url) {

                HStack {

                    Image(systemName: "safari")

                    Text(linkTitle)

                    Spacer()

                    Image(systemName: "arrow.up.right")

                }

                .font(.subheadline.weight(.semibold))

                .padding(.top, 4)

            }

        }

    }

    .frame(maxWidth: .infinity, alignment: .leading)

    .padding()

    .background(Color.gray.opacity(0.09))

    .cornerRadius(16)

}

private func consultationStep(_ number: String, _ title: String, _ detail: String) -> some View {

    HStack(alignment: .top, spacing: 12) {

        Text(number)

            .font(.caption).bold()

            .frame(width: 25, height: 25)

            .background(Color.blue.opacity(0.12))

            .clipShape(Circle())

        VStack(alignment: .leading, spacing: 2) {

            Text(title)

                .font(.subheadline).bold()

            Text(detail)

                .font(.caption)

                .foregroundStyle(.secondary)

        }

    }

}
}
