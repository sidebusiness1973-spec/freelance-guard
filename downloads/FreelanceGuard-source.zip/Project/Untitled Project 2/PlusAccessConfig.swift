import Foundation

enum PlusAccessConfig {
    static let isPurchasingEnabled = false


    /// Debug builds can show the temporary Plus test switch.
    /// Release builds hide all test controls.
    static var showsDebugControls: Bool {
#if DEBUG
        return true
#else
        return false
#endif
    }

    /// The app always starts in Free mode.
    /// StoreKit purchase state will replace this during the billing phase.
    static let initialUnlocked = false
}
