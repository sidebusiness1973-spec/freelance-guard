import Foundation

final class MemoryStorage: WorkspaceStorage {
    var value: Data?
    init(_ value: Data? = nil) { self.value = value }
    func read() -> Data? { value }
    func write(_ data: Data) { value = data }
}

@main
struct WorkspaceTests {
    @MainActor static func main() throws {
        var count = 0
        func check(_ condition: @autoclosure () -> Bool, _ name: String) {
            precondition(condition(), name); count += 1; print("PASS: \(name)")
        }
        let uuid = "12345678-1234-1234-1234-123456789ABC"
        // Build 3 keys and Date's default JSON encoding are preserved verbatim.
        let oldWork = """
        [{"id":"\(uuid)","date":800000000,"startTime":800000000,"endTime":800028800,"instruction":"指示A","details":"作業A","breakMinutes":60,"memo":"旧メモ"}]
        """
        let oldEvidence = """
        [{"id":"\(uuid)","date":800000000,"type":"メール","title":"旧証拠","details":"本文"}]
        """
        let oldDeadline = """
        [{"id":"\(uuid)","date":800000000,"type":"支払期限","title":"旧期日","memo":"メモ"}]
        """
        let oldCheck = """
        [{"id":"\(uuid)","date":800000000,"yesCount":1,"answers":[true,false]}]
        """
        let decoder = JSONDecoder()
        var work = try decoder.decode([WorkRecord].self, from: Data(oldWork.utf8))
        let evidence = try decoder.decode([EvidenceRecord].self, from: Data(oldEvidence.utf8))
        let deadlines = try decoder.decode([ImportantDateRecord].self, from: Data(oldDeadline.utf8))
        let checks = try decoder.decode([CheckHistory].self, from: Data(oldCheck.utf8))
        check(work[0].projectID == nil && work[0].memo == "旧メモ", "Build 3 work decodes as unassigned without changing contents")
        check(evidence[0].projectID == nil && evidence[0].title == "旧証拠", "Build 3 evidence compatibility")
        check(deadlines[0].projectID == nil && deadlines[0].title == "旧期日", "Build 3 deadline compatibility")
        check(checks[0].yesCount == 1, "Build 3 check-history compatibility")
        let storage = MemoryStorage()
        let store = WorkspaceStore(storage: storage)
        check(store.projects.isEmpty && store.lawChecks.isEmpty, "empty workspace is valid")
        var project = ProjectContract(); project.name = "Web制作"; project.client = "取引先A"
        check(store.saveProject(project), "project create")
        project.paymentTerms = "月末締め翌月払い"
        check(store.saveProject(project) && store.projects.count == 1, "project edit keeps identity")
        let reopened = WorkspaceStore(storage: storage)
        check(reopened.projects.first?.paymentTerms == project.paymentTerms, "project data survives reload")
        var invalid = ProjectContract()
        check(!store.saveProject(invalid) && store.projects.count == 1, "empty project rejected without data loss")
        invalid.name = "期間逆転"; invalid.endDate = Date.distantPast
        check(!store.saveProject(invalid), "reversed contract period rejected")
        work[0].projectID = project.id
        let roundTrip = try decoder.decode([WorkRecord].self, from: JSONEncoder().encode(work))
        check(roundTrip[0].id == work[0].id && roundTrip[0].projectID == project.id, "record IDs and optional assignment survive encoding")
        let entries = WorkspaceActivity.entries(work: work, evidence: evidence, deadlines: deadlines, checks: checks, laws: [], projects: [project])
        check(entries.count == 5 && Set(entries.map(\.id)).count == 5, "timeline kinds do not collide when UUIDs match")
        check(WorkspaceActivity.filtered(entries, query: "指示A").count == 1, "search finds work instructions")
        check(WorkspaceActivity.filtered(entries, query: "本文").count == 1, "search finds evidence body")
        check(WorkspaceActivity.filtered(entries, query: "取引先A").count == 1, "search finds project clients")
        check(WorkspaceActivity.filtered(entries, scope: .project(project.id)).count == 2, "project filter excludes unassigned records")
        check(WorkspaceActivity.filtered(entries, scope: .unassigned).count == 3, "unassigned filter")
        let asc = WorkspaceActivity.filtered(entries, newestFirst: false)
        check(zip(asc, asc.dropFirst()).allSatisfy { $0.date <= $1.date }, "ascending timeline order")
        let desc = WorkspaceActivity.filtered(entries)
        check(zip(desc, desc.dropFirst()).allSatisfy { $0.date >= $1.date }, "descending timeline order")
        let at = work[0].date
        check(WorkspaceActivity.filtered(entries, interval: DateInterval(start: at, end: at.addingTimeInterval(1))).count == 4, "date filter includes matching start boundary")
        check(WorkspaceActivity.filtered(entries, interval: DateInterval(start: at.addingTimeInterval(-1), end: at)).isEmpty, "date filter excludes end boundary")
        var prep = ConsultationPreparation(); prep.checked[0] = true; prep.question = "報酬の経緯を確認したい"
        check(store.savePreparation(prep, projectID: project.id), "consultation checklist and notes save")
        let restoredPrep = WorkspaceStore(storage: storage).preparation(for: project.id)
        check(restoredPrep == prep && store.preparation(for: nil).question.isEmpty, "consultation reload and project isolation")
        check(store.saveLawCheck(answers: [false,false,false,false,false,false,false], summary: "確認済み0/7"), "zero-confirmed law check can be saved")
        check(WorkspaceStore(storage: storage).lawChecks.count == 1, "law check history reload")
        let report = ConsultationReportDocument.make(projectID: project.id, projects: store.projects, work: work, entries: entries, preparation: prep)
        check(report.plainText.contains("取引先A") && report.plainText.contains("指示A") && report.plainText.contains(prep.question), "report contains contract, instructions and consultation notes")
        check(!report.plainText.contains("旧証拠"), "project report excludes other/unassigned evidence")
        check(report.plainText.contains("確認済み：契約書を確認した") && report.plainText.contains("全体の履歴"), "report shows checklist status and global-check scope")
        let emptyReport = ConsultationReportDocument.make(projectID: nil, projects: [], work: [], entries: [], preparation: .init())
        check(emptyReport.plainText.contains("0件") && emptyReport.sections.count == 10, "empty report has every required section")
        check(store.deleteProject(project.id) && store.projects.isEmpty && store.preparation(for: project.id).question.isEmpty, "project delete and scoped preparation cleanup")
        let corruptBytes = Data("bad-json".utf8)
        let brokenStorage = MemoryStorage(corruptBytes)
        let broken = WorkspaceStore(storage: brokenStorage)
        check(broken.errorMessage != nil && !broken.saveProject(project) && brokenStorage.value == corruptBytes, "corrupt workspace is retained and cannot be overwritten")
        var future = WorkspaceData(); future.version = 99
        let futureStorage = MemoryStorage(try JSONEncoder().encode(future))
        check(!WorkspaceStore(storage: futureStorage).saveProject(project), "unknown future data format is protected")
        var calendar = Calendar(identifier: .gregorian); calendar.timeZone = TimeZone(secondsFromGMT: 0)!
        let base = calendar.startOfDay(for: Date())
        func duration(_ start: Int, _ end: Int, _ pause: Int) -> Int {
            WorkRecord(date: base, startTime: base.addingTimeInterval(Double(start * 60)), endTime: base.addingTimeInterval(Double(end * 60)), instruction: "", details: "", breakMinutes: pause, memo: "").workedMinutes(calendar: calendar)
        }
        check(duration(9*60,18*60,60) == 480, "working hours subtract breaks")
        check(duration(22*60,6*60,60) == 420, "overnight hours")
        check(duration(9*60,9*60,60) == 0 && duration(9*60,10*60,180) == 0, "zero hours and excessive breaks cannot become negative")
        var linkedWork = work
        var linkedEvidence = evidence
        var linkedDeadlines = deadlines
        linkedEvidence[0].projectID = project.id
        linkedDeadlines[0].projectID = project.id
        WorkspaceRecordLinks.detach(project.id, work: &linkedWork, evidence: &linkedEvidence, deadlines: &linkedDeadlines)
        check(linkedWork.count == 1 && linkedWork[0].projectID == nil && linkedWork[0].instruction == "指示A", "project deletion detaches work without deleting its content")
        check(linkedEvidence[0].projectID == nil && linkedEvidence[0].details == "本文", "project deletion preserves evidence")
        check(linkedDeadlines[0].projectID == nil && linkedDeadlines[0].title == "旧期日", "project deletion preserves deadlines")
        let unassignedReport = ConsultationReportDocument.make(projectID: nil, projects: [], work: linkedWork,
            entries: WorkspaceActivity.entries(work: linkedWork, evidence: linkedEvidence, deadlines: linkedDeadlines, checks: checks, laws: store.lawChecks), preparation: prep)
        check(unassignedReport.plainText.contains("旧証拠") && unassignedReport.plainText.contains("確認済み0/7"), "all-record report includes unassigned legacy data and law history")
        let afterDeletion = try decoder.decode([WorkRecord].self, from: JSONEncoder().encode(linkedWork))
        check(afterDeletion[0].id == UUID(uuidString: uuid) && afterDeletion[0].projectID == nil, "unassignment preserves legacy IDs on reload")
        let lawID = store.lawChecks[0].id
        check(store.deleteLawCheck(lawID) && WorkspaceStore(storage: storage).lawChecks.isEmpty, "law check deletion persists")
        print("ALL \(count) TESTS PASSED")
    }
}
