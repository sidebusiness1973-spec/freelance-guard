#!/bin/zsh
set -eu
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP_BUILD="$(mktemp -d "${TMPDIR:-/tmp}/freelanceguard-tests.XXXXXX")"
SRC="$ROOT/Untitled Project 2"
xcrun swiftc -swift-version 5 -default-isolation MainActor -parse-as-library -module-cache-path "$TMP_BUILD/ModuleCache" "$SRC/RecordModels.swift" "$SRC/WorkspaceModels.swift" "$SRC/WorkspaceStore.swift" "$SRC/ConsultationReport.swift" "$ROOT/Build4Tests/WorkspaceTests.swift" -o "$TMP_BUILD/WorkspaceTests"
"$TMP_BUILD/WorkspaceTests"
