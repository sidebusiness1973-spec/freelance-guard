import SwiftUI
import SwiftData
import Combine
import AppKit

// ======================================================
// MARK: - 契約情報
// ======================================================

struct ContractRecord: Identifiable, Codable, Equatable {
    var id: UUID
    var createdAt: Date
    var company: String
    var person: String
    var contractType: String
    var pay: String
    var workStyle: String
    var notes: String

    init(
        id: UUID = UUID(),
        createdAt: Date = Date(),
        company: String,
        person: String,
        contractType: String,
        pay: String,
        workStyle: String,
        notes: String
    ) {
        self.id = id
        self.createdAt = createdAt
        self.company = company
        self.person = person
        self.contractType = contractType
        self.pay = pay
        self.workStyle = workStyle
        self.notes = notes
    }
}

@MainActor
final class ContractStore: ObservableObject {

    static let shared = ContractStore()

    @Published var contracts: [ContractRecord] = []

    private let storageKey = "freelanceGuardContractsV2"

    private init() {
        load()
        migrateOldContractIfNeeded()
    }

    private var storageLoadFailed = false

    func add(_ contract: ContractRecord) throws {
        try commit([contract] + contracts)
    }

    func update(_ contract: ContractRecord) throws {
        guard let index = contracts.firstIndex(where: { $0.id == contract.id }) else { return }
        var updated = contracts
        updated[index] = contract
        try commit(updated)
    }

    func delete(_ contract: ContractRecord) throws {
        try commit(contracts.filter { $0.id != contract.id })
    }

    func replaceAll(_ newContracts: [ContractRecord]) throws {
        try commit(newContracts)
    }

    private func commit(_ records: [ContractRecord]) throws {
        guard !storageLoadFailed else {
            throw NSError(domain: "ContractStore", code: 1, userInfo: [NSLocalizedDescriptionKey: "保存済みの契約情報を読み込めませんでした。元のデータを保護するため保存を中止しました。バックアップを確認してください。"])
        }
        let data = try JSONEncoder().encode(records)
        UserDefaults.standard.set(data, forKey: storageKey)
        contracts = records
    }

    func validatedSnapshot() throws -> [ContractRecord] {
        guard !storageLoadFailed else {
            throw NSError(domain: "ContractStore", code: 2, userInfo: [NSLocalizedDescriptionKey: "契約情報を読み込めないためバックアップを中止しました。元の保存データは変更していません。"])
        }
        return contracts
    }

    // Used only after a backup has been fully validated and SwiftData committed.
    func replaceAllWithEncodedData(_ records: [ContractRecord], data: Data) {
        UserDefaults.standard.set(data, forKey: storageKey)
        contracts = records
        storageLoadFailed = false
    }

    private func save() throws {
        let data = try JSONEncoder().encode(contracts)

        UserDefaults.standard.set(
            data,
            forKey: storageKey
        )
    }

    private func load() {
        guard let data = UserDefaults.standard.data(forKey: storageKey) else { return }
        do {
            contracts = try JSONDecoder().decode([ContractRecord].self, from: data)
        } catch {
            storageLoadFailed = true
        }
    }

    private func migrateOldContractIfNeeded() {
        guard contracts.isEmpty, UserDefaults.standard.object(forKey: storageKey) == nil else {
            return
        }

        let defaults = UserDefaults.standard

        let oldCompany =
            defaults.string(
                forKey: "contractCompany"
            ) ?? ""

        guard !oldCompany
            .trimmingCharacters(
                in: .whitespacesAndNewlines
            )
            .isEmpty
        else {
            return
        }

        let oldContract = ContractRecord(
            company: oldCompany,
            person:
                defaults.string(
                    forKey: "contractPerson"
                ) ?? "",
            contractType:
                defaults.string(
                    forKey: "contractType"
                ) ?? "業務委託・準委任",
            pay:
                defaults.string(
                    forKey: "contractPay"
                ) ?? "",
            workStyle:
                defaults.string(
                    forKey: "contractWorkStyle"
                ) ?? "",
            notes:
                defaults.string(
                    forKey: "contractNotes"
                ) ?? ""
        )

        contracts = [oldContract]
        try? save()
    }
}

// ======================================================
// MARK: - SwiftDataモデル
// ======================================================

@Model
final class WorkRecord {
    var date: Date
    var startTime: Date
    var endTime: Date
    var workDetails: String
    var instructionDetails: String

    init(
        date: Date,
        startTime: Date,
        endTime: Date,
        workDetails: String,
        instructionDetails: String
    ) {
        self.date = date
        self.startTime = startTime
        self.endTime = endTime
        self.workDetails = workDetails
        self.instructionDetails = instructionDetails
    }
}

@Model
final class EvidenceMemo {
    var createdAt: Date
    var title: String
    var category: String
    var details: String

    init(
        createdAt: Date,
        title: String,
        category: String,
        details: String
    ) {
        self.createdAt = createdAt
        self.title = title
        self.category = category
        self.details = details
    }
}

@Model
final class DeadlineItem {
    var dueDate: Date
    var title: String
    var note: String

    init(
        dueDate: Date,
        title: String,
        note: String
    ) {
        self.dueDate = dueDate
        self.title = title
        self.note = note
    }
}

@Model
final class FreelanceLawResult {
    var createdAt: Date
    var warningCount: Int
    var answersRaw: String
    var resultMessage: String

    init(
        createdAt: Date = Date(),
        warningCount: Int,
        answersRaw: String,
        resultMessage: String
    ) {
        self.createdAt = createdAt
        self.warningCount = warningCount
        self.answersRaw = answersRaw
        self.resultMessage = resultMessage
    }
}

// ======================================================
// MARK: - メイン
// ======================================================

struct ContentView: View {

    @State private var selectedMenu: SidebarItem? = .home
    @StateObject private var contractStore = ContractStore.shared

    var body: some View {
        NavigationSplitView {

            List(
                SidebarItem.allCases,
                selection: $selectedMenu
            ) { item in

                Label(
                    item.title,
                    systemImage: item.icon
                )
                .tag(item)
            }
            .navigationTitle(
                "フリーランス守りナビ"
            )
            .navigationSplitViewColumnWidth(
                min: 190,
                ideal: 240
            )

        } detail: {

            if let selectedMenu {
                detailView(for: selectedMenu)
            } else {
                Text("メニューを選択してください")
            }
        }
        .environmentObject(contractStore)
        .frame(
            minWidth: 1100,
            minHeight: 740
        )
    }

    @ViewBuilder
    private func detailView(
        for item: SidebarItem
    ) -> some View {

        switch item {

        case .home:
            HomeView(onOpen: { selectedMenu = $0 })

        case .workCheck:
            WorkStyleCheckView()

        case .freelanceLaw:
            FreelanceLawCheckView()

        case .contract:
            ContractView()

        case .workLog:
            WorkLogView()

        case .evidence:
            EvidenceView()

        case .deadlines:
            DeadlineView()

        case .consultation:
            MacConsultationView()

        case .documents:
            MacDocumentDraftView()

        case .organizer:
            MacMessageOrganizerView()

        case .checklist:
            MacEvidenceChecklistView()

        case .guides:
            MacKnowledgeView()

        case .search:
            SearchView()

        case .reports:
            ReportView()

        case .settings:
            SettingsView()
        }
    }
}

// ======================================================
// MARK: - ホーム
// ======================================================

struct HomeView: View {
    let onOpen: (SidebarItem) -> Void

    @AppStorage("showRecordReminder") private var showRecordReminder = true
    @AppStorage("displayLegalNotice") private var displayLegalNotice = true

    @EnvironmentObject
    private var contractStore: ContractStore

    @Query
    private var workRecords: [WorkRecord]

    @Query
    private var evidenceMemos: [EvidenceMemo]

    @Query
    private var deadlines: [DeadlineItem]

    @Query
    private var lawResults: [FreelanceLawResult]

    var body: some View {

        ScrollView {

            VStack(spacing: 30) {

                VStack(alignment: .leading, spacing: 18) {
                    HStack {
                        Label("フリーランス守りナビ", systemImage: "checkmark.shield.fill")
                            .font(.headline)
                        Spacer()
                        Text("Mac").font(.caption.bold()).padding(8)
                            .background(.white.opacity(0.12), in: Capsule())
                    }
                    Text("仕事の記録を、\n相談に役立つ形へ。")
                        .font(.system(size: 36, weight: .bold, design: .rounded))
                    Text("契約・勤務・指示・証拠・期限を、ひとつの場所に。")
                        .font(.title3).foregroundStyle(.white.opacity(0.8))
                    HStack(spacing: 12) {
                        Button { onOpen(.workLog) } label: {
                            Label("勤務記録を開く", systemImage: "plus.circle.fill")
                                .font(.headline).padding(14)
                                .foregroundStyle(Color(red: 0.05, green: 0.17, blue: 0.23))
                                .background(Color(red: 0.46, green: 0.91, blue: 0.79), in: RoundedRectangle(cornerRadius: 14))
                        }.buttonStyle(.plain)
                        Button { onOpen(.evidence) } label: {
                            Label("証拠・メモを開く", systemImage: "doc.text")
                                .font(.headline).padding(14)
                                .background(.white.opacity(0.12), in: RoundedRectangle(cornerRadius: 14))
                        }.buttonStyle(.plain)
                    }
                }
                .foregroundStyle(.white)
                .padding(28)
                .frame(maxWidth: 820, alignment: .leading)
                .background(LinearGradient(colors: [Color(red: 0.06, green: 0.16, blue: 0.24), Color(red: 0.09, green: 0.30, blue: 0.34)], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 28))

                if showRecordReminder {
                    Label("勤務後に勤務記録と指示のやり取りを残しましょう。", systemImage: "lightbulb")
                        .foregroundStyle(.secondary)
                }
                if displayLegalNotice {
                    Text("このアプリは記録と情報整理のためのもので、個別の法的判断は行いません。")
                        .font(.caption).foregroundStyle(.secondary)
                }

                HStack(spacing: 18) {

                    DashboardCard(
                        icon: "doc.badge.gearshape",
                        title: "契約情報",
                        value:
                            "\(contractStore.contracts.count)件"
                    )

                    DashboardCard(
                        icon: "clock",
                        title: "勤務記録",
                        value:
                            "\(workRecords.count)件"
                    )
                }
                .frame(maxWidth: 820)

                HStack(spacing: 18) {

                    DashboardCard(
                        icon: "doc.text",
                        title: "証拠・メモ",
                        value:
                            "\(evidenceMemos.count)件"
                    )

                    DashboardCard(
                        icon: "calendar",
                        title: "重要日",
                        value:
                            "\(deadlines.count)件"
                    )
                }
                .frame(maxWidth: 820)

                DashboardCard(
                    icon: "checkmark.seal",
                    title:
                        "フリーランス法チェック履歴",
                    value:
                        "\(lawResults.count)件"
                )
                .frame(maxWidth: 400)

                if let latest =
                    contractStore.contracts.first {

                    GroupBox(
                        "最新の契約先"
                    ) {

                        HStack {

                            Image(
                                systemName:
                                    "building.2"
                            )

                            VStack(
                                alignment: .leading,
                                spacing: 4
                            ) {

                                Text(latest.company)
                                    .font(.headline)

                                Text(
                                    latest.contractType
                                )
                                .foregroundStyle(
                                    .secondary
                                )
                            }

                            Spacer()
                        }
                        .padding(8)
                    }
                    .frame(maxWidth: 820)
                }

                if let latestCheck =
                    lawResults.max(
                        by: {
                            lhs,
                            rhs in

                            lhs.createdAt <
                            rhs.createdAt
                        }
                    ) {

                    GroupBox(
                        "最新のフリーランス法チェック"
                    ) {

                        VStack(
                            alignment: .leading,
                            spacing: 8
                        ) {

                            Text(
                                latestCheck
                                    .createdAt
                                    .formatted(
                                        date: .long,
                                        time: .shortened
                                    )
                            )
                            .font(.headline)

                            Text(
                                "確認が必要な項目：\(latestCheck.warningCount)件"
                            )

                            Text(
                                latestCheck
                                    .resultMessage
                            )
                            .foregroundStyle(
                                .secondary
                            )
                        }
                        .frame(
                            maxWidth: .infinity,
                            alignment: .leading
                        )
                        .padding(8)
                    }
                    .frame(maxWidth: 820)
                }

                GroupBox {

                    VStack(
                        alignment: .leading,
                        spacing: 10
                    ) {

                        Label(
                            "記録を残す習慣が、自分を守る材料になります。",
                            systemImage:
                                "lightbulb"
                        )
                        .font(.headline)

                        Text(
                            "勤務時間、具体的な指示、シフト、出社要請、契約上の重要日などを日常的に記録できます。"
                        )
                        .foregroundStyle(
                            .secondary
                        )
                    }
                    .frame(
                        maxWidth: .infinity,
                        alignment: .leading
                    )
                    .padding(8)
                }
                .frame(maxWidth: 820)
            }
            .padding(28)
            .frame(maxWidth: .infinity)
        }
    }
}

struct DashboardCard: View {

    let icon: String
    let title: String
    let value: String

    var body: some View {

        VStack(spacing: 12) {

            Image(systemName: icon)
                .font(.system(size: 24, weight: .semibold))
                .foregroundStyle(.teal)
                .frame(width: 52, height: 52)
                .background(.teal.opacity(0.1), in: RoundedRectangle(cornerRadius: 16))

            Text(value)
                .font(.system(size: 34, weight: .bold, design: .rounded))
                .fontWeight(.bold)

            Text(title)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(24)
        .background(
            .quaternary.opacity(0.35)
        )
        .clipShape(
            RoundedRectangle(
                cornerRadius: 16
            )
        )
    }
}

// ======================================================
// MARK: - 働き方チェック
// ======================================================

struct WorkStyleCheckView: View {

    @AppStorage("freelanceGuardWorkStyleHistoryV1")
    private var historyData: Data = Data()

    @State private var currentQuestion = 0
    @State private var selectedHistory: MacWorkStyleHistory?

    @State private var answers: [Bool?] =
        Array(
            repeating: nil,
            count: 15
        )

    private let questions = [
        "勤務時間を会社から指定されていますか？",
        "勤務する曜日を会社から指定されていますか？",
        "勤務場所を会社から指定されていますか？",
        "仕事の具体的な進め方について指示を受けていますか？",
        "会社からシフトを組まれていますか？",
        "休みを取る際に会社の許可が必要ですか？",
        "仕事中の行動や進捗を会社から管理されていますか？",
        "定例ミーティングへの参加を求められていますか？",
        "会社から仕事の量や件数を指定されていますか？",
        "業務で使用するツールを会社から指定されていますか？",
        "仕事を断ることが難しい状況ですか？",
        "自分の代わりに別の人へ仕事を任せることが難しいですか？",
        "報酬が成果ではなく、働いた時間を基準に決まっていますか？",
        "会社の社員と似た働き方をしていますか？",
        "契約終了について会社側が一方的に決められる状況ですか？"
    ]

    var body: some View {

        VStack(spacing: 28) {

            Image(
                systemName: "checklist"
            )
            .font(.system(size: 52))

            Text(
                "働き方チェック"
            )
            .font(.largeTitle)
            .fontWeight(.bold)

            Text(
                "現在の働き方について、15の質問に答えてください。"
            )
            .font(.title3)
            .foregroundStyle(.secondary)

            Divider()

            if currentQuestion <
                questions.count {

                VStack(spacing: 24) {

                    Text(
                        "質問 \(currentQuestion + 1) / \(questions.count)"
                    )
                    .font(.headline)
                    .foregroundStyle(.secondary)

                    Text(
                        questions[
                            currentQuestion
                        ]
                    )
                    .font(.title2)
                    .fontWeight(.semibold)
                    .multilineTextAlignment(
                        .center
                    )

                    HStack(spacing: 20) {

                        Button {
                            answer(true)

                        } label: {

                            Label(
                                "はい",
                                systemImage:
                                    "checkmark.circle"
                            )
                            .frame(width: 130)
                        }
                        .controlSize(.large)

                        Button {
                            answer(false)

                        } label: {

                            Label(
                                "いいえ",
                                systemImage:
                                    "xmark.circle"
                            )
                            .frame(width: 130)
                        }
                        .controlSize(.large)
                    }

                    if currentQuestion > 0 {

                        Button(
                            "前の質問に戻る"
                        ) {
                            currentQuestion -= 1
                        }
                    }
                }

            } else {

                resultView
            }

            Spacer()
        }
        .padding(50)
        .frame(
            maxWidth: .infinity,
            maxHeight: .infinity
        )
        .sheet(item: $selectedHistory) { record in
            ScrollView {
                VStack(alignment: .leading, spacing: 14) {
                    Text("チェック履歴").font(.title.bold())
                    Text(record.date.formatted(date: .long, time: .shortened))
                    Text("\(record.yesCount) / \(record.answers.count)項目が該当")
                        .font(.headline)
                    ForEach(questions.indices, id: \.self) { index in
                        if record.answers.indices.contains(index) {
                            Text("\(index + 1). \(questions[index])：\(record.answers[index] ? "はい" : "いいえ")")
                        }
                    }
                    Button("閉じる") { selectedHistory = nil }
                }
                .padding(30)
                .frame(minWidth: 600, alignment: .leading)
            }
            .frame(minHeight: 450)
        }
    }

    private var resultView: some View {

        let yesCount =
            answers
                .compactMap { $0 }
                .filter { $0 }
                .count

        return VStack(spacing: 20) {

            Image(
                systemName:
                    "checkmark.shield"
            )
            .font(.system(size: 64))

            Text("チェック完了")
                .font(.largeTitle)
                .fontWeight(.bold)

            Text(
                "\(questions.count)項目中 \(yesCount)項目が該当"
            )
            .font(.title2)

            Text(
                resultMessage(
                    for: yesCount
                )
            )
            .font(.title3)
            .multilineTextAlignment(.center)
            .foregroundStyle(.secondary)
            .frame(maxWidth: 650)

            Button(
                "もう一度チェックする"
            ) {

                currentQuestion = 0

                answers =
                    Array(
                        repeating: nil,
                        count: questions.count
                    )
            }
            .controlSize(.large)

            if !history.isEmpty {
                DisclosureGroup("保存済みのチェック履歴（\(history.count)件）") {
                    ScrollView {
                        ForEach(history) { record in
                            Button("\(record.date.formatted(date: .abbreviated, time: .shortened))：該当 \(record.yesCount) / \(record.answers.count)") {
                                selectedHistory = record
                            }
                            .buttonStyle(.plain)
                            .frame(maxWidth: .infinity, alignment: .leading)
                        }
                    }
                    .frame(maxHeight: 180)
                }
                .frame(maxWidth: 600)
            }
        }
    }

    private var history: [MacWorkStyleHistory] {
        (try? JSONDecoder().decode([MacWorkStyleHistory].self, from: historyData)) ?? []
    }

    private func answer(_ value: Bool) {
        guard currentQuestion < questions.count else { return }
        answers[currentQuestion] = value
        currentQuestion += 1
        if currentQuestion == questions.count {
            let result = MacWorkStyleHistory(
                date: Date(),
                yesCount: answers.compactMap { $0 }.filter { $0 }.count,
                answers: answers.map { $0 ?? false }
            )
            do {
                let previous = historyData.isEmpty ? [] : try JSONDecoder().decode([MacWorkStyleHistory].self, from: historyData)
                historyData = try JSONEncoder().encode([result] + previous)
            } catch {
                RecordPersistence.showError(error)
            }
        }
    }

    private func resultMessage(
        for yesCount: Int
    ) -> String {

        switch yesCount {

        case 0...4:

            return """
            現時点では比較的自由度の高い働き方に見えます。
            契約内容と実際の働き方を定期的に確認しておきましょう。
            """

        case 5...9:

            return """
            契約内容と実際の働き方にズレがないか確認する価値があります。
            具体的な指示や勤務条件は記録しておきましょう。
            """

        default:

            return """
            勤務時間・場所・指示・シフトなどの拘束が多い可能性があります。
            日々の実態を記録し、契約内容と整理しておくことが大切です。
            """
        }
    }
}

// ======================================================
// MARK: - フリーランス法チェック
// ======================================================

struct FreelanceLawCheckView: View {

    @Environment(\.modelContext)
    private var modelContext

    @Query(
        sort:
            \FreelanceLawResult.createdAt,
        order: .reverse
    )
    private var savedResults:
        [FreelanceLawResult]

    @State private var currentQuestion = 0

    @State private var answers: [Bool?] =
        Array(
            repeating: nil,
            count: 7
        )

    @State private var saveMessage = ""

    private let questions = [
        "取引条件（業務内容・報酬額・支払期日など）が明示されていますか？",
        "報酬の支払期日が明確になっていますか？",
        "一方的な報酬減額や受領拒否をされたことはありませんか？",
        "不当にやり直しを求められていませんか？",
        "募集時に示された条件と実際の条件は一致していますか？",
        "継続的な契約の場合、解除や不更新について十分な説明がありますか？",
        "ハラスメントや不利益な取扱いについて相談できる環境がありますか？"
    ]

    var body: some View {

        ScrollView {

            VStack(
                alignment: .center,
                spacing: 26
            ) {

                Image(
                    systemName:
                        "checkmark.seal"
                )
                .font(.system(size: 52))

                Text(
                    "フリーランス法チェック"
                )
                .font(.largeTitle)
                .fontWeight(.bold)

                Text(
                    "取引条件や契約運用について確認します。"
                )
                .font(.title3)
                .foregroundStyle(.secondary)

                Text(
                    "※簡易チェックです。個別案件の法的結論を判定するものではありません。"
                )
                .font(.caption)
                .foregroundStyle(.secondary)

                Divider()

                if currentQuestion <
                    questions.count {

                    questionView

                } else {

                    resultView
                }

                Divider()

                historyView
            }
            .padding(50)
            .frame(maxWidth: .infinity)
        }
    }

    private var questionView: some View {

        VStack(spacing: 22) {

            Text(
                "質問 \(currentQuestion + 1) / \(questions.count)"
            )
            .font(.headline)
            .foregroundStyle(.secondary)

            Text(
                questions[
                    currentQuestion
                ]
            )
            .font(.title2)
            .fontWeight(.semibold)
            .multilineTextAlignment(.center)
            .frame(maxWidth: 700)

            HStack(spacing: 20) {

                Button {

                    answers[
                        currentQuestion
                    ] = true

                    currentQuestion += 1

                } label: {

                    Label(
                        "はい",
                        systemImage:
                            "checkmark.circle"
                    )
                    .frame(width: 130)
                }
                .controlSize(.large)

                Button {

                    answers[
                        currentQuestion
                    ] = false

                    currentQuestion += 1

                } label: {

                    Label(
                        "いいえ",
                        systemImage:
                            "xmark.circle"
                    )
                    .frame(width: 130)
                }
                .controlSize(.large)
            }

            if currentQuestion > 0 {

                Button(
                    "前の質問に戻る"
                ) {
                    currentQuestion -= 1
                }
            }
        }
    }

    private var resultView: some View {

        let warningCount =
            answers
                .compactMap { $0 }
                .filter { !$0 }
                .count

        let message =
            resultMessage(
                for: warningCount
            )

        return VStack(spacing: 20) {

            Image(
                systemName:
                    "doc.text.magnifyingglass"
            )
            .font(.system(size: 60))

            Text("チェック完了")
                .font(.largeTitle)
                .fontWeight(.bold)

            Text(
                "確認が必要な項目：\(warningCount)件"
            )
            .font(.title2)

            Text(message)
                .font(.title3)
                .multilineTextAlignment(
                    .center
                )
                .foregroundStyle(.secondary)
                .frame(maxWidth: 700)

            if !saveMessage.isEmpty {

                Label(
                    saveMessage,
                    systemImage:
                        "checkmark.circle.fill"
                )
                .foregroundStyle(.green)
                .fontWeight(.semibold)
            }

            HStack(spacing: 14) {

                Button {

                    saveResult(
                        warningCount:
                            warningCount,
                        message:
                            message
                    )

                } label: {

                    Label(
                        "結果を保存",
                        systemImage:
                            "square.and.arrow.down"
                    )
                }
                .buttonStyle(
                    .borderedProminent
                )
                .controlSize(.large)

                Button(
                    "もう一度チェックする"
                ) {

                    currentQuestion = 0

                    answers =
                        Array(
                            repeating: nil,
                            count: 7
                        )

                    saveMessage = ""
                }
                .controlSize(.large)
            }
        }
    }

    private var historyView: some View {

        VStack(
            alignment: .leading,
            spacing: 18
        ) {

            HStack {

                Text(
                    "保存済みチェック履歴"
                )
                .font(.title2)
                .fontWeight(.bold)

                Spacer()

                Text(
                    "\(savedResults.count)件"
                )
                .foregroundStyle(
                    .secondary
                )
            }

            if savedResults.isEmpty {

                ContentUnavailableView(
                    "保存済み結果はありません",
                    systemImage:
                        "checkmark.seal",
                    description:
                        Text(
                            "チェック結果を保存すると、ここに履歴が表示されます。"
                        )
                )

            } else {

                ForEach(
                    savedResults
                ) { result in

                    VStack(
                        alignment: .leading,
                        spacing: 10
                    ) {

                        HStack {

                            Text(
                                result
                                    .createdAt
                                    .formatted(
                                        date: .long,
                                        time: .shortened
                                    )
                            )
                            .font(.headline)

                            Spacer()

                            Button(
                                role:
                                    .destructive
                            ) {

                                modelContext
                                    .delete(
                                        result
                                    )

                                _ = RecordPersistence.save(modelContext)

                            } label: {

                                Image(
                                    systemName:
                                        "trash"
                                )
                            }
                            .buttonStyle(
                                .borderless
                            )
                        }

                        Text(
                            "確認が必要な項目：\(result.warningCount)件"
                        )
                        .font(.title3)
                        .fontWeight(.semibold)

                        Text(
                            result.resultMessage
                        )
                        .foregroundStyle(
                            .secondary
                        )
                    }
                    .padding()
                    .background(
                        .quaternary
                            .opacity(0.35)
                    )
                    .clipShape(
                        RoundedRectangle(
                            cornerRadius: 14
                        )
                    )
                }
            }
        }
        .frame(
            maxWidth: 850,
            alignment: .leading
        )
        .padding(.top, 10)
    }

    private func saveResult(
        warningCount: Int,
        message: String
    ) {

        let raw =
            answers
                .map {

                    if $0 == true {
                        return "1"
                    }

                    if $0 == false {
                        return "0"
                    }

                    return "-"
                }
                .joined(
                    separator: ","
                )

        let result =
            FreelanceLawResult(
                warningCount:
                    warningCount,
                answersRaw:
                    raw,
                resultMessage:
                    message
            )

        modelContext.insert(result)

        do {

            try modelContext.save()

            saveMessage =
                "チェック結果を保存しました"

        } catch {

            modelContext.rollback()
            saveMessage =
                "保存できませんでした"
        }
    }

    private func resultMessage(
        for count: Int
    ) -> String {

        switch count {

        case 0:

            return """
            今回の回答では大きな確認項目は見当たりませんでした。
            契約書や取引条件、メール、チャットなどの記録は引き続き保存しておきましょう。
            """

        case 1...2:

            return """
            一部の取引条件について確認する価値があります。
            契約書、報酬条件、メール、チャットなどを整理しておきましょう。
            """

        default:

            return """
            複数の項目で確認が必要です。
            契約内容と実際の取引状況を整理し、必要に応じて行政窓口や専門家への相談を検討してください。
            """
        }
    }
}

// ======================================================
// MARK: - 契約情報
// ======================================================

struct ContractView: View {

    @EnvironmentObject
    private var contractStore:
        ContractStore

    @State private var company = ""
    @State private var person = ""

    @State private var contractType =
        "業務委託・準委任"

    @State private var pay = ""
    @State private var workStyle = ""
    @State private var notes = ""

    @State private var searchText = ""

    @State private var editingContract:
        ContractRecord?

    @State private var statusMessage = ""
    @State private var saveSucceeded = false

    private let contractTypes = [
        "業務委託・準委任",
        "業務委託・請負",
        "雇用契約",
        "その他"
    ]

    private var filteredContracts:
        [ContractRecord] {

        if searchText.isEmpty {
            return contractStore.contracts
        }

        return contractStore.contracts.filter {

            $0.company
                .localizedCaseInsensitiveContains(
                    searchText
                )
            ||
            $0.person
                .localizedCaseInsensitiveContains(
                    searchText
                )
            ||
            $0.contractType
                .localizedCaseInsensitiveContains(
                    searchText
                )
            ||
            $0.pay
                .localizedCaseInsensitiveContains(
                    searchText
                )
            ||
            $0.workStyle
                .localizedCaseInsensitiveContains(
                    searchText
                )
            ||
            $0.notes
                .localizedCaseInsensitiveContains(
                    searchText
                )
        }
    }

    var body: some View {

        ScrollView {

            VStack(
                alignment: .leading,
                spacing: 24
            ) {

                Text("契約情報")
                    .font(.largeTitle)
                    .fontWeight(.bold)

                Text(
                    "契約先ごとに契約内容を保存・管理できます。"
                )
                .font(.title3)
                .foregroundStyle(.secondary)

                Divider()

                GroupBox(
                    "新しい契約を登録"
                ) {

                    VStack(
                        alignment: .leading,
                        spacing: 16
                    ) {

                        TextField(
                            "会社・事業者名",
                            text: $company
                        )

                        TextField(
                            "担当者名",
                            text: $person
                        )

                        Picker(
                            "契約形態",
                            selection:
                                $contractType
                        ) {

                            ForEach(
                                contractTypes,
                                id: \.self
                            ) {

                                Text($0)
                            }
                        }

                        TextField(
                            "報酬 例：時給2,400円 / 月60万円",
                            text: $pay
                        )

                        TextField(
                            "働き方 例：週5日・在宅・8:30〜17:30",
                            text:
                                $workStyle
                        )

                        Text("契約メモ")
                            .fontWeight(.semibold)

                        TextEditor(
                            text: $notes
                        )
                        .frame(
                            minHeight: 140
                        )

                        HStack {

                            if !statusMessage.isEmpty {

                                Label(
                                    statusMessage,
                                    systemImage:
                                        saveSucceeded
                                        ? "checkmark.circle.fill"
                                        : "exclamationmark.triangle.fill"
                                )
                                .foregroundStyle(
                                    saveSucceeded
                                    ? Color.green
                                    : Color.red
                                )
                            }

                            Spacer()

                            Button {

                                saveContract()

                            } label: {

                                Label(
                                    "契約情報を保存",
                                    systemImage:
                                        "square.and.arrow.down"
                                )
                            }
                            .controlSize(.large)
                            .buttonStyle(
                                .borderedProminent
                            )
                            .disabled(
                                company
                                    .trimmingCharacters(
                                        in:
                                            .whitespacesAndNewlines
                                    )
                                    .isEmpty
                            )
                        }
                    }
                    .padding()
                }

                Divider()

                HStack {

                    Text("保存済み契約")
                        .font(.title2)
                        .fontWeight(.bold)

                    Spacer()

                    TextField(
                        "契約情報を検索",
                        text:
                            $searchText
                    )
                    .textFieldStyle(
                        .roundedBorder
                    )
                    .frame(width: 280)
                }

                if filteredContracts.isEmpty {

                    ContentUnavailableView(
                        "契約情報はありません",
                        systemImage:
                            "doc.badge.gearshape",
                        description:
                            Text(
                                "保存した契約情報がここに表示されます。"
                            )
                    )

                } else {

                    ForEach(
                        filteredContracts
                    ) { contract in

                        ContractCard(
                            contract:
                                contract,
                            onEdit: {

                                editingContract =
                                    contract
                            },
                            onDelete: {

                                deleteContract(
                                    contract
                                )
                            }
                        )
                    }
                }
            }
            .padding(40)
        }
        .sheet(
            item:
                $editingContract
        ) { contract in

            ContractEditView(
                contract:
                    contract
            )
            .environmentObject(
                contractStore
            )
        }
    }

    private func saveContract() {

        let newContract =
            ContractRecord(
                company:
                    company
                        .trimmingCharacters(
                            in:
                                .whitespacesAndNewlines
                        ),
                person:
                    person,
                contractType:
                    contractType,
                pay:
                    pay,
                workStyle:
                    workStyle,
                notes:
                    notes
            )

        do {

            try contractStore.add(
                newContract
            )

            saveSucceeded = true

            statusMessage =
                "契約情報を保存しました"

            company = ""
            person = ""

            contractType =
                "業務委託・準委任"

            pay = ""
            workStyle = ""
            notes = ""

        } catch {

            saveSucceeded = false

            statusMessage =
                "保存できませんでした"
        }
    }

    private func deleteContract(
        _ contract:
            ContractRecord
    ) {

        do {

            try contractStore.delete(
                contract
            )

        } catch {

            saveSucceeded = false

            statusMessage =
                "削除できませんでした"
        }
    }
}

struct ContractCard: View {

    let contract: ContractRecord
    let onEdit: () -> Void
    let onDelete: () -> Void

    var body: some View {

        VStack(
            alignment: .leading,
            spacing: 10
        ) {

            HStack {

                Image(
                    systemName:
                        "building.2"
                )
                .font(.title2)

                Text(contract.company)
                    .font(.title3)
                    .fontWeight(.bold)

                Spacer()

                Button {

                    onEdit()

                } label: {

                    Image(
                        systemName:
                            "pencil"
                    )
                }
                .buttonStyle(.borderless)

                Button(
                    role:
                        .destructive
                ) {

                    onDelete()

                } label: {

                    Image(
                        systemName:
                            "trash"
                    )
                }
                .buttonStyle(.borderless)
            }

            Divider()

            ContractInfoRow(
                title: "担当者",
                value:
                    contract.person
            )

            ContractInfoRow(
                title: "契約形態",
                value:
                    contract.contractType
            )

            ContractInfoRow(
                title: "報酬",
                value:
                    contract.pay
            )

            ContractInfoRow(
                title: "働き方",
                value:
                    contract.workStyle
            )

            if !contract.notes
                .trimmingCharacters(
                    in:
                        .whitespacesAndNewlines
                )
                .isEmpty {

                Divider()

                Text("契約メモ")
                    .fontWeight(.semibold)

                Text(contract.notes)
                    .foregroundStyle(
                        .secondary
                    )
            }

            Text(
                "登録日：\(contract.createdAt.formatted(date: .long, time: .shortened))"
            )
            .font(.caption)
            .foregroundStyle(.secondary)
        }
        .padding()
        .background(
            .quaternary.opacity(0.35)
        )
        .clipShape(
            RoundedRectangle(
                cornerRadius: 14
            )
        )
    }
}

struct ContractInfoRow: View {

    let title: String
    let value: String

    var body: some View {

        if !value
            .trimmingCharacters(
                in:
                    .whitespacesAndNewlines
            )
            .isEmpty {

            HStack(
                alignment: .top
            ) {

                Text(title)
                    .fontWeight(.semibold)
                    .frame(
                        width: 90,
                        alignment:
                            .leading
                    )

                Text(value)

                Spacer()
            }
        }
    }
}

struct ContractEditView: View {

    @Environment(\.dismiss)
    private var dismiss

    @EnvironmentObject
    private var contractStore:
        ContractStore

    let contract:
        ContractRecord

    @State private var company:
        String

    @State private var person:
        String

    @State private var contractType:
        String

    @State private var pay:
        String

    @State private var workStyle:
        String

    @State private var notes:
        String

    private let contractTypes = [
        "業務委託・準委任",
        "業務委託・請負",
        "雇用契約",
        "その他"
    ]

    init(
        contract:
            ContractRecord
    ) {

        self.contract =
            contract

        _company =
            State(
                initialValue:
                    contract.company
            )

        _person =
            State(
                initialValue:
                    contract.person
            )

        _contractType =
            State(
                initialValue:
                    contract.contractType
            )

        _pay =
            State(
                initialValue:
                    contract.pay
            )

        _workStyle =
            State(
                initialValue:
                    contract.workStyle
            )

        _notes =
            State(
                initialValue:
                    contract.notes
            )
    }

    var body: some View {

        VStack(
            alignment: .leading,
            spacing: 18
        ) {

            Text("契約情報を編集")
                .font(.title)
                .fontWeight(.bold)

            TextField(
                "会社・事業者名",
                text: $company
            )

            TextField(
                "担当者名",
                text: $person
            )

            Picker(
                "契約形態",
                selection:
                    $contractType
            ) {

                ForEach(
                    contractTypes,
                    id: \.self
                ) {

                    Text($0)
                }
            }

            TextField(
                "報酬",
                text: $pay
            )

            TextField(
                "働き方",
                text: $workStyle
            )

            Text("契約メモ")
                .fontWeight(.semibold)

            TextEditor(
                text: $notes
            )
            .frame(height: 130)

            HStack {

                Button(
                    "キャンセル"
                ) {
                    dismiss()
                }

                Spacer()

                Button(
                    "変更を保存"
                ) {

                    var updated =
                        contract

                    updated.company =
                        company

                    updated.person =
                        person

                    updated.contractType =
                        contractType

                    updated.pay =
                        pay

                    updated.workStyle =
                        workStyle

                    updated.notes =
                        notes

                    do {
                        try contractStore.update(updated)
                        dismiss()
                    } catch {
                        RecordPersistence.showError(error)
                    }
                }
                .keyboardShortcut(
                    .defaultAction
                )
            }
        }
        .padding(30)
        .frame(
            width: 620,
            height: 560
        )
    }
}

// ======================================================
// MARK: - 勤務記録
// ======================================================

struct WorkLogView: View {

    @Environment(\.modelContext)
    private var modelContext

    @Query(
        sort:
            \WorkRecord.date,
        order: .reverse
    )
    private var records:
        [WorkRecord]

    @State private var workDate =
        Date()

    @State private var startTime =
        Date()

    @State private var endTime =
        Date()

    @State private var workDetails = ""

    @State private var instructionDetails =
        ""

    @State private var searchText = ""

    @State private var editingRecord:
        WorkRecord?

    private var filteredRecords:
        [WorkRecord] {

        if searchText.isEmpty {
            return records
        }

        return records.filter {

            $0.workDetails
                .localizedCaseInsensitiveContains(
                    searchText
                )
            ||
            $0.instructionDetails
                .localizedCaseInsensitiveContains(
                    searchText
                )
        }
    }

    var body: some View {

        ScrollView {

            VStack(
                alignment: .leading,
                spacing: 24
            ) {

                Text("勤務記録")
                    .font(.largeTitle)
                    .fontWeight(.bold)

                Text(
                    "勤務日時・業務内容・受けた指示を記録します。"
                )
                .font(.title3)
                .foregroundStyle(.secondary)

                Divider()

                GroupBox(
                    "勤務情報"
                ) {

                    VStack(
                        alignment: .leading,
                        spacing: 16
                    ) {

                        DatePicker(
                            "勤務日",
                            selection:
                                $workDate,
                            displayedComponents:
                                .date
                        )

                        DatePicker(
                            "開始時刻",
                            selection:
                                $startTime,
                            displayedComponents:
                                .hourAndMinute
                        )

                        DatePicker(
                            "終了時刻",
                            selection:
                                $endTime,
                            displayedComponents:
                                .hourAndMinute
                        )
                    }
                    .padding()
                }

                GroupBox(
                    "業務内容"
                ) {

                    TextEditor(
                        text:
                            $workDetails
                    )
                    .frame(
                        minHeight: 110
                    )
                    .padding(6)
                }

                GroupBox(
                    "指示・命令された内容"
                ) {

                    TextEditor(
                        text:
                            $instructionDetails
                    )
                    .frame(
                        minHeight: 110
                    )
                    .padding(6)
                }

                HStack {

                    Spacer()

                    Button {

                        saveRecord()

                    } label: {

                        Label(
                            "勤務記録を保存",
                            systemImage:
                                "square.and.arrow.down"
                        )
                    }
                    .controlSize(.large)
                    .disabled(
                        workDetails
                            .trimmingCharacters(
                                in:
                                    .whitespacesAndNewlines
                            )
                            .isEmpty
                    )
                }

                Divider()

                HStack {

                    Text("保存済み記録")
                        .font(.title2)
                        .fontWeight(.bold)

                    Spacer()

                    TextField(
                        "勤務記録を検索",
                        text:
                            $searchText
                    )
                    .textFieldStyle(
                        .roundedBorder
                    )
                    .frame(width: 260)
                }

                if filteredRecords.isEmpty {

                    ContentUnavailableView(
                        "勤務記録が見つかりません",
                        systemImage:
                            "clock",
                        description:
                            Text(
                                "保存した勤務記録がここに表示されます。"
                            )
                    )

                } else {

                    ForEach(
                        filteredRecords
                    ) { record in

                        WorkRecordRow(
                            record:
                                record,
                            onEdit: {

                                editingRecord =
                                    record
                            },
                            onDelete: {

                                modelContext
                                    .delete(
                                        record
                                    )

                                _ = RecordPersistence.save(modelContext)
                            }
                        )
                    }
                }
            }
            .padding(40)
        }
        .sheet(
            item:
                $editingRecord
        ) { record in

            WorkRecordEditView(
                record:
                    record
            )
        }
    }

    private func saveRecord() {

        let newRecord =
            WorkRecord(
                date: workDate,
                startTime:
                    startTime,
                endTime:
                    endTime,
                workDetails:
                    workDetails,
                instructionDetails:
                    instructionDetails
            )

        modelContext.insert(
            newRecord
        )

        do {

            try modelContext.save()

        } catch {
            modelContext.rollback()
            RecordPersistence.showError(error)

            return
        }

        workDetails = ""
        instructionDetails = ""
    }
}

struct WorkRecordRow: View {

    let record: WorkRecord
    let onEdit: () -> Void
    let onDelete: () -> Void

    var body: some View {

        VStack(
            alignment: .leading,
            spacing: 10
        ) {

            HStack {

                Text(
                    record.date
                        .formatted(
                            date: .long,
                            time: .omitted
                        )
                )
                .font(.headline)

                Spacer()

                Button {

                    onEdit()

                } label: {

                    Image(
                        systemName:
                            "pencil"
                    )
                }
                .buttonStyle(.borderless)

                Button(
                    role:
                        .destructive
                ) {

                    onDelete()

                } label: {

                    Image(
                        systemName:
                            "trash"
                    )
                }
                .buttonStyle(.borderless)
            }

            Text(
                "\(record.startTime.formatted(date: .omitted, time: .shortened)) 〜 \(record.endTime.formatted(date: .omitted, time: .shortened))"
            )
            .foregroundStyle(.secondary)

            Divider()

            Text("業務内容")
                .fontWeight(.semibold)

            Text(record.workDetails)

            if !record
                .instructionDetails
                .isEmpty {

                Text("指示内容")
                    .fontWeight(.semibold)

                Text(
                    record
                        .instructionDetails
                )
            }
        }
        .padding()
        .background(
            .quaternary.opacity(0.35)
        )
        .clipShape(
            RoundedRectangle(
                cornerRadius: 14
            )
        )
    }
}

struct WorkRecordEditView: View {

    @Environment(\.dismiss)
    private var dismiss

    @Environment(\.modelContext)
    private var modelContext

    let record: WorkRecord

    @State private var date:
        Date

    @State private var startTime:
        Date

    @State private var endTime:
        Date

    @State private var workDetails:
        String

    @State private var instructionDetails:
        String

    init(
        record: WorkRecord
    ) {

        self.record =
            record

        _date =
            State(
                initialValue:
                    record.date
            )

        _startTime =
            State(
                initialValue:
                    record.startTime
            )

        _endTime =
            State(
                initialValue:
                    record.endTime
            )

        _workDetails =
            State(
                initialValue:
                    record.workDetails
            )

        _instructionDetails =
            State(
                initialValue:
                    record
                        .instructionDetails
            )
    }

    var body: some View {

        VStack(
            alignment: .leading,
            spacing: 20
        ) {

            Text("勤務記録を編集")
                .font(.title)
                .fontWeight(.bold)

            DatePicker(
                "勤務日",
                selection:
                    $date,
                displayedComponents:
                    .date
            )

            DatePicker(
                "開始時刻",
                selection:
                    $startTime,
                displayedComponents:
                    .hourAndMinute
            )

            DatePicker(
                "終了時刻",
                selection:
                    $endTime,
                displayedComponents:
                    .hourAndMinute
            )

            Text("業務内容")
                .fontWeight(.semibold)

            TextEditor(
                text:
                    $workDetails
            )
            .frame(height: 100)

            Text("指示内容")
                .fontWeight(.semibold)

            TextEditor(
                text:
                    $instructionDetails
            )
            .frame(height: 100)

            HStack {

                Button(
                    "キャンセル"
                ) {
                    dismiss()
                }

                Spacer()

                Button(
                    "変更を保存"
                ) {

                    record.date =
                        date

                    record.startTime =
                        startTime

                    record.endTime =
                        endTime

                    record.workDetails =
                        workDetails

                    record.instructionDetails =
                        instructionDetails

                    if RecordPersistence.save(modelContext) { dismiss() }
                }
                .keyboardShortcut(
                    .defaultAction
                )
            }
        }
        .padding(30)
        .frame(
            width: 600,
            height: 560
        )
    }
}

// ======================================================
// MARK: - 証拠・メモ
// ======================================================

struct EvidenceView: View {

    @Environment(\.modelContext)
    private var modelContext

    @Query(
        sort:
            \EvidenceMemo.createdAt,
        order: .reverse
    )
    private var memos:
        [EvidenceMemo]

    @State private var title = ""
    @State private var category =
        "業務指示"

    @State private var details = ""
    @State private var createdAt =
        Date()

    @State private var searchText = ""

    @State private var editingMemo:
        EvidenceMemo?

    private let categories = [
        "業務指示",
        "出社要請",
        "勤務時間",
        "シフト",
        "契約",
        "報酬",
        "連絡",
        "その他"
    ]

    private var filteredMemos:
        [EvidenceMemo] {

        if searchText.isEmpty {
            return memos
        }

        return memos.filter {

            $0.title
                .localizedCaseInsensitiveContains(
                    searchText
                )
            ||
            $0.category
                .localizedCaseInsensitiveContains(
                    searchText
                )
            ||
            $0.details
                .localizedCaseInsensitiveContains(
                    searchText
                )
        }
    }

    var body: some View {

        ScrollView {

            VStack(
                alignment: .leading,
                spacing: 24
            ) {

                Text("証拠・メモ")
                    .font(.largeTitle)
                    .fontWeight(.bold)

                Text(
                    "重要な指示や出来事を、その日のうちに記録しておけます。"
                )
                .font(.title3)
                .foregroundStyle(.secondary)

                Divider()

                GroupBox(
                    "新しいメモ"
                ) {

                    VStack(
                        alignment: .leading,
                        spacing: 16
                    ) {

                        DatePicker(
                            "日時",
                            selection:
                                $createdAt
                        )

                        Picker(
                            "分類",
                            selection:
                                $category
                        ) {

                            ForEach(
                                categories,
                                id: \.self
                            ) {

                                Text($0)
                            }
                        }

                        TextField(
                            "タイトル",
                            text:
                                $title
                        )

                        TextEditor(
                            text:
                                $details
                        )
                        .frame(
                            minHeight: 140
                        )

                        HStack {

                            Spacer()

                            Button {

                                saveMemo()

                            } label: {

                                Label(
                                    "証拠・メモを保存",
                                    systemImage:
                                        "square.and.arrow.down"
                                )
                            }
                            .controlSize(.large)
                            .disabled(
                                title
                                    .trimmingCharacters(
                                        in:
                                            .whitespacesAndNewlines
                                    )
                                    .isEmpty
                            )
                        }
                    }
                    .padding()
                }

                HStack {

                    Text("保存済みメモ")
                        .font(.title2)
                        .fontWeight(.bold)

                    Spacer()

                    TextField(
                        "メモを検索",
                        text:
                            $searchText
                    )
                    .textFieldStyle(
                        .roundedBorder
                    )
                    .frame(width: 260)
                }

                if filteredMemos.isEmpty {

                    ContentUnavailableView(
                        "メモが見つかりません",
                        systemImage:
                            "doc.text"
                    )

                } else {

                    ForEach(
                        filteredMemos
                    ) { memo in

                        VStack(
                            alignment: .leading,
                            spacing: 8
                        ) {

                            HStack {

                                Text(memo.title)
                                    .font(.headline)

                                Spacer()

                                Button {

                                    editingMemo =
                                        memo

                                } label: {

                                    Image(
                                        systemName:
                                            "pencil"
                                    )
                                }
                                .buttonStyle(
                                    .borderless
                                )

                                Button(
                                    role:
                                        .destructive
                                ) {

                                    modelContext
                                        .delete(
                                            memo
                                        )

                                    _ = RecordPersistence.save(modelContext)

                                } label: {

                                    Image(
                                        systemName:
                                            "trash"
                                    )
                                }
                                .buttonStyle(
                                    .borderless
                                )
                            }

                            Text(memo.category)
                                .font(.caption)
                                .padding(
                                    .horizontal,
                                    8
                                )
                                .padding(
                                    .vertical,
                                    4
                                )
                                .background(
                                    .quaternary
                                )
                                .clipShape(
                                    Capsule()
                                )

                            Text(
                                memo.createdAt
                                    .formatted(
                                        date: .long,
                                        time: .shortened
                                    )
                            )
                            .foregroundStyle(
                                .secondary
                            )

                            if !memo.details.isEmpty {

                                Divider()

                                Text(memo.details)
                            }
                        }
                        .padding()
                        .background(
                            .quaternary
                                .opacity(0.35)
                        )
                        .clipShape(
                            RoundedRectangle(
                                cornerRadius:
                                    14
                            )
                        )
                    }
                }
            }
            .padding(40)
        }
        .sheet(
            item:
                $editingMemo
        ) { memo in

            EvidenceEditView(
                memo: memo
            )
        }
    }

    private func saveMemo() {

        let memo =
            EvidenceMemo(
                createdAt:
                    createdAt,
                title:
                    title,
                category:
                    category,
                details:
                    details
            )

        modelContext.insert(memo)

        do {

            try modelContext.save()

        } catch {
            modelContext.rollback()
            RecordPersistence.showError(error)

            return
        }

        title = ""
        details = ""
        category = "業務指示"
        createdAt = Date()
    }
}

struct EvidenceEditView: View {

    @Environment(\.dismiss)
    private var dismiss

    @Environment(\.modelContext)
    private var modelContext

    let memo:
        EvidenceMemo

    @State private var title:
        String

    @State private var category:
        String

    @State private var details:
        String

    @State private var date:
        Date

    init(
        memo: EvidenceMemo
    ) {

        self.memo = memo

        _title =
            State(
                initialValue:
                    memo.title
            )

        _category =
            State(
                initialValue:
                    memo.category
            )

        _details =
            State(
                initialValue:
                    memo.details
            )

        _date =
            State(
                initialValue:
                    memo.createdAt
            )
    }

    var body: some View {

        VStack(
            alignment: .leading,
            spacing: 18
        ) {

            Text("証拠・メモを編集")
                .font(.title)
                .fontWeight(.bold)

            DatePicker(
                "日時",
                selection:
                    $date
            )

            TextField(
                "タイトル",
                text: $title
            )

            TextField(
                "分類",
                text: $category
            )

            TextEditor(
                text: $details
            )
            .frame(height: 180)

            HStack {

                Button(
                    "キャンセル"
                ) {
                    dismiss()
                }

                Spacer()

                Button(
                    "変更を保存"
                ) {

                    memo.title = title
                    memo.category = category
                    memo.details = details
                    memo.createdAt = date

                    if RecordPersistence.save(modelContext) { dismiss() }
                }
            }
        }
        .padding(30)
        .frame(
            width: 600,
            height: 470
        )
    }
}

// ======================================================
// MARK: - 期限・重要日
// ======================================================

struct DeadlineView: View {

    @Environment(\.modelContext)
    private var modelContext

    @Query(
        sort:
            \DeadlineItem.dueDate,
        order: .forward
    )
    private var deadlines:
        [DeadlineItem]

    @State private var title = ""
    @State private var dueDate =
        Date()

    @State private var note = ""
    @State private var searchText = ""

    @State private var editingDeadline:
        DeadlineItem?

    private var filteredDeadlines:
        [DeadlineItem] {

        if searchText.isEmpty {
            return deadlines
        }

        return deadlines.filter {

            $0.title
                .localizedCaseInsensitiveContains(
                    searchText
                )
            ||
            $0.note
                .localizedCaseInsensitiveContains(
                    searchText
                )
        }
    }

    var body: some View {

        ScrollView {

            VStack(
                alignment: .leading,
                spacing: 24
            ) {

                Text("期限・重要日")
                    .font(.largeTitle)
                    .fontWeight(.bold)

                Text(
                    "契約更新日・支払日・回答期限などを管理できます。"
                )
                .font(.title3)
                .foregroundStyle(.secondary)

                Divider()

                GroupBox(
                    "重要日を追加"
                ) {

                    VStack(
                        alignment: .leading,
                        spacing: 16
                    ) {

                        TextField(
                            "例：契約更新日、報酬支払日、回答期限",
                            text:
                                $title
                        )

                        DatePicker(
                            "日付",
                            selection:
                                $dueDate,
                            displayedComponents:
                                .date
                        )

                        TextEditor(
                            text:
                                $note
                        )
                        .frame(
                            minHeight: 100
                        )

                        HStack {

                            Spacer()

                            Button {

                                saveDeadline()

                            } label: {

                                Label(
                                    "重要日を保存",
                                    systemImage:
                                        "calendar.badge.plus"
                                )
                            }
                            .controlSize(.large)
                            .disabled(
                                title
                                    .trimmingCharacters(
                                        in:
                                            .whitespacesAndNewlines
                                    )
                                    .isEmpty
                            )
                        }
                    }
                    .padding()
                }

                HStack {

                    Text("登録済み")
                        .font(.title2)
                        .fontWeight(.bold)

                    Spacer()

                    TextField(
                        "重要日を検索",
                        text:
                            $searchText
                    )
                    .textFieldStyle(
                        .roundedBorder
                    )
                    .frame(width: 260)
                }

                if filteredDeadlines.isEmpty {

                    ContentUnavailableView(
                        "重要日が見つかりません",
                        systemImage:
                            "calendar"
                    )

                } else {

                    ForEach(
                        filteredDeadlines
                    ) { item in

                        HStack(
                            alignment: .top,
                            spacing: 16
                        ) {

                            Image(
                                systemName:
                                    "calendar"
                            )
                            .font(.title2)

                            VStack(
                                alignment: .leading,
                                spacing: 6
                            ) {

                                Text(item.title)
                                    .font(.headline)

                                Text(
                                    item.dueDate
                                        .formatted(
                                            date: .long,
                                            time: .omitted
                                        )
                                )
                                .foregroundStyle(
                                    .secondary
                                )

                                if !item.note.isEmpty {

                                    Text(item.note)
                                }
                            }

                            Spacer()

                            Button {

                                editingDeadline =
                                    item

                            } label: {

                                Image(
                                    systemName:
                                        "pencil"
                                )
                            }
                            .buttonStyle(
                                .borderless
                            )

                            Button(
                                role:
                                    .destructive
                            ) {

                                modelContext
                                    .delete(
                                        item
                                    )

                                _ = RecordPersistence.save(modelContext)

                            } label: {

                                Image(
                                    systemName:
                                        "trash"
                                )
                            }
                            .buttonStyle(
                                .borderless
                            )
                        }
                        .padding()
                        .background(
                            .quaternary
                                .opacity(0.35)
                        )
                        .clipShape(
                            RoundedRectangle(
                                cornerRadius:
                                    14
                            )
                        )
                    }
                }
            }
            .padding(40)
        }
        .sheet(
            item:
                $editingDeadline
        ) { item in

            DeadlineEditView(
                item: item
            )
        }
    }

    private func saveDeadline() {

        let item =
            DeadlineItem(
                dueDate:
                    dueDate,
                title:
                    title,
                note:
                    note
            )

        modelContext.insert(item)

        do {

            try modelContext.save()

        } catch {
            modelContext.rollback()
            RecordPersistence.showError(error)

            return
        }

        title = ""
        note = ""
        dueDate = Date()
    }
}

struct DeadlineEditView: View {

    @Environment(\.dismiss)
    private var dismiss

    @Environment(\.modelContext)
    private var modelContext

    let item:
        DeadlineItem

    @State private var title:
        String

    @State private var date:
        Date

    @State private var note:
        String

    init(
        item:
            DeadlineItem
    ) {

        self.item = item

        _title =
            State(
                initialValue:
                    item.title
            )

        _date =
            State(
                initialValue:
                    item.dueDate
            )

        _note =
            State(
                initialValue:
                    item.note
            )
    }

    var body: some View {

        VStack(
            alignment: .leading,
            spacing: 18
        ) {

            Text("重要日を編集")
                .font(.title)
                .fontWeight(.bold)

            TextField(
                "タイトル",
                text: $title
            )

            DatePicker(
                "日付",
                selection:
                    $date,
                displayedComponents:
                    .date
            )

            TextEditor(
                text: $note
            )
            .frame(height: 160)

            HStack {

                Button(
                    "キャンセル"
                ) {
                    dismiss()
                }

                Spacer()

                Button(
                    "変更を保存"
                ) {

                    item.title = title
                    item.dueDate = date
                    item.note = note

                    if RecordPersistence.save(modelContext) { dismiss() }
                }
            }
        }
        .padding(30)
        .frame(
            width: 600,
            height: 400
        )
    }
}

// ======================================================
// MARK: - 全体検索
// ======================================================

struct SearchView: View {

    @EnvironmentObject
    private var contractStore:
        ContractStore

    @Query
    private var workRecords:
        [WorkRecord]

    @Query
    private var memos:
        [EvidenceMemo]

    @Query
    private var deadlines:
        [DeadlineItem]

    @Query
    private var lawResults:
        [FreelanceLawResult]

    @State private var searchText = ""

    var body: some View {

        ScrollView {

            VStack(
                alignment: .leading,
                spacing: 24
            ) {

                Text("全体検索")
                    .font(.largeTitle)
                    .fontWeight(.bold)

                TextField(
                    "契約・勤務・証拠・期限・チェック結果をまとめて検索",
                    text:
                        $searchText
                )
                .textFieldStyle(
                    .roundedBorder
                )
                .font(.title3)

                Divider()

                if searchText.isEmpty {

                    ContentUnavailableView(
                        "検索キーワードを入力してください",
                        systemImage:
                            "magnifyingglass"
                    )

                } else {

                    searchResults
                }
            }
            .padding(40)
        }
    }

    @ViewBuilder
    private var searchResults:
        some View {

        let contractMatches =
            contractStore.contracts.filter {

                $0.company
                    .localizedCaseInsensitiveContains(
                        searchText
                    )
                ||
                $0.person
                    .localizedCaseInsensitiveContains(
                        searchText
                    )
                ||
                $0.contractType
                    .localizedCaseInsensitiveContains(
                        searchText
                    )
                ||
                $0.pay
                    .localizedCaseInsensitiveContains(
                        searchText
                    )
                ||
                $0.workStyle
                    .localizedCaseInsensitiveContains(
                        searchText
                    )
                ||
                $0.notes
                    .localizedCaseInsensitiveContains(
                        searchText
                    )
            }

        let workMatches =
            workRecords.filter {

                $0.workDetails
                    .localizedCaseInsensitiveContains(
                        searchText
                    )
                ||
                $0.instructionDetails
                    .localizedCaseInsensitiveContains(
                        searchText
                    )
            }

        let memoMatches =
            memos.filter {

                $0.title
                    .localizedCaseInsensitiveContains(
                        searchText
                    )
                ||
                $0.details
                    .localizedCaseInsensitiveContains(
                        searchText
                    )
                ||
                $0.category
                    .localizedCaseInsensitiveContains(
                        searchText
                    )
            }

        let deadlineMatches =
            deadlines.filter {

                $0.title
                    .localizedCaseInsensitiveContains(
                        searchText
                    )
                ||
                $0.note
                    .localizedCaseInsensitiveContains(
                        searchText
                    )
            }

        let lawMatches =
            lawResults.filter {

                $0.resultMessage
                    .localizedCaseInsensitiveContains(
                        searchText
                    )
                ||
                String(
                    $0.warningCount
                )
                .localizedCaseInsensitiveContains(
                    searchText
                )
            }

        if contractMatches.isEmpty &&
            workMatches.isEmpty &&
            memoMatches.isEmpty &&
            deadlineMatches.isEmpty &&
            lawMatches.isEmpty {

            ContentUnavailableView(
                "一致する記録はありません",
                systemImage:
                    "magnifyingglass"
            )

        } else {

            if !contractMatches.isEmpty {

                SearchSectionTitle(
                    title: "契約情報"
                )

                ForEach(
                    contractMatches
                ) { item in

                    SearchResultCard(
                        icon:
                            "doc.badge.gearshape",
                        title:
                            item.company,
                        text:
                            "\(item.contractType)  \(item.pay)"
                    )
                }
            }

            if !workMatches.isEmpty {

                SearchSectionTitle(
                    title: "勤務記録"
                )

                ForEach(
                    workMatches
                ) { item in

                    SearchResultCard(
                        icon: "clock",
                        title:
                            item.workDetails,
                        text:
                            item.instructionDetails
                    )
                }
            }

            if !memoMatches.isEmpty {

                SearchSectionTitle(
                    title:
                        "証拠・メモ"
                )

                ForEach(
                    memoMatches
                ) { item in

                    SearchResultCard(
                        icon: "doc.text",
                        title:
                            item.title,
                        text:
                            item.details
                    )
                }
            }

            if !deadlineMatches.isEmpty {

                SearchSectionTitle(
                    title:
                        "期限・重要日"
                )

                ForEach(
                    deadlineMatches
                ) { item in

                    SearchResultCard(
                        icon:
                            "calendar",
                        title:
                            item.title,
                        text:
                            item.note
                    )
                }
            }

            if !lawMatches.isEmpty {

                SearchSectionTitle(
                    title:
                        "フリーランス法チェック"
                )

                ForEach(
                    lawMatches
                ) { item in

                    SearchResultCard(
                        icon:
                            "checkmark.seal",
                        title:
                            "確認項目 \(item.warningCount)件",
                        text:
                            item.resultMessage
                    )
                }
            }
        }
    }
}

struct SearchSectionTitle: View {

    let title: String

    var body: some View {

        Text(title)
            .font(.title2)
            .fontWeight(.bold)
            .padding(.top, 8)
    }
}

struct SearchResultCard: View {

    let icon: String
    let title: String
    let text: String

    var body: some View {

        HStack(
            alignment: .top,
            spacing: 14
        ) {

            Image(
                systemName:
                    icon
            )
            .font(.title2)

            VStack(
                alignment: .leading,
                spacing: 6
            ) {

                Text(title)
                    .font(.headline)

                if !text.isEmpty {

                    Text(text)
                        .foregroundStyle(
                            .secondary
                        )
                }
            }

            Spacer()
        }
        .padding()
        .background(
            .quaternary.opacity(0.35)
        )
        .clipShape(
            RoundedRectangle(
                cornerRadius: 12
            )
        )
    }
}

// ======================================================
// MARK: - レポート
// ======================================================

struct ReportView: View {

    @EnvironmentObject
    private var contractStore:
        ContractStore

    @Query(
        sort:
            \WorkRecord.date,
        order: .reverse
    )
    private var workRecords:
        [WorkRecord]

    @Query(
        sort:
            \EvidenceMemo.createdAt,
        order: .reverse
    )
    private var evidenceMemos:
        [EvidenceMemo]

    @Query(
        sort:
            \DeadlineItem.dueDate,
        order: .forward
    )
    private var deadlines:
        [DeadlineItem]

    @Query(
        sort:
            \FreelanceLawResult.createdAt,
        order: .reverse
    )
    private var lawResults:
        [FreelanceLawResult]

    var body: some View {

        ScrollView {

            VStack(
                alignment: .leading,
                spacing: 28
            ) {

                Text("レポート")
                    .font(.largeTitle)
                    .fontWeight(.bold)

                Text(
                    "保存されている記録を確認・書き出しできます。"
                )
                .font(.title3)
                .foregroundStyle(.secondary)

                Divider()

                GroupBox(
                    "レポート出力"
                ) {

                    HStack(
                        spacing: 14
                    ) {

                        Button {

                            ReportExporter
                                .exportPDF(
                                    contracts:
                                        contractStore.contracts,
                                    workRecords:
                                        workRecords,
                                    memos:
                                        evidenceMemos,
                                    deadlines:
                                        deadlines,
                                    lawResults:
                                        lawResults
                                )

                        } label: {

                            Label(
                                "PDF保存",
                                systemImage:
                                    "doc.richtext"
                            )
                            .frame(
                                minWidth: 110
                            )
                        }
                        .controlSize(.large)
                        .buttonStyle(
                            .borderedProminent
                        )

                        Button {

                            ReportExporter
                                .exportCSV(
                                    contracts:
                                        contractStore.contracts,
                                    workRecords:
                                        workRecords,
                                    memos:
                                        evidenceMemos,
                                    deadlines:
                                        deadlines,
                                    lawResults:
                                        lawResults
                                )

                        } label: {

                            Label(
                                "CSV保存",
                                systemImage:
                                    "tablecells"
                            )
                            .frame(
                                minWidth: 110
                            )
                        }
                        .controlSize(.large)

                        Button {

                            ReportExporter
                                .printReport(
                                    contracts:
                                        contractStore.contracts,
                                    workRecords:
                                        workRecords,
                                    memos:
                                        evidenceMemos,
                                    deadlines:
                                        deadlines,
                                    lawResults:
                                        lawResults
                                )

                        } label: {

                            Label(
                                "印刷",
                                systemImage:
                                    "printer"
                            )
                            .frame(
                                minWidth: 100
                            )
                        }
                        .controlSize(.large)

                        Spacer()
                    }
                    .padding(10)
                }

                HStack(spacing: 18) {

                    DashboardCard(
                        icon:
                            "doc.badge.gearshape",
                        title:
                            "契約情報",
                        value:
                            "\(contractStore.contracts.count)件"
                    )

                    DashboardCard(
                        icon:
                            "clock",
                        title:
                            "勤務記録",
                        value:
                            "\(workRecords.count)件"
                    )
                }

                HStack(spacing: 18) {

                    DashboardCard(
                        icon:
                            "doc.text",
                        title:
                            "証拠・メモ",
                        value:
                            "\(evidenceMemos.count)件"
                    )

                    DashboardCard(
                        icon:
                            "calendar",
                        title:
                            "重要日",
                        value:
                            "\(deadlines.count)件"
                    )
                }

                DashboardCard(
                    icon:
                        "checkmark.seal",
                    title:
                        "法チェック履歴",
                    value:
                        "\(lawResults.count)件"
                )
                .frame(maxWidth: 420)

                GroupBox(
                    "記録状況"
                ) {

                    VStack(
                        alignment: .leading,
                        spacing: 14
                    ) {

                        ReportLine(
                            title:
                                "契約情報",
                            value:
                                "\(contractStore.contracts.count)件"
                        )

                        ReportLine(
                            title:
                                "勤務記録",
                            value:
                                "\(workRecords.count)件"
                        )

                        ReportLine(
                            title:
                                "証拠・メモ",
                            value:
                                "\(evidenceMemos.count)件"
                        )

                        ReportLine(
                            title:
                                "期限・重要日",
                            value:
                                "\(deadlines.count)件"
                        )

                        ReportLine(
                            title:
                                "フリーランス法チェック",
                            value:
                                "\(lawResults.count)件"
                        )
                    }
                    .padding()
                }

                if !contractStore
                    .contracts
                    .isEmpty {

                    Text(
                        "保存されている契約"
                    )
                    .font(.title2)
                    .fontWeight(.bold)

                    ForEach(
                        contractStore.contracts
                    ) { contract in

                        VStack(
                            alignment: .leading,
                            spacing: 8
                        ) {

                            Text(
                                contract.company
                            )
                            .font(.headline)

                            ContractInfoRow(
                                title:
                                    "担当者",
                                value:
                                    contract.person
                            )

                            ContractInfoRow(
                                title:
                                    "契約形態",
                                value:
                                    contract.contractType
                            )

                            ContractInfoRow(
                                title:
                                    "報酬",
                                value:
                                    contract.pay
                            )

                            ContractInfoRow(
                                title:
                                    "働き方",
                                value:
                                    contract.workStyle
                            )

                            if !contract.notes.isEmpty {

                                Divider()

                                Text(
                                    contract.notes
                                )
                                .foregroundStyle(
                                    .secondary
                                )
                            }
                        }
                        .padding()
                        .background(
                            .quaternary
                                .opacity(0.35)
                        )
                        .clipShape(
                            RoundedRectangle(
                                cornerRadius: 14
                            )
                        )
                    }
                }

                if !lawResults.isEmpty {

                    Text(
                        "フリーランス法チェック履歴"
                    )
                    .font(.title2)
                    .fontWeight(.bold)

                    ForEach(
                        lawResults
                    ) { result in

                        VStack(
                            alignment: .leading,
                            spacing: 8
                        ) {

                            Text(
                                result.createdAt
                                    .formatted(
                                        date: .long,
                                        time: .shortened
                                    )
                            )
                            .font(.headline)

                            Text(
                                "確認が必要な項目：\(result.warningCount)件"
                            )
                            .fontWeight(
                                .semibold
                            )

                            Text(
                                result.resultMessage
                            )
                            .foregroundStyle(
                                .secondary
                            )
                        }
                        .padding()
                        .background(
                            .quaternary
                                .opacity(0.35)
                        )
                        .clipShape(
                            RoundedRectangle(
                                cornerRadius: 14
                            )
                        )
                    }
                }

                Divider()

                Label(
                    "PDFは相談・保管用、CSVはExcelやNumbersでの集計用として利用できます。",
                    systemImage:
                        "info.circle"
                )
                .foregroundStyle(.secondary)
            }
            .padding(40)
        }
    }
}

struct ReportLine: View {

    let title: String
    let value: String

    var body: some View {

        HStack {

            Text(title)

            Spacer()

            Text(value)
                .fontWeight(.semibold)
        }
    }
}

// ======================================================
// MARK: - 設定
// ======================================================

struct SettingsView: View {

    @EnvironmentObject
    private var contractStore:
        ContractStore

    @Environment(\.modelContext)
    private var modelContext

    @AppStorage(
        "showRecordReminder"
    )
    private var showRecordReminder =
        true

    @AppStorage(
        "displayLegalNotice"
    )
    private var displayLegalNotice =
        true

    var body: some View {

        Form {

            Section("記録") {

                Toggle(
                    "勤務後に記録を残すことを意識する",
                    isOn:
                        $showRecordReminder
                )
            }

            Section("表示") {

                Toggle(
                    "法的判断ではない旨の注意事項を表示する",
                    isOn:
                        $displayLegalNotice
                )
            }

            Section("プライバシー・データ") {
                Text("入力した契約情報・勤務記録・証拠メモ・チェック履歴は、このMacのアプリ用領域に保存されます。アプリから開発者への送信、広告、アクセス解析は行いません。")
                Text("文章整理と文書作成は端末内で処理します。相談先のリンクは標準ブラウザで開き、リンク先のプライバシーポリシーが適用されます。")
                Text("PDF・CSV・バックアップには入力した情報が含まれます。保存先や共有相手を確認してください。記録は各一覧から削除できます。外部に保存したファイルはアプリ内で記録を削除しても残ります。")
            }

            Section("バックアップ") {

                VStack(
                    alignment: .leading,
                    spacing: 12
                ) {

                    Text(
                        "契約情報・勤務記録・証拠メモ・重要日・フリーランス法チェック履歴をまとめて保存できます。"
                    )
                    .foregroundStyle(
                        .secondary
                    )

                    HStack(spacing: 14) {

                        Button {

                            BackupManager
                                .exportBackup(
                                    contractStore:
                                        contractStore,
                                    modelContext:
                                        modelContext
                                )

                        } label: {

                            Label(
                                "バックアップを作成",
                                systemImage:
                                    "externaldrive.badge.plus"
                            )
                        }
                        .controlSize(.large)
                        .buttonStyle(
                            .borderedProminent
                        )

                        Button {

                            BackupManager
                                .restoreBackup(
                                    contractStore:
                                        contractStore,
                                    modelContext:
                                        modelContext
                                )

                        } label: {

                            Label(
                                "バックアップから復元",
                                systemImage:
                                    "arrow.counterclockwise"
                            )
                        }
                        .controlSize(.large)
                    }

                    Text(
                        "復元すると、現在のアプリ内データはバックアップ内のデータに置き換わります。"
                    )
                    .font(.caption)
                    .foregroundStyle(
                        .secondary
                    )
                }
                .padding(.vertical, 6)
            }

            Section(
                "アプリについて"
            ) {

                LabeledContent(
                    "アプリ名",
                    value:
                        "フリーランス守りナビ"
                )

                LabeledContent(
                    "版",
                    value:
                        "\(Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "1.0")（\(Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "2")）"
                )
            }

            Section("搭載機能") {

                Text("働き方チェック")
                Text("フリーランス法チェック")
                Text("契約情報")
                Text("勤務記録")
                Text("証拠・メモ")
                Text("期限・重要日")
                Text("全体検索")
                Text("レポート")
                Text("PDF出力")
                Text("CSV出力")
                Text("印刷")
                Text("バックアップ")
                Text("復元")
            }

            Section("注意事項") {

                Text(
                    "このアプリは記録や情報整理を支援するためのもので、個別の法的判断や法律相談を行うものではありません。"
                )
                .foregroundStyle(.secondary)
            }
        }
        .formStyle(.grouped)
        .padding(30)
    }
}

// ======================================================
// MARK: - サイドバー
// ======================================================

enum SidebarItem:
    String,
    CaseIterable,
    Identifiable {

    case home
    case workCheck
    case freelanceLaw
    case contract
    case workLog
    case evidence
    case deadlines
    case consultation
    case documents
    case organizer
    case checklist
    case guides
    case search
    case reports
    case settings

    var id: String {
        rawValue
    }

    var title: String {

        switch self {

        case .home:
            return "ホーム"

        case .workCheck:
            return "働き方チェック"

        case .freelanceLaw:
            return "フリーランス法チェック"

        case .contract:
            return "契約情報"

        case .workLog:
            return "勤務記録"

        case .evidence:
            return "証拠・メモ"

        case .deadlines:
            return "期限・重要日"

        case .consultation:
            return "相談先案内"

        case .documents:
            return "文書作成サポート"

        case .organizer:
            return "文章整理"

        case .checklist:
            return "証拠チェックリスト"

        case .guides:
            return "契約・トラブルの基礎知識"

        case .search:
            return "全体検索"

        case .reports:
            return "レポート"

        case .settings:
            return "設定"
        }
    }

    var icon: String {

        switch self {

        case .home:
            return "house"

        case .workCheck:
            return "checklist"

        case .freelanceLaw:
            return "checkmark.seal"

        case .contract:
            return "doc.badge.gearshape"

        case .workLog:
            return "clock"

        case .evidence:
            return "doc.text"

        case .deadlines:
            return "calendar"

        case .consultation:
            return "person.2"

        case .documents:
            return "doc.text.fill"

        case .organizer:
            return "text.alignleft"

        case .checklist:
            return "checklist.checked"

        case .guides:
            return "book.closed"

        case .search:
            return "magnifyingglass"

        case .reports:
            return "chart.bar"

        case .settings:
            return "gearshape"
        }
    }
}

// ======================================================
// MARK: - Preview
// ======================================================

#Preview {

    ContentView()
        .modelContainer(
            for: [
                WorkRecord.self,
                EvidenceMemo.self,
                DeadlineItem.self,
                FreelanceLawResult.self
            ],
            inMemory: true
        )
}


@MainActor
enum RecordPersistence {
    static func save(_ context: ModelContext) -> Bool {
        do {
            try context.save()
            return true
        } catch {
            context.rollback()
            showError(error)
            return false
        }
    }

    static func showError(_ error: Error) {
        let alert = NSAlert()
        alert.messageText = "保存できませんでした"
        alert.informativeText = error.localizedDescription
        alert.alertStyle = .warning
        alert.runModal()
    }
}
