import Foundation
import AppKit
import SwiftData
import UniformTypeIdentifiers

// ======================================================
// MARK: - バックアップ用データ
// ======================================================

struct BackupArchive: Codable {
    var createdAt: Date
    var version: Int

    var contracts: [ContractRecord]
    var workRecords: [WorkRecordBackup]
    var evidenceMemos: [EvidenceMemoBackup]
    var deadlines: [DeadlineBackup]
    var lawResults: [FreelanceLawResultBackup]
    var workStyleHistory: [MacWorkStyleHistory]?
}

struct WorkRecordBackup: Codable {
    var date: Date
    var startTime: Date
    var endTime: Date
    var workDetails: String
    var instructionDetails: String
}

struct EvidenceMemoBackup: Codable {
    var createdAt: Date
    var title: String
    var category: String
    var details: String
}

struct DeadlineBackup: Codable {
    var dueDate: Date
    var title: String
    var note: String
}

struct FreelanceLawResultBackup: Codable {
    var createdAt: Date
    var warningCount: Int
    var answersRaw: String
    var resultMessage: String
}

// ======================================================
// MARK: - バックアップ管理
// ======================================================

@MainActor
enum BackupManager {

    // ==================================================
    // MARK: バックアップ作成
    // ==================================================

    static func exportBackup(
        contractStore: ContractStore,
        modelContext: ModelContext
    ) {

        do {

            let workRecords =
                try modelContext.fetch(
                    FetchDescriptor<WorkRecord>()
                )

            let memos =
                try modelContext.fetch(
                    FetchDescriptor<EvidenceMemo>()
                )

            let deadlines =
                try modelContext.fetch(
                    FetchDescriptor<DeadlineItem>()
                )

            let lawResults =
                try modelContext.fetch(
                    FetchDescriptor<FreelanceLawResult>()
                )

            let archive =
                BackupArchive(
                    createdAt: Date(),
                    version: 1,
                    contracts:
                        try contractStore.validatedSnapshot(),
                    workRecords:
                        workRecords.map {
                            WorkRecordBackup(
                                date: $0.date,
                                startTime: $0.startTime,
                                endTime: $0.endTime,
                                workDetails: $0.workDetails,
                                instructionDetails:
                                    $0.instructionDetails
                            )
                        },
                    evidenceMemos:
                        memos.map {
                            EvidenceMemoBackup(
                                createdAt:
                                    $0.createdAt,
                                title:
                                    $0.title,
                                category:
                                    $0.category,
                                details:
                                    $0.details
                            )
                        },
                    deadlines:
                        deadlines.map {
                            DeadlineBackup(
                                dueDate:
                                    $0.dueDate,
                                title:
                                    $0.title,
                                note:
                                    $0.note
                            )
                        },
                    lawResults:
                        lawResults.map {
                            FreelanceLawResultBackup(
                                createdAt:
                                    $0.createdAt,
                                warningCount:
                                    $0.warningCount,
                                answersRaw:
                                    $0.answersRaw,
                                resultMessage:
                                    $0.resultMessage
                            )
                        },
                    workStyleHistory:
                        try UserDefaults.standard.data(forKey: "freelanceGuardWorkStyleHistoryV1").map {
                            try JSONDecoder().decode([MacWorkStyleHistory].self, from: $0)
                        } ?? []
                )

            let encoder =
                JSONEncoder()

            encoder.outputFormatting = [
                .prettyPrinted,
                .sortedKeys
            ]

            let data =
                try encoder.encode(
                    archive
                )

            let formatter =
                DateFormatter()

            formatter.dateFormat =
                "yyyyMMdd_HHmm"

            let fileName =
                "フリーランス守りナビ_バックアップ_\(formatter.string(from: Date())).json"

            let panel =
                NSSavePanel()

            panel.title =
                "バックアップを保存"

            panel.nameFieldStringValue =
                fileName

            panel.allowedContentTypes = [
                .json
            ]

            guard
                panel.runModal() == .OK,
                let url = panel.url
            else {
                return
            }

            try data.write(
                to: url,
                options: .atomic
            )

            showInfo(
                title:
                    "バックアップ完了",
                message:
                    "すべての記録をバックアップしました。"
            )

        } catch {

            showError(
                title:
                    "バックアップエラー",
                message:
                    error.localizedDescription
            )
        }
    }

    // ==================================================
    // MARK: 復元
    // ==================================================

    static func restoreBackup(
        contractStore: ContractStore,
        modelContext: ModelContext
    ) {

        let panel =
            NSOpenPanel()

        panel.title =
            "バックアップファイルを選択"

        panel.allowedContentTypes = [
            .json
        ]

        panel.allowsMultipleSelection =
            false

        panel.canChooseDirectories =
            false

        guard
            panel.runModal() == .OK,
            let url = panel.url
        else {
            return
        }

        do {

            let data =
                try Data(
                    contentsOf: url
                )

            let decoder =
                JSONDecoder()

            let archive =
                try decoder.decode(
                    BackupArchive.self,
                    from: data
                )

            guard archive.version == 1 else {
                throw NSError(domain: "BackupManager", code: 1, userInfo: [NSLocalizedDescriptionKey: "このバックアップの形式には対応していません。データは変更していません。"])
            }
            // Encode before changing any persisted records.
            let contractData = try JSONEncoder().encode(archive.contracts)
            let historyData = try JSONEncoder().encode(archive.workStyleHistory ?? [])

            let confirm =
                NSAlert()

            confirm.messageText =
                "バックアップを復元しますか？"

            confirm.informativeText =
                """
                現在アプリ内に保存されている契約情報・勤務記録・証拠メモ・重要日・チェック履歴は、バックアップ内のデータに置き換わります。

                この操作は元に戻せません。
                """

            confirm.alertStyle =
                .warning

            confirm.addButton(
                withTitle:
                    "復元する"
            )

            confirm.addButton(
                withTitle:
                    "キャンセル"
            )

            let response =
                confirm.runModal()

            guard
                response == .alertFirstButtonReturn
            else {
                return
            }

            let autosaveWasEnabled = modelContext.autosaveEnabled
            modelContext.autosaveEnabled = false
            defer { modelContext.autosaveEnabled = autosaveWasEnabled }

            try deleteCurrentData(
                modelContext:
                    modelContext
            )


            for item in archive.workRecords {

                modelContext.insert(
                    WorkRecord(
                        date:
                            item.date,
                        startTime:
                            item.startTime,
                        endTime:
                            item.endTime,
                        workDetails:
                            item.workDetails,
                        instructionDetails:
                            item.instructionDetails
                    )
                )
            }

            for item in archive.evidenceMemos {

                modelContext.insert(
                    EvidenceMemo(
                        createdAt:
                            item.createdAt,
                        title:
                            item.title,
                        category:
                            item.category,
                        details:
                            item.details
                    )
                )
            }

            for item in archive.deadlines {

                modelContext.insert(
                    DeadlineItem(
                        dueDate:
                            item.dueDate,
                        title:
                            item.title,
                        note:
                            item.note
                    )
                )
            }

            for item in archive.lawResults {

                modelContext.insert(
                    FreelanceLawResult(
                        createdAt:
                            item.createdAt,
                        warningCount:
                            item.warningCount,
                        answersRaw:
                            item.answersRaw,
                        resultMessage:
                            item.resultMessage
                    )
                )
            }

            try modelContext.save()

            contractStore.replaceAllWithEncodedData(archive.contracts, data: contractData)
            UserDefaults.standard.set(historyData, forKey: "freelanceGuardWorkStyleHistoryV1")

            showInfo(
                title:
                    "復元完了",
                message:
                    "バックアップからデータを復元しました。"
            )

        } catch {
            modelContext.rollback()
            showError(
                title:
                    "復元エラー",
                message:
                    error.localizedDescription
            )
        }
    }

    // ==================================================
    // MARK: 現在データ削除
    // ==================================================

    private static func deleteCurrentData(
        modelContext: ModelContext
    ) throws {

        let works =
            try modelContext.fetch(
                FetchDescriptor<WorkRecord>()
            )

        for item in works {
            modelContext.delete(
                item
            )
        }

        let memos =
            try modelContext.fetch(
                FetchDescriptor<EvidenceMemo>()
            )

        for item in memos {
            modelContext.delete(
                item
            )
        }

        let deadlines =
            try modelContext.fetch(
                FetchDescriptor<DeadlineItem>()
            )

        for item in deadlines {
            modelContext.delete(
                item
            )
        }

        let lawResults =
            try modelContext.fetch(
                FetchDescriptor<FreelanceLawResult>()
            )

        for item in lawResults {
            modelContext.delete(
                item
            )
        }

        // The caller saves deletes and inserts together, so failed restores can roll back.
    }

    // ==================================================
    // MARK: ダイアログ
    // ==================================================

    private static func showInfo(
        title: String,
        message: String
    ) {

        let alert =
            NSAlert()

        alert.messageText =
            title

        alert.informativeText =
            message

        alert.alertStyle =
            .informational

        alert.runModal()
    }

    private static func showError(
        title: String,
        message: String
    ) {

        let alert =
            NSAlert()

        alert.messageText =
            title

        alert.informativeText =
            message

        alert.alertStyle =
            .critical

        alert.runModal()
    }
}
