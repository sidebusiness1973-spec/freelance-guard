import SwiftUI
import SwiftData

@main
struct FreelanceGuardMacApp: App {

    var body: some Scene {

        WindowGroup {
            ContentView()
        }
        .modelContainer(
            for: [
                WorkRecord.self,
                EvidenceMemo.self,
                DeadlineItem.self,
                FreelanceLawResult.self
            ]
        )
    }
}
