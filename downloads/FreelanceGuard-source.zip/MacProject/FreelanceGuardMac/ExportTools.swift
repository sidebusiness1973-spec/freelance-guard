import SwiftUI
import AppKit
import UniformTypeIdentifiers
import CoreText

// ======================================================
// MARK: - レポート出力
// ======================================================

@MainActor
enum ReportExporter {

    // MARK: PDF

    static func exportPDF(
        contracts: [ContractRecord],
        workRecords: [WorkRecord],
        memos: [EvidenceMemo],
        deadlines: [DeadlineItem],
        lawResults: [FreelanceLawResult]
    ) {

        let panel = NSSavePanel()

        panel.title = "PDFレポートを保存"
        panel.nameFieldStringValue =
            "フリーランス守りナビ_レポート.pdf"

        panel.allowedContentTypes = [
            .pdf
        ]

        guard
            panel.runModal() == .OK,
            let url = panel.url
        else {
            return
        }

        let view = makePrintableView(
            contracts: contracts,
            workRecords: workRecords,
            memos: memos,
            deadlines: deadlines,
            lawResults: lawResults
        )

        do {
            let pdfData = try PaginatedPDF.makeData(view.attributedString())

            try pdfData.write(
                to: url,
                options: .atomic
            )

            showMessage(
                title: "PDF保存完了",
                message:
                    "レポートをPDF形式で保存しました。"
            )

        } catch {

            showError(
                title: "PDF保存エラー",
                message:
                    error.localizedDescription
            )
        }
    }

    // MARK: CSV

    static func exportCSV(
        contracts: [ContractRecord],
        workRecords: [WorkRecord],
        memos: [EvidenceMemo],
        deadlines: [DeadlineItem],
        lawResults: [FreelanceLawResult]
    ) {

        var csv = "\u{FEFF}"

        csv += """
        種類,日付,タイトル,項目1,項目2,項目3,メモ

        """

        for result in MacWorkStyleHistory.load() {
            csv += csvRow([
                "働き方チェック",
                result.date.formatted(date: .numeric, time: .shortened),
                "該当 \(result.yesCount) / \(result.answers.count)",
                result.answers.map { $0 ? "はい" : "いいえ" }.joined(separator: " / "),
                "", "", ""
            ])
        }

        // -------------------------------
        // 契約情報
        // -------------------------------

        for contract in contracts {

            csv += csvRow([
                "契約情報",
                contract.createdAt.formatted(
                    date: .numeric,
                    time: .shortened
                ),
                contract.company,
                contract.person,
                contract.contractType,
                "\(contract.pay) \(contract.workStyle)",
                contract.notes
            ])
        }

        // -------------------------------
        // 勤務記録
        // -------------------------------

        for record in workRecords {

            csv += csvRow([
                "勤務記録",
                record.date.formatted(
                    date: .numeric,
                    time: .omitted
                ),
                record.workDetails,
                record.startTime.formatted(
                    date: .omitted,
                    time: .shortened
                ),
                record.endTime.formatted(
                    date: .omitted,
                    time: .shortened
                ),
                record.instructionDetails,
                ""
            ])
        }

        // -------------------------------
        // 証拠・メモ
        // -------------------------------

        for memo in memos {

            csv += csvRow([
                "証拠・メモ",
                memo.createdAt.formatted(
                    date: .numeric,
                    time: .shortened
                ),
                memo.title,
                memo.category,
                "",
                "",
                memo.details
            ])
        }

        // -------------------------------
        // 期限
        // -------------------------------

        for item in deadlines {

            csv += csvRow([
                "期限・重要日",
                item.dueDate.formatted(
                    date: .numeric,
                    time: .omitted
                ),
                item.title,
                "",
                "",
                "",
                item.note
            ])
        }

        // -------------------------------
        // フリーランス法チェック
        // -------------------------------

        for result in lawResults {

            csv += csvRow([
                "フリーランス法チェック",
                result.createdAt.formatted(
                    date: .numeric,
                    time: .shortened
                ),
                "確認が必要な項目 \(result.warningCount)件",
                result.answersRaw,
                "",
                "",
                result.resultMessage
            ])
        }

        let panel =
            NSSavePanel()

        panel.title =
            "CSVレポートを保存"

        panel.nameFieldStringValue =
            "フリーランス守りナビ_レポート.csv"

        panel.allowedContentTypes = [
            .commaSeparatedText
        ]

        guard
            panel.runModal() == .OK,
            let url = panel.url
        else {
            return
        }

        do {

            try csv.write(
                to: url,
                atomically: true,
                encoding: .utf8
            )

            showMessage(
                title: "CSV保存完了",
                message:
                    "レポートをCSV形式で保存しました。"
            )

        } catch {

            showError(
                title: "CSV保存エラー",
                message:
                    error.localizedDescription
            )
        }
    }

    // MARK: 印刷

    static func printReport(
        contracts: [ContractRecord],
        workRecords: [WorkRecord],
        memos: [EvidenceMemo],
        deadlines: [DeadlineItem],
        lawResults: [FreelanceLawResult]
    ) {

        let view =
            makePrintableView(
                contracts: contracts,
                workRecords: workRecords,
                memos: memos,
                deadlines: deadlines,
                lawResults: lawResults
            )

        let printOperation =
            NSPrintOperation(
                view: view
            )

        printOperation.showsPrintPanel =
            true

        printOperation.showsProgressPanel =
            true

        printOperation.run()
    }

    // ==================================================
    // MARK: - 印刷・PDF本文
    // ==================================================

    private static func makePrintableView(
        contracts: [ContractRecord],
        workRecords: [WorkRecord],
        memos: [EvidenceMemo],
        deadlines: [DeadlineItem],
        lawResults: [FreelanceLawResult]
    ) -> NSTextView {

        let width: CGFloat =
            595

        let textView =
            NSTextView(
                frame:
                    NSRect(
                        x: 0,
                        y: 0,
                        width: width,
                        height: 842
                    )
            )

        textView.isEditable =
            false

        textView.isSelectable =
            true

        textView.textContainerInset =
            NSSize(
                width: 35,
                height: 35
            )

        let content =
            NSMutableAttributedString()

        let titleStyle:
            [NSAttributedString.Key: Any] = [

                .font:
                    NSFont.boldSystemFont(
                        ofSize: 25
                    )
            ]

        let subtitleStyle:
            [NSAttributedString.Key: Any] = [

                .font:
                    NSFont.systemFont(
                        ofSize: 13
                    ),

                .foregroundColor:
                    NSColor.secondaryLabelColor
            ]

        let headingStyle:
            [NSAttributedString.Key: Any] = [

                .font:
                    NSFont.boldSystemFont(
                        ofSize: 17
                    )
            ]

        let itemTitleStyle:
            [NSAttributedString.Key: Any] = [

                .font:
                    NSFont.boldSystemFont(
                        ofSize: 13
                    )
            ]

        let normalStyle:
            [NSAttributedString.Key: Any] = [

                .font:
                    NSFont.systemFont(
                        ofSize: 12
                    )
            ]

        // ==================================================
        // ヘッダー
        // ==================================================

        append(
            "フリーランス守りナビ\n",
            style: titleStyle,
            to: content
        )

        append(
            """
            記録レポート
            作成日時：\(Date().formatted(date: .long, time: .shortened))

            """,
            style: subtitleStyle,
            to: content
        )

        append(
            """
            契約情報：\(contracts.count)件
            勤務記録：\(workRecords.count)件
            証拠・メモ：\(memos.count)件
            期限・重要日：\(deadlines.count)件
            フリーランス法チェック：\(lawResults.count)件
            働き方チェック：\(MacWorkStyleHistory.load().count)件


            """,
            style: normalStyle,
            to: content
        )

        // ==================================================
        // 契約
        // ==================================================

        append("■ 働き方チェック履歴\n\n", style: headingStyle, to: content)
        let workStyleHistory = MacWorkStyleHistory.load()
        if workStyleHistory.isEmpty {
            append("登録なし\n\n", style: normalStyle, to: content)
        } else {
            for result in workStyleHistory {
                append(
                    "\(result.date.formatted(date: .numeric, time: .shortened))：\(result.yesCount) / \(result.answers.count)項目が該当\n\n",
                    style: normalStyle,
                    to: content
                )
            }
        }

        append(
            "■ 契約情報\n\n",
            style: headingStyle,
            to: content
        )

        if contracts.isEmpty {

            append(
                "登録なし\n\n",
                style: normalStyle,
                to: content
            )

        } else {

            for contract in contracts {

                append(
                    "\(contract.company)\n",
                    style: itemTitleStyle,
                    to: content
                )

                append(
                    """
                    担当者：\(contract.person)
                    契約形態：\(contract.contractType)
                    報酬：\(contract.pay)
                    働き方：\(contract.workStyle)
                    登録日：\(contract.createdAt.formatted(date: .long, time: .shortened))

                    """,
                    style: normalStyle,
                    to: content
                )

                if !contract.notes.isEmpty {

                    append(
                        """
                        契約メモ：
                        \(contract.notes)

                        """,
                        style: normalStyle,
                        to: content
                    )
                }

                append(
                    "----------------------------------------\n\n",
                    style: normalStyle,
                    to: content
                )
            }
        }

        // ==================================================
        // 勤務記録
        // ==================================================

        append(
            "■ 勤務記録\n\n",
            style: headingStyle,
            to: content
        )

        if workRecords.isEmpty {

            append(
                "登録なし\n\n",
                style: normalStyle,
                to: content
            )

        } else {

            for record in workRecords {

                append(
                    "\(record.date.formatted(date: .long, time: .omitted))\n",
                    style: itemTitleStyle,
                    to: content
                )

                append(
                    """
                    勤務時間：
                    \(record.startTime.formatted(date: .omitted, time: .shortened))
                    〜
                    \(record.endTime.formatted(date: .omitted, time: .shortened))

                    業務内容：
                    \(record.workDetails)

                    指示・命令：
                    \(record.instructionDetails)

                    ----------------------------------------

                    """,
                    style: normalStyle,
                    to: content
                )
            }
        }

        // ==================================================
        // 証拠・メモ
        // ==================================================

        append(
            "■ 証拠・メモ\n\n",
            style: headingStyle,
            to: content
        )

        if memos.isEmpty {

            append(
                "登録なし\n\n",
                style: normalStyle,
                to: content
            )

        } else {

            for memo in memos {

                append(
                    "\(memo.title)\n",
                    style: itemTitleStyle,
                    to: content
                )

                append(
                    """
                    日時：\(memo.createdAt.formatted(date: .long, time: .shortened))
                    分類：\(memo.category)

                    内容：
                    \(memo.details)

                    ----------------------------------------

                    """,
                    style: normalStyle,
                    to: content
                )
            }
        }

        // ==================================================
        // 期限
        // ==================================================

        append(
            "■ 期限・重要日\n\n",
            style: headingStyle,
            to: content
        )

        if deadlines.isEmpty {

            append(
                "登録なし\n\n",
                style: normalStyle,
                to: content
            )

        } else {

            for item in deadlines {

                append(
                    "\(item.title)\n",
                    style: itemTitleStyle,
                    to: content
                )

                append(
                    """
                    日付：\(item.dueDate.formatted(date: .long, time: .omitted))
                    メモ：\(item.note)

                    ----------------------------------------

                    """,
                    style: normalStyle,
                    to: content
                )
            }
        }

        // ==================================================
        // フリーランス法チェック
        // ==================================================

        append(
            "■ フリーランス法チェック履歴\n\n",
            style: headingStyle,
            to: content
        )

        if lawResults.isEmpty {

            append(
                "保存済み結果なし\n\n",
                style: normalStyle,
                to: content
            )

        } else {

            for result in lawResults {

                append(
                    result.createdAt.formatted(
                        date: .long,
                        time: .shortened
                    ) + "\n",
                    style: itemTitleStyle,
                    to: content
                )

                append(
                    """
                    確認が必要な項目：\(result.warningCount)件

                    \(result.resultMessage)

                    ----------------------------------------

                    """,
                    style: normalStyle,
                    to: content
                )
            }
        }

        // ==================================================
        // 注意事項
        // ==================================================

        append(
            """

            ※このレポートは、利用者自身が入力・保存した記録を整理したものです。
            ※個別案件について法的判断・法律相談・行政判断を行うものではありません。
            """,
            style: subtitleStyle,
            to: content
        )

        textView.textStorage?
            .setAttributedString(
                content
            )

        textView.sizeToFit()

        let requiredHeight =
            max(
                textView.frame.height + 80,
                842
            )

        textView.frame =
            NSRect(
                x: 0,
                y: 0,
                width: width,
                height: requiredHeight
            )

        return textView
    }

    // ==================================================
    // MARK: - CSV
    // ==================================================

    private static func csvRow(
        _ values: [String]
    ) -> String {

        let escaped =
            values.map { value in

                let clean =
                    value.replacingOccurrences(
                        of: "\"",
                        with: "\"\""
                    )

                return "\"\(clean)\""
            }

        return
            escaped.joined(
                separator: ","
            )
            + "\n"
    }

    // ==================================================
    // MARK: - 文字追加
    // ==================================================

    private static func append(
        _ string: String,
        style:
            [NSAttributedString.Key: Any],
        to content:
            NSMutableAttributedString
    ) {

        content.append(
            NSAttributedString(
                string: string,
                attributes: style
            )
        )
    }

    // ==================================================
    // MARK: - ダイアログ
    // ==================================================

    private static func showMessage(
        title: String,
        message: String
    ) {

        let alert =
            NSAlert()

        alert.messageText =
            title

        alert.informativeText =
            message

        alert.alertStyle =
            .informational

        alert.runModal()
    }

    private static func showError(
        title: String,
        message: String
    ) {

        let alert =
            NSAlert()

        alert.messageText =
            title

        alert.informativeText =
            message

        alert.alertStyle =
            .warning

        alert.runModal()
    }
}


// Lay out by visible text ranges rather than character counts to retain long lines,
// blank lines and Japanese text across A4 pages. PDF text remains selectable.
@MainActor
enum PaginatedPDF {
    static func makeData(_ input: NSAttributedString) throws -> Data {
        let content = NSMutableAttributedString(attributedString: input)
        if content.length == 0 { content.append(NSAttributedString(string: " ")) }
        content.addAttribute(.foregroundColor, value: NSColor.black, range: NSRange(location: 0, length: content.length))
        let data = NSMutableData()
        var page = CGRect(x: 0, y: 0, width: 595, height: 842)
        guard let consumer = CGDataConsumer(data: data as CFMutableData),
              let context = CGContext(consumer: consumer, mediaBox: &page, nil) else {
            throw failure()
        }
        let framesetter = CTFramesetterCreateWithAttributedString(content as CFAttributedString)
        let path = CGPath(rect: page.insetBy(dx: 40, dy: 40), transform: nil)
        var location = 0
        while location < content.length {
            let frame = CTFramesetterCreateFrame(framesetter, CFRange(location: location, length: 0), path, nil)
            let visible = CTFrameGetVisibleStringRange(frame)
            guard visible.length > 0 else { throw failure() }
            context.beginPDFPage(nil)
            context.setFillColor(CGColor(gray: 1, alpha: 1))
            context.fill(page)
            context.textMatrix = .identity
            CTFrameDraw(frame, context)
            context.endPDFPage()
            location += visible.length
        }
        context.closePDF()
        return data as Data
    }

    private static func failure() -> NSError {
        NSError(domain: "PaginatedPDF", code: 1, userInfo: [NSLocalizedDescriptionKey: "PDFを作成できませんでした。"])
    }
}
