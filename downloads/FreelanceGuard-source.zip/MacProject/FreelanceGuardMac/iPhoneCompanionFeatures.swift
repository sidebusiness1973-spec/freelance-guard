import SwiftUI
import SwiftData
import AppKit
import PDFKit
import UniformTypeIdentifiers

// The history is kept separately from the existing SwiftData schema so existing
// installations can open this update without a model migration.
struct MacWorkStyleHistory: Identifiable, Codable {
    var id = UUID()
    var date: Date
    var yesCount: Int
    var answers: [Bool]

    static func load() -> [MacWorkStyleHistory] {
        guard let data = UserDefaults.standard.data(forKey: "freelanceGuardWorkStyleHistoryV1") else { return [] }
        return (try? JSONDecoder().decode([MacWorkStyleHistory].self, from: data)) ?? []
    }
}

struct MacConsultationView: View {
    private let destinations: [(String, String, String)] = [
        ("労働基準監督署", "勤務時間・場所や業務指示など、実際の働き方を整理して相談します。", "https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/koyou_roudou/roudoukijun/kijyungaiyou/kijyungaiyou06.html"),
        ("総合労働相談コーナー", "どの窓口へ相談すべきか分からないときに利用できます。", "https://www.mhlw.go.jp/general/seido/chihou/kaiketu/soudan.html"),
        ("フリーランス・トラブル110番", "業務委託の契約解除や報酬未払いなどを相談できます。", "https://freelance110.mhlw.go.jp"),
        ("公正取引委員会", "フリーランス法に関する相談・申出先を確認できます。", "https://www.jftc.go.jp/soudan/soudan/freelance.html")
    ]

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                Text("相談先案内").font(.largeTitle.bold())
                Text("契約書、勤務記録、指示のやり取り、支払条件、出来事の日付を先に整理しましょう。")
                    .foregroundStyle(.secondary)
                ForEach(destinations.indices, id: \.self) { index in
                    let destination = destinations[index]
                    GroupBox(destination.0) {
                        VStack(alignment: .leading, spacing: 10) {
                            Text(destination.1)
                            if let url = URL(string: destination.2) {
                                Link("公式サイトをブラウザで開く", destination: url)
                            }
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(.vertical, 5)
                    }
                }
                GroupBox("弁護士への相談") {
                    Text("契約解除・未払い・交渉など、個別事情に基づく判断が必要な場合は、契約書と時系列の記録を持参して相談してください。")
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                Text("案内先のWebページはMacの標準ブラウザで開きます。アプリ内にWebページを表示しません。")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            .padding(30)
            .frame(maxWidth: 900, alignment: .leading)
        }
    }
}

struct MacDocumentDraftView: View {
    @Environment(\.modelContext) private var modelContext
    @State private var purpose = "支払いのお願い・督促"
    @State private var recipient = ""
    @State private var sender = ""
    @State private var amount = ""
    @State private var deadline = Date()
    @State private var facts = ""
    @State private var request = ""
    @State private var draft = ""
    @State private var notice = ""

    private let purposes = ["支払いのお願い・督促", "契約内容の確認", "契約終了・解除の確認", "業務条件の確認", "記録を残すための通知"]

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text("文書作成サポート").font(.largeTitle.bold())
                Text("入力した事実から、相手へ送る文案のたたき台を作ります。")
                    .foregroundStyle(.secondary)
                Picker("文書の目的", selection: $purpose) {
                    ForEach(purposes, id: \.self) { Text($0) }
                }
                TextField("宛先（会社名・担当者など）", text: $recipient)
                TextField("差出人（氏名・屋号など）", text: $sender)
                if purpose == purposes[0] {
                    TextField("確認する金額（例：120,000円）", text: $amount)
                }
                DatePicker("回答・支払いを希望する日", selection: $deadline, displayedComponents: .date)
                Text("事実・経緯").font(.headline)
                TextEditor(text: $facts).frame(height: 110).border(Color.gray.opacity(0.3))
                Text("相手に求めたいこと").font(.headline)
                TextEditor(text: $request).frame(height: 80).border(Color.gray.opacity(0.3))
                Button("文案を作成") { draft = makeDraft() }
                    .buttonStyle(.borderedProminent)
                    .disabled(facts.trimmed.isEmpty && request.trimmed.isEmpty)

                if !draft.isEmpty {
                    Text("文案プレビュー").font(.headline)
                    Text(draft).textSelection(.enabled)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding().background(Color.gray.opacity(0.08))
                    HStack {
                        Button("コピー") {
                            NSPasteboard.general.clearContents()
                            NSPasteboard.general.setString(draft, forType: .string)
                            notice = "文案をコピーしました"
                        }
                        Button("PDFで保存") {
                            do { if try MacDraftPDF.save(draft) { notice = "PDFを保存しました" } }
                            catch { notice = "PDF保存エラー：\(error.localizedDescription)" }
                        }
                        Button("証拠・メモに保存") {
                            modelContext.insert(EvidenceMemo(createdAt: Date(), title: purpose, category: "契約", details: draft))
                            do { try modelContext.save(); notice = "証拠・メモに保存しました" }
                            catch { modelContext.rollback(); notice = "保存エラー：\(error.localizedDescription)" }
                        }
                    }
                }
                if !notice.isEmpty { Text(notice).foregroundStyle(.secondary) }
                Text("この文案やPDFは情報整理用です。内容証明郵便の形式や法的効果を保証するものではありません。送付前に事実・宛先・金額を確認してください。")
                    .font(.caption).foregroundStyle(.secondary)
            }
            .textFieldStyle(.roundedBorder)
            .padding(30)
            .frame(maxWidth: 900, alignment: .leading)
        }
    }

    private func makeDraft() -> String {
        let target = recipient.trimmed.isEmpty ? "ご担当者様" : recipient.trimmed
        let opening: String
        switch purpose {
        case "支払いのお願い・督促": opening = "未払いの報酬について確認とお支払いをお願いいたします。"
        case "契約内容の確認": opening = "契約内容について認識に相違がないかご確認ください。"
        case "契約終了・解除の確認": opening = "契約終了・解除の日付、理由及び今後の取扱いをご確認ください。"
        case "業務条件の確認": opening = "業務条件について確認をお願いいたします。"
        default: opening = "下記の事実について記録と確認のためご連絡します。"
        }
        let sum = (purpose == purposes[0] && !amount.trimmed.isEmpty) ? "\n確認する金額：\(amount.trimmed)" : ""
        return """
        \(target)

        \(opening)

        【事実・経緯】
        \(facts.trimmed.isEmpty ? "（事実を入力してください）" : facts.trimmed)\(sum)

        【お願いしたいこと】
        \(request.trimmed.isEmpty ? "上記についてご確認のうえ、ご回答をお願いいたします。" : request.trimmed)

        回答希望日：\(deadline.formatted(date: .numeric, time: .omitted))

        \(sender.trimmed)
        """
    }
}

private extension String {
    var trimmed: String { trimmingCharacters(in: .whitespacesAndNewlines) }
}

private enum MacDraftPDF {
    static func save(_ text: String) throws -> Bool {
        let panel = NSSavePanel()
        panel.title = "文案をPDFで保存"
        panel.nameFieldStringValue = "フリーランス守りナビ_文案.pdf"
        panel.allowedContentTypes = [.pdf]
        guard panel.runModal() == .OK, let url = panel.url else { return false }
        let content = NSAttributedString(string: text, attributes: [.font: NSFont.systemFont(ofSize: 12)])
        try PaginatedPDF.makeData(content).write(to: url, options: .atomic)
        return true
    }
}

struct MacMessageOrganizerView: View {
    @Environment(\.modelContext) private var modelContext
    @State private var input = ""
    @State private var output = ""
    @State private var notice = ""

    private let rules: [(String, String)] = [
        ("日付・時刻", #"\d{1,4}[年/.-]\d{1,2}|\d{1,2}時|\d{1,2}:\d{2}"#),
        ("勤務時間", "勤務|稼働|出勤|退勤|休憩|残業"),
        ("件数・ノルマ", "件|本|ノルマ|必達|目標"),
        ("指示・依頼", "指示|命令|依頼|提出|報告|必ず"),
        ("出社・勤務場所", "出社|在宅|リモート|オフィス|勤務場所"),
        ("契約終了", "解除|解約|契約終了|停止|更新しない")
    ]

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text("文章整理").font(.largeTitle.bold())
                Text("LINEやメールなどの文章を貼り付け、端末内のルールで項目別に整理します。")
                    .foregroundStyle(.secondary)
                TextEditor(text: $input).frame(height: 210).border(Color.gray.opacity(0.3))
                Button("文章を整理する") { output = organize(input) }
                    .buttonStyle(.borderedProminent)
                    .disabled(input.trimmed.isEmpty)
                if !output.isEmpty {
                    Text(output).textSelection(.enabled)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding().background(Color.gray.opacity(0.08))
                    Button("証拠・メモに保存") {
                        modelContext.insert(EvidenceMemo(createdAt: Date(), title: "文章整理", category: "その他", details: output))
                        do { try modelContext.save(); notice = "証拠・メモに保存しました" }
                        catch { modelContext.rollback(); notice = "保存エラー：\(error.localizedDescription)" }
                    }
                }
                if !notice.isEmpty { Text(notice).foregroundStyle(.secondary) }
                Text("分類は文字の一致を使った整理です。法的評価や違法性の判定は行いません。原文も別に保管してください。")
                    .font(.caption).foregroundStyle(.secondary)
            }
            .padding(30).frame(maxWidth: 900, alignment: .leading)
        }
    }

    private func organize(_ text: String) -> String {
        let lines = text.components(separatedBy: .newlines).map(\.trimmed).filter { !$0.isEmpty }
        var sections: [String] = []
        for (label, expression) in rules {
            let matches = lines.filter { $0.range(of: expression, options: .regularExpression) != nil }
            if !matches.isEmpty { sections.append("【\(label)】\n" + matches.map { "・" + $0 }.joined(separator: "\n")) }
        }
        return sections.isEmpty ? "該当する表現が見つかりませんでした。原文を確認してください。" : sections.joined(separator: "\n\n")
    }
}

struct MacEvidenceChecklistView: View {
    @Environment(\.modelContext) private var modelContext
    @State private var selectedCase = 0
    @State private var checked: Set<Int> = []
    @State private var notice = ""

    private let cases = ["契約解除・アカウント停止", "報酬未払い・支払遅延", "勤務時間・シフト指定", "出社・勤務場所指定", "件数・ノルマ・具体的指示", "契約内容と実態の違い"]
    private let itemsByCase: [[String]] = [
        ["契約書・発注書", "解除・終了の通知", "アカウント停止の記録", "勤務予定・シフト", "カレンダー・会議予定", "それまでの業務実績", "解除前後のやり取り", "報酬・請求資料"],
        ["契約書・発注書", "請求書", "納品・業務完了記録", "勤務・稼働記録", "支払予定の連絡", "催促・問い合わせ履歴", "入金履歴", "報酬変更の連絡"],
        ["契約書・募集条件", "シフト表", "タイムカード・勤怠", "定例会議予定", "開始・終了の指示", "休暇に関する連絡", "日報・業務報告", "条件変更の経緯"],
        ["契約書・募集条件", "出社指示", "前日・当日の確認", "カレンダー", "交通・入館記録", "勤務場所変更の連絡", "出社頻度の記録", "場所指定に関する説明"],
        ["件数目標・必達指示", "業務マニュアル", "チャットの業務指示", "ロープレ・研修記録", "日報・件数報告", "評価・注意の連絡", "会議メモ・予定", "システム上の履歴"],
        ["契約書", "募集時の情報", "実際の勤務記録", "実際の勤務場所", "業務指示", "報酬・請求記録", "条件変更のやり取り", "時系列メモ"]
    ]

    private var currentItems: [String] { itemsByCase[selectedCase] }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text("証拠チェックリスト").font(.largeTitle.bold())
                Text("手元にある資料を確認し、相談前の準備に役立てます。")
                    .foregroundStyle(.secondary)
                Picker("ケース", selection: $selectedCase) {
                    ForEach(cases.indices, id: \.self) { index in Text(cases[index]).tag(index) }
                }
                .onChange(of: selectedCase) { _, _ in checked.removeAll() }
                ForEach(currentItems.indices, id: \.self) { index in
                    Toggle(currentItems[index], isOn: Binding(
                        get: { checked.contains(index) },
                        set: { isOn in
                            if isOn { checked.insert(index) } else { checked.remove(index) }
                        }
                    ))
                }
                Text("確認済み：\(checked.count) / \(currentItems.count)")
                Button("確認状況を証拠・メモに保存") {
                    let details = currentItems.indices.map { "\(checked.contains($0) ? "確認済み" : "未確認")：\(currentItems[$0])" }.joined(separator: "\n")
                    modelContext.insert(EvidenceMemo(createdAt: Date(), title: "証拠チェック：\(cases[selectedCase])", category: "その他", details: details))
                    do { try modelContext.save(); notice = "証拠・メモに保存しました" }
                    catch { modelContext.rollback(); notice = "保存エラー：\(error.localizedDescription)" }
                }
                if !notice.isEmpty { Text(notice).foregroundStyle(.secondary) }
                Text("元データは編集・削除せず、別途保管してください。")
                    .font(.caption).foregroundStyle(.secondary)
            }
            .padding(30).frame(maxWidth: 900, alignment: .leading)
        }
    }
}

struct MacKnowledgeView: View {
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                Text("契約・トラブルの基礎知識").font(.largeTitle.bold())
                GroupBox("契約前の確認") {
                    Text("業務内容、報酬と支払日、作業場所、契約期間、変更・解除の方法を契約書や発注書で確認しましょう。")
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                GroupBox("働き方の記録") {
                    Text("勤務時間・場所の指定、定例会議、具体的な指示、シフト、件数目標など、契約と実際の働き方の両方を記録しましょう。")
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                GroupBox("トラブルが起きたとき") {
                    Text("日時・相手・出来事を時系列にまとめ、契約書、請求書、チャット、メール等の原本を残してください。必要に応じて相談先案内から専門窓口を確認できます。")
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                Text("この画面は一般的な情報整理を支援するものです。個別の法的判断は行いません。")
                    .font(.caption).foregroundStyle(.secondary)
            }
            .padding(30).frame(maxWidth: 900, alignment: .leading)
        }
    }
}
