#!/bin/zsh

set -euo pipefail

script_directory="${0:A:h}"
project_directory="${script_directory:h}"
project_path="${project_directory}/フリーランス守りナビ Mac.xcodeproj"
scheme_name="フリーランス守りナビ Mac"
archive_directory="${project_directory}/build/archives"
archive_path="${archive_directory}/${scheme_name}.xcarchive"
derived_data_path="${project_directory}/build/DerivedData"

mkdir -p "${archive_directory}"

echo "1/3 Release設定を検証しています…"
xcodebuild \
    -project "${project_path}" \
    -scheme "${scheme_name}" \
    -configuration Release \
    -destination "generic/platform=macOS" \
    -derivedDataPath "${derived_data_path}" \
    clean build \
    CODE_SIGN_STYLE=Automatic

echo "2/3 Archiveを作成しています…"
xcodebuild \
    -project "${project_path}" \
    -scheme "${scheme_name}" \
    -configuration Release \
    -destination "generic/platform=macOS" \
    -derivedDataPath "${derived_data_path}" \
    -archivePath "${archive_path}" \
    archive \
    CODE_SIGN_STYLE=Automatic

echo "3/3 Xcode Organizerを開きます…"
open "${archive_path}"

echo "完了: ${archive_path}"
echo "Organizerで『Distribute App』→『App Store Connect』を選択してください。"
